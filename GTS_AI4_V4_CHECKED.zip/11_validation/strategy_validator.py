"""
GTS — Global Trading System
Module   : 11_validation/strategy_validator.py
Owner    : AI-4

INPUT       : A strategy plugin directory
              (07_strategy/plugins/<ASSET>/<STRATEGY_ID>/) containing
              strategy.py, config.json, manifest.json, tests/.
OUTPUT      : StrategyValidationResult — pass/fail + list of StrategyIssue.
CALLER      : 07_strategy/strategy_registry/strategy_validator.py hook,
              11_validation/qa_gate.py, plugin "Discover -> Validate ->
              Register" flow (Master Blueprint section 6).
CALLEE      : 11_validation/code_validator.py (reused for strategy.py).
DEPENDENCIES: Standard library + code_validator.py (sibling module).

Purpose: enforce the mandatory plugin structure and safety contract before
a strategy plugin is allowed to register with the strategy_registry:
  - required files present (strategy.py, config.json, manifest.json, tests/)
  - manifest.json has required keys and matches folder location
  - config.json is valid JSON and contains required risk-aware keys
  - strategy.py passes code_validator.py
  - strategy.py does not attempt to import forbidden pipeline stages
    (a strategy must not import 14_execution/15_broker/17_live_trading
    directly — it must only ever emit signals, per Master Blueprint
    "No strategy creation authority" / core-engine independence rule)
  - strategy.py exposes the required entry-point interface
    (a callable/class implementing generate_signal / on_bar)
"""

from __future__ import annotations

import ast
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path

try:
    from code_validator import CodeValidator, Severity as CodeSeverity
except ImportError:  # pragma: no cover - allows standalone use/testing
    CodeValidator = None  # type: ignore[assignment, misc]
    CodeSeverity = None  # type: ignore[assignment, misc]

logger = logging.getLogger("gts.validation.strategy_validator")
if not logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"))
    logger.addHandler(_h)
    logger.setLevel(logging.INFO)


class Severity(str, Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    BLOCKER = "BLOCKER"


@dataclass(frozen=True)
class StrategyIssue:
    rule_id: str
    severity: Severity
    message: str

    def __str__(self) -> str:  # pragma: no cover
        return f"[{self.severity.value}] {self.rule_id} — {self.message}"


@dataclass
class StrategyValidationResult:
    passed: bool
    strategy_id: str
    issues: list[StrategyIssue] = field(default_factory=list)
    checked_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @property
    def blockers(self) -> list[StrategyIssue]:
        return [i for i in self.issues if i.severity == Severity.BLOCKER]

    @property
    def warnings(self) -> list[StrategyIssue]:
        return [i for i in self.issues if i.severity == Severity.WARNING]

    def summary(self) -> str:
        status = "PASS" if self.passed else "FAIL"
        return (
            f"StrategyValidator {status} [{self.strategy_id}] — "
            f"{len(self.blockers)} blocker(s), {len(self.warnings)} warning(s)"
        )


REQUIRED_PLUGIN_FILES = ("strategy.py", "config.json", "manifest.json")
REQUIRED_MANIFEST_KEYS = ("strategy_id", "asset", "version", "author", "priority_tier")
REQUIRED_CONFIG_KEYS = ("max_position_size", "max_daily_loss", "enabled")

# A strategy plugin must never import these pipeline stages directly — it
# only produces signals; risk/execution/broker/live wiring is core-engine
# responsibility (Master Blueprint: "core engines remain independent from
# individual strategies", "No strategy creation authority").
FORBIDDEN_STRATEGY_IMPORTS = {
    "14_execution", "15_broker", "16_paper_trading",
    "17_live_trading", "18_accounting",
}

# Valid strategy priority tiers per Master Blueprint section 3.
VALID_PRIORITY_TIERS = {"EXPIRY_SPECIALIST", "SCALPING", "INTRADAY", "SWING"}

REQUIRED_ENTRY_POINTS = {"generate_signal", "on_bar"}  # at least one required


class StrategyValidator:
    """
    Validates a single strategy plugin directory against the GTS plugin
    contract before it may be registered.

    Usage
    -----
        validator = StrategyValidator()
        result = validator.validate("07_strategy/plugins/NIFTY/my_strategy/")
    """

    def __init__(self) -> None:
        self._code_validator = CodeValidator() if CodeValidator is not None else None

    # ------------------------------------------------------------------ #

    def validate(self, plugin_dir: str | Path) -> StrategyValidationResult:
        plugin_dir = Path(plugin_dir)
        strategy_id = plugin_dir.name
        issues: list[StrategyIssue] = []

        issues += self._check_required_files(plugin_dir)

        manifest = self._load_json_safely(plugin_dir / "manifest.json", "GTS-STRAT-010", issues)
        if manifest is not None:
            issues += self._check_manifest(manifest, strategy_id)

        config = self._load_json_safely(plugin_dir / "config.json", "GTS-STRAT-011", issues)
        if config is not None:
            issues += self._check_config(config)

        strategy_py = plugin_dir / "strategy.py"
        if strategy_py.exists():
            issues += self._check_strategy_code(strategy_py)
            issues += self._check_forbidden_imports(strategy_py)
            issues += self._check_entry_points(strategy_py)

        tests_dir = plugin_dir / "tests"
        if not tests_dir.exists() or not any(tests_dir.glob("test_*.py")):
            issues.append(
                StrategyIssue(
                    "GTS-STRAT-012", Severity.WARNING,
                    "No tests found under tests/ (expected test_*.py).",
                )
            )

        passed = not any(i.severity == Severity.BLOCKER for i in issues)
        result = StrategyValidationResult(passed=passed, strategy_id=strategy_id, issues=issues)
        logger.info(result.summary())
        return result

    # ------------------------------------------------------------------ #
    # Individual checks
    # ------------------------------------------------------------------ #

    def _check_required_files(self, plugin_dir: Path) -> list[StrategyIssue]:
        issues: list[StrategyIssue] = []
        if not plugin_dir.exists():
            issues.append(
                StrategyIssue(
                    "GTS-STRAT-001", Severity.BLOCKER,
                    f"Plugin directory does not exist: {plugin_dir}",
                )
            )
            return issues
        for required in REQUIRED_PLUGIN_FILES:
            if not (plugin_dir / required).exists():
                issues.append(
                    StrategyIssue(
                        "GTS-STRAT-002", Severity.BLOCKER,
                        f"Required file missing: {required}",
                    )
                )
        return issues

    def _load_json_safely(
        self, path: Path, error_rule_id: str, issues: list[StrategyIssue]
    ) -> dict | None:
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            issues.append(
                StrategyIssue(
                    error_rule_id, Severity.BLOCKER,
                    f"Invalid JSON in {path.name}: {exc}",
                )
            )
            return None

    def _check_manifest(self, manifest: dict, strategy_id: str) -> list[StrategyIssue]:
        issues: list[StrategyIssue] = []
        missing = [k for k in REQUIRED_MANIFEST_KEYS if k not in manifest]
        if missing:
            issues.append(
                StrategyIssue(
                    "GTS-STRAT-003", Severity.BLOCKER,
                    f"manifest.json missing required key(s): {missing}",
                )
            )
        declared_id = manifest.get("strategy_id")
        if declared_id and declared_id != strategy_id:
            issues.append(
                StrategyIssue(
                    "GTS-STRAT-004", Severity.BLOCKER,
                    f"manifest.json strategy_id '{declared_id}' does not "
                    f"match plugin folder name '{strategy_id}'.",
                )
            )
        tier = manifest.get("priority_tier")
        if tier is not None and tier not in VALID_PRIORITY_TIERS:
            issues.append(
                StrategyIssue(
                    "GTS-STRAT-005", Severity.WARNING,
                    f"Unrecognised priority_tier '{tier}' "
                    f"(expected one of {sorted(VALID_PRIORITY_TIERS)}).",
                )
            )
        return issues

    def _check_config(self, config: dict) -> list[StrategyIssue]:
        issues: list[StrategyIssue] = []
        missing = [k for k in REQUIRED_CONFIG_KEYS if k not in config]
        if missing:
            issues.append(
                StrategyIssue(
                    "GTS-STRAT-006", Severity.BLOCKER,
                    f"config.json missing required key(s): {missing}",
                )
            )
        max_pos = config.get("max_position_size")
        if isinstance(max_pos, (int, float)) and max_pos <= 0:
            issues.append(
                StrategyIssue(
                    "GTS-STRAT-007", Severity.BLOCKER,
                    f"max_position_size must be positive, got {max_pos}.",
                )
            )
        max_loss = config.get("max_daily_loss")
        if isinstance(max_loss, (int, float)) and max_loss <= 0:
            issues.append(
                StrategyIssue(
                    "GTS-STRAT-008", Severity.BLOCKER,
                    f"max_daily_loss must be positive, got {max_loss}.",
                )
            )
        return issues

    def _check_strategy_code(self, strategy_py: Path) -> list[StrategyIssue]:
        issues: list[StrategyIssue] = []
        if self._code_validator is None:
            issues.append(
                StrategyIssue(
                    "GTS-STRAT-009", Severity.WARNING,
                    "code_validator.py not importable — skipping static "
                    "code checks for strategy.py.",
                )
            )
            return issues
        report = self._code_validator.validate_file(strategy_py)
        for code_issue in report.issues:
            issues.append(
                StrategyIssue(
                    code_issue.rule_id,
                    Severity(code_issue.severity.value),
                    f"strategy.py: {code_issue.message}",
                )
            )
        return issues

    def _check_forbidden_imports(self, strategy_py: Path) -> list[StrategyIssue]:
        issues: list[StrategyIssue] = []
        try:
            tree = ast.parse(strategy_py.read_text(encoding="utf-8"), filename=str(strategy_py))
        except (SyntaxError, OSError, UnicodeDecodeError):
            return issues  # already reported by code_validator

        for node in ast.walk(tree):
            module_name = None
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module_name = alias.name.split(".")[0]
                    if module_name in FORBIDDEN_STRATEGY_IMPORTS:
                        issues.append(
                            StrategyIssue(
                                "GTS-STRAT-013", Severity.BLOCKER,
                                f"strategy.py imports forbidden module "
                                f"'{module_name}' — strategies may only emit "
                                f"signals, not touch execution/broker/live "
                                f"layers directly.",
                            )
                        )
            elif isinstance(node, ast.ImportFrom) and node.module:
                module_name = node.module.split(".")[0]
                if module_name in FORBIDDEN_STRATEGY_IMPORTS:
                    issues.append(
                        StrategyIssue(
                            "GTS-STRAT-013", Severity.BLOCKER,
                            f"strategy.py imports forbidden module "
                            f"'{module_name}' — strategies may only emit "
                            f"signals, not touch execution/broker/live "
                            f"layers directly.",
                        )
                    )
        return issues

    def _check_entry_points(self, strategy_py: Path) -> list[StrategyIssue]:
        issues: list[StrategyIssue] = []
        try:
            tree = ast.parse(strategy_py.read_text(encoding="utf-8"), filename=str(strategy_py))
        except (SyntaxError, OSError, UnicodeDecodeError):
            return issues

        found: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if node.name in REQUIRED_ENTRY_POINTS:
                    found.add(node.name)
            if isinstance(node, ast.ClassDef):
                for item in node.body:
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        if item.name in REQUIRED_ENTRY_POINTS:
                            found.add(item.name)

        if not found:
            issues.append(
                StrategyIssue(
                    "GTS-STRAT-014", Severity.BLOCKER,
                    f"strategy.py must implement at least one of "
                    f"{sorted(REQUIRED_ENTRY_POINTS)} as an entry point.",
                )
            )
        return issues


def main(argv: list[str] | None = None) -> int:
    """
    CLI usage:
        python strategy_validator.py <plugin_dir>
    """
    import sys

    args = argv if argv is not None else sys.argv[1:]
    if not args:
        print("Usage: python strategy_validator.py <plugin_dir>")
        return 2

    validator = StrategyValidator()
    result = validator.validate(args[0])

    for issue in result.issues:
        print(issue)
    print(result.summary())
    return 0 if result.passed else 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
