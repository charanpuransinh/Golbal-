"""
live_engine.py
==============
MODULE   : 17_live_trading
OWNER    : AI-4
PURPOSE  : Routes validated, risk-approved signals to the real broker via
           14_execution.order_manager. This is the ONLY module allowed to
           send real orders to a live broker account.

INPUT    : Approved signals (post risk + live_gate)
OUTPUT   : Live order confirmations, fills, broker acks
CALLER   : 25_scheduler, 20_dashboard (live trading tab)
CALLEE   : 14_execution.order_manager, 15_broker.broker_registry,
           12_risk.kill_switch, 17_live_trading.live_gate
DEPENDS  : live_gate, order_manager, broker_adapter_base, kill_switch
"""

from __future__ import annotations
import time
import uuid
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

logger = logging.getLogger("gts.live_engine")


class LiveOrderStatus(Enum):
    PENDING = "PENDING"
    SENT = "SENT"
    ACKED = "ACKED"
    FILLED = "FILLED"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    REJECTED = "REJECTED"
    CANCELLED = "CANCELLED"
    ERROR = "ERROR"


@dataclass
class LiveOrder:
    order_id: str
    symbol: str
    side: str                 # BUY / SELL
    quantity: float
    order_type: str = "MARKET"
    limit_price: Optional[float] = None
    strategy_id: Optional[str] = None
    status: LiveOrderStatus = LiveOrderStatus.PENDING
    broker_order_id: Optional[str] = None
    filled_qty: float = 0.0
    avg_fill_price: float = 0.0
    created_at: float = field(default_factory=time.time)
    error: Optional[str] = None


class LiveEngine:
    """
    Owns the full lifecycle of a live order:
    live_gate check -> broker send -> ack/fill tracking -> kill_switch watch
    """

    def __init__(self, broker_adapter, live_gate, kill_switch, order_manager):
        """
        broker_adapter : instance of 15_broker.broker_adapter_base.BrokerAdapter
        live_gate      : instance of live_gate.LiveGate
        kill_switch    : instance of 12_risk.kill_switch.KillSwitch
        order_manager  : instance of 14_execution.order_manager.OrderManager
        """
        self.broker = broker_adapter
        self.live_gate = live_gate
        self.kill_switch = kill_switch
        self.order_manager = order_manager
        self.orders: Dict[str, LiveOrder] = {}

    def submit_signal(self, symbol: str, side: str, quantity: float,
                       order_type: str = "MARKET", limit_price: float = None,
                       strategy_id: str = None) -> LiveOrder:
        order_id = str(uuid.uuid4())
        order = LiveOrder(
            order_id=order_id, symbol=symbol, side=side, quantity=quantity,
            order_type=order_type, limit_price=limit_price, strategy_id=strategy_id,
        )
        self.orders[order_id] = order

        # 1. Kill switch check (highest priority, cannot be bypassed)
        if self.kill_switch.is_tripped():
            order.status = LiveOrderStatus.REJECTED
            order.error = "KILL_SWITCH_ACTIVE"
            logger.warning("Order %s rejected: kill switch active", order_id)
            return order

        # 2. Live eligibility gate (validation, risk, exposure all passed?)
        gate_result = self.live_gate.check(order)
        if not gate_result.approved:
            order.status = LiveOrderStatus.REJECTED
            order.error = gate_result.reason
            logger.warning("Order %s rejected by live_gate: %s", order_id, gate_result.reason)
            return order

        # 3. Route through order_manager -> broker
        try:
            order.status = LiveOrderStatus.SENT
            broker_response = self.order_manager.submit(
                symbol=symbol, side=side, quantity=quantity,
                order_type=order_type, limit_price=limit_price,
                broker=self.broker,
            )
            order.broker_order_id = broker_response.get("broker_order_id")
            order.status = LiveOrderStatus.ACKED
        except Exception as exc:  # noqa: BLE001
            order.status = LiveOrderStatus.ERROR
            order.error = str(exc)
            logger.exception("Live order %s failed to send", order_id)
            self.kill_switch.report_error(source="live_engine", detail=str(exc))

        return order

    def on_broker_fill(self, broker_order_id: str, fill_qty: float, fill_price: float):
        """Called by broker webhook/poller when a fill event arrives."""
        order = next(
            (o for o in self.orders.values() if o.broker_order_id == broker_order_id), None
        )
        if not order:
            logger.warning("Fill received for unknown broker_order_id=%s", broker_order_id)
            return
        order.filled_qty += fill_qty
        order.avg_fill_price = fill_price
        order.status = (
            LiveOrderStatus.FILLED if order.filled_qty >= order.quantity
            else LiveOrderStatus.PARTIALLY_FILLED
        )

    def cancel_order(self, order_id: str) -> bool:
        order = self.orders.get(order_id)
        if not order or order.status not in (LiveOrderStatus.SENT, LiveOrderStatus.ACKED):
            return False
        try:
            self.order_manager.cancel(order.broker_order_id, broker=self.broker)
            order.status = LiveOrderStatus.CANCELLED
            return True
        except Exception as exc:  # noqa: BLE001
            logger.exception("Cancel failed for order %s", order_id)
            order.error = str(exc)
            return False

    def open_orders(self) -> List[LiveOrder]:
        return [
            o for o in self.orders.values()
            if o.status in (LiveOrderStatus.SENT, LiveOrderStatus.ACKED, LiveOrderStatus.PARTIALLY_FILLED)
        ]
