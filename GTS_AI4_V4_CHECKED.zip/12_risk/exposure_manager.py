"""
GTS — Global Trading System
Module   : 12_risk/exposure_manager.py
Owner    : AI-4

INPUT       : Proposed order (symbol, side, quantity, price), current
              positions and current gross exposure from 13_portfolio.
OUTPUT      : ExposureResult — approved quantity (possibly reduced) or
              rejection, with explanation.
CALLER      : 12_risk/risk_engine.py.
CALLEE      : None outside stdlib.
DEPENDENCIES: Standard library only.

Purpose: enforce gross portfolio exposure limits and per-symbol
concentration limits, so no combination of positions can push the book
beyond configured bounds — independent of any single order's own size
limit (that is position_sizing.py's job).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class ExposureResult:
    approved_quantity: float
    requested_quantity: float
    rejected: bool
    message: str = ""
    evaluated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class ExposureManager:
    """
    Enforces gross and per-symbol exposure limits.

    Usage
    -----
        manager = ExposureManager(max_gross_exposure=1_000_000, max_symbol_exposure_pct=0.25)
        result = manager.check(
            symbol="NIFTY", side="BUY", quantity=50, price=20000,
            current_positions={}, current_gross_exposure=0.0,
        )
    """

    def __init__(self, max_gross_exposure: float, max_symbol_exposure_pct: float = 0.25) -> None:
        if max_gross_exposure <= 0:
            raise ValueError("max_gross_exposure must be positive.")
        if not (0 < max_symbol_exposure_pct <= 1):
            raise ValueError("max_symbol_exposure_pct must be in (0, 1].")
        self.max_gross_exposure = max_gross_exposure
        self.max_symbol_exposure_pct = max_symbol_exposure_pct
        self.max_symbol_exposure = max_gross_exposure * max_symbol_exposure_pct

    # ------------------------------------------------------------------ #

    def check(
        self,
        symbol: str,
        side: str,
        quantity: float,
        price: float,
        current_positions: dict[str, float],
        current_gross_exposure: float,
    ) -> ExposureResult:
        if quantity <= 0 or price <= 0:
            return ExposureResult(
                approved_quantity=0.0, requested_quantity=quantity, rejected=True,
                message=f"Non-positive quantity ({quantity}) or price ({price}).",
            )

        direction = 1 if side.upper() in ("BUY", "LONG") else -1
        order_notional = quantity * price

        # --- Per-symbol exposure check ---
        current_symbol_qty = current_positions.get(symbol, 0.0)
        new_symbol_qty = current_symbol_qty + direction * quantity
        new_symbol_notional = abs(new_symbol_qty) * price

        approved_quantity = quantity
        messages: list[str] = []

        if new_symbol_notional > self.max_symbol_exposure:
            # Reduce quantity so the resulting symbol notional hits the cap.
            max_additional_notional = max(
                0.0, self.max_symbol_exposure - abs(current_symbol_qty) * price
            )
            capped_qty = max_additional_notional / price if price > 0 else 0.0
            if capped_qty < quantity:
                messages.append(
                    f"Per-symbol exposure cap hit for {symbol}: would reach "
                    f"{new_symbol_notional:.2f}, limit {self.max_symbol_exposure:.2f}. "
                    f"Quantity reduced from {quantity} to {capped_qty:.4f}."
                )
                approved_quantity = max(0.0, capped_qty)

        # --- Gross exposure check ---
        order_notional = approved_quantity * price
        new_gross_exposure = current_gross_exposure + order_notional
        if new_gross_exposure > self.max_gross_exposure:
            max_additional_gross = max(0.0, self.max_gross_exposure - current_gross_exposure)
            capped_by_gross = max_additional_gross / price if price > 0 else 0.0
            if capped_by_gross < approved_quantity:
                messages.append(
                    f"Gross exposure cap hit: would reach {new_gross_exposure:.2f}, "
                    f"limit {self.max_gross_exposure:.2f}. Quantity reduced from "
                    f"{approved_quantity:.4f} to {capped_by_gross:.4f}."
                )
                approved_quantity = max(0.0, capped_by_gross)

        if approved_quantity <= 0:
            return ExposureResult(
                approved_quantity=0.0,
                requested_quantity=quantity,
                rejected=True,
                message=" ".join(messages) or "Exposure limits reduce order to zero.",
            )

        return ExposureResult(
            approved_quantity=approved_quantity,
            requested_quantity=quantity,
            rejected=False,
            message=" ".join(messages),
        )


def main(argv: list[str] | None = None) -> int:
    """CLI smoke-test: python exposure_manager.py"""
    manager = ExposureManager(max_gross_exposure=100_000, max_symbol_exposure_pct=0.25)
    result = manager.check(
        symbol="NIFTY", side="BUY", quantity=10, price=20000,
        current_positions={}, current_gross_exposure=0.0,
    )
    print(result)
    return 0 if not result.rejected else 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
