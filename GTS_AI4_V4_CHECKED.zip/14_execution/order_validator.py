"""
GTS — Global Trading System
Module   : 14_execution/order_validator.py
Owner    : AI-4

INPUT       : A fully risk-approved Order (already passed through
              12_risk/risk_engine.py) plus instrument metadata from
              02_instruments.
OUTPUT      : OrderValidationResult — pass/fail before the order is
              allowed to reach a broker adapter.
CALLER      : 14_execution/order_manager.py (mandatory step: Risk ->
              order_validator -> execution_engine -> broker).
CALLEE       : None outside stdlib.
DEPENDENCIES: Standard library only.

Purpose: the last static gate before an order touches a broker. This is
deliberately independent of risk_engine.py — risk_engine.py decides
"should this trade happen at all", order_validator.py decides "is this
order object well-formed and exchange-compliant" (tick size, lot size,
duplicate/idempotency check, symbol validity, order-type support). Two
independent gates catch two independent classes of bugs.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum


class OrderType(str, Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP = "STOP"
    STOP_LIMIT = "STOP_LIMIT"


class Severity(str, Enum):
    WARNING = "WARNING"
    BLOCKER = "BLOCKER"


@dataclass(frozen=True)
class InstrumentSpec:
    """Minimal instrument metadata needed for exchange-compliance checks.
    In production this is looked up from 02_instruments; passed in here
    to keep this module free of a hard dependency on that package."""
    symbol: str
    tick_size: float
    lot_size: int
    min_quantity: int = 1
    max_quantity: int | None = None
    tradable: bool = True


@dataclass(frozen=True)
class Order:
    order_id: str
    symbol: str
    side: str            # BUY / SELL
    quantity: float
    order_type: OrderType
    limit_price: float | None = None
    stop_price: float | None = None
    strategy_id: str = ""


@dataclass(frozen=True)
class OrderIssue:
    rule_id: str
    severity: Severity
    message: str

    def __str__(self) -> str:  # pragma: no cover
        return f"[{self.severity.value}] {self.rule_id} — {self.message}"


@dataclass
class OrderValidationResult:
    passed: bool
    order_id: str
    issues: list[OrderIssue] = field(default_factory=list)
    checked_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def summary(self) -> str:
        status = "PASS" if self.passed else "FAIL"
        return f"OrderValidator {status} [{self.order_id}] — {len(self.issues)} issue(s)"


class OrderValidator:
    """
    Validates a single order's structural / exchange-compliance correctness.
    Maintains an in-memory idempotency cache to reject duplicate order_ids.

    Usage
    -----
        validator = OrderValidator()
        spec = InstrumentSpec(symbol="NIFTY", tick_size=0.05, lot_size=50)
        result = validator.validate(order, spec)
    """

    def __init__(self) -> None:
        self._seen_order_ids: set[str] = set()

    # ------------------------------------------------------------------ #

    def validate(self, order: Order, spec: InstrumentSpec) -> OrderValidationResult:
        issues: list[OrderIssue] = []

        issues += self._check_symbol_match(order, spec)
        issues += self._check_tradable(spec)
        issues += self._check_duplicate(order)
        issues += self._check_quantity(order, spec)
        issues += self._check_lot_size(order, spec)
        issues += self._check_price_fields(order)
        issues += self._check_tick_size(order, spec)

        passed = not any(i.severity == Severity.BLOCKER for i in issues)
        if passed:
            self._seen_order_ids.add(order.order_id)

        return OrderValidationResult(passed=passed, order_id=order.order_id, issues=issues)

    # ------------------------------------------------------------------ #

    def _check_symbol_match(self, order: Order, spec: InstrumentSpec) -> list[OrderIssue]:
        if order.symbol != spec.symbol:
            return [
                OrderIssue(
                    "GTS-ORD-001", Severity.BLOCKER,
                    f"Order symbol '{order.symbol}' does not match "
                    f"instrument spec '{spec.symbol}'.",
                )
            ]
        return []

    def _check_tradable(self, spec: InstrumentSpec) -> list[OrderIssue]:
        if not spec.tradable:
            return [
                OrderIssue(
                    "GTS-ORD-002", Severity.BLOCKER,
                    f"Instrument '{spec.symbol}' is not currently tradable "
                    f"(halted, delisted, or outside session).",
                )
            ]
        return []

    def _check_duplicate(self, order: Order) -> list[OrderIssue]:
        if order.order_id in self._seen_order_ids:
            return [
                OrderIssue(
                    "GTS-ORD-003", Severity.BLOCKER,
                    f"Duplicate order_id '{order.order_id}' — possible "
                    f"retry/replay bug. Order rejected for idempotency.",
                )
            ]
        return []

    def _check_quantity(self, order: Order, spec: InstrumentSpec) -> list[OrderIssue]:
        issues: list[OrderIssue] = []
        if order.quantity <= 0:
            issues.append(
                OrderIssue("GTS-ORD-004", Severity.BLOCKER, f"Non-positive quantity: {order.quantity}.")
            )
            return issues
        if order.quantity < spec.min_quantity:
            issues.append(
                OrderIssue(
                    "GTS-ORD-005", Severity.BLOCKER,
                    f"Quantity {order.quantity} below minimum {spec.min_quantity}.",
                )
            )
        if spec.max_quantity is not None and order.quantity > spec.max_quantity:
            issues.append(
                OrderIssue(
                    "GTS-ORD-006", Severity.BLOCKER,
                    f"Quantity {order.quantity} exceeds maximum {spec.max_quantity}.",
                )
            )
        return issues

    def _check_lot_size(self, order: Order, spec: InstrumentSpec) -> list[OrderIssue]:
        if spec.lot_size <= 0:
            return []
        if order.quantity % spec.lot_size != 0:
            return [
                OrderIssue(
                    "GTS-ORD-007", Severity.BLOCKER,
                    f"Quantity {order.quantity} is not a multiple of lot "
                    f"size {spec.lot_size}.",
                )
            ]
        return []

    def _check_price_fields(self, order: Order) -> list[OrderIssue]:
        issues: list[OrderIssue] = []
        if order.order_type == OrderType.MARKET:
            if order.limit_price is not None:
                issues.append(
                    OrderIssue(
                        "GTS-ORD-008", Severity.WARNING,
                        "MARKET order has a limit_price set — it will be ignored.",
                    )
                )
        if order.order_type in (OrderType.LIMIT, OrderType.STOP_LIMIT):
            if order.limit_price is None or order.limit_price <= 0:
                issues.append(
                    OrderIssue(
                        "GTS-ORD-009", Severity.BLOCKER,
                        f"{order.order_type.value} order requires a positive limit_price.",
                    )
                )
        if order.order_type in (OrderType.STOP, OrderType.STOP_LIMIT):
            if order.stop_price is None or order.stop_price <= 0:
                issues.append(
                    OrderIssue(
                        "GTS-ORD-010", Severity.BLOCKER,
                        f"{order.order_type.value} order requires a positive stop_price.",
                    )
                )
        return issues

    def _check_tick_size(self, order: Order, spec: InstrumentSpec) -> list[OrderIssue]:
        issues: list[OrderIssue] = []
        if spec.tick_size <= 0:
            return issues
        for label, price in (("limit_price", order.limit_price), ("stop_price", order.stop_price)):
            if price is None:
                continue
            ratio = price / spec.tick_size
            if abs(ratio - round(ratio)) > 1e-6:
                issues.append(
                    OrderIssue(
                        "GTS-ORD-011", Severity.BLOCKER,
                        f"{label} {price} is not a multiple of tick size {spec.tick_size}.",
                    )
                )
        return issues


def main(argv: list[str] | None = None) -> int:
    """CLI smoke-test: python order_validator.py"""
    validator = OrderValidator()
    spec = InstrumentSpec(symbol="NIFTY", tick_size=0.05, lot_size=50, max_quantity=500)
    order = Order(
        order_id="ORD-0001", symbol="NIFTY", side="BUY", quantity=50,
        order_type=OrderType.LIMIT, limit_price=20000.05, strategy_id="expiry_v1",
    )
    result = validator.validate(order, spec)
    print(result.summary())
    for issue in result.issues:
        print(issue)

    # Duplicate submission should now be rejected.
    dup_result = validator.validate(order, spec)
    print(dup_result.summary())
    return 0 if result.passed else 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
