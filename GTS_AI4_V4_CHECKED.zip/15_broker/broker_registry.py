"""
GTS — Global Trading System
Module   : 15_broker/broker_registry.py
Owner    : AI-4

INPUT       : Broker adapter classes (subclasses of BrokerAdapterBase)
              registered at startup, and a broker name/config selected by
              16_paper_trading / 17_live_trading.
OUTPUT      : A live BrokerAdapter instance ready for
              14_execution/execution_engine.py to use.
CALLER      : 16_paper_trading/paper_engine.py, 17_live_trading/live_engine.py,
              27_system (startup wiring).
CALLEE       : 15_broker/broker_adapter_base.py.
DEPENDENCIES: Standard library only.

Purpose: central lookup/factory so the rest of GTS never hard-codes a
specific broker class name. New broker integrations register themselves
here (mirrors the strategy plugin "Discover -> Validate -> Register"
pattern in Master Blueprint section 6) instead of every caller importing
concrete broker modules directly — this is what keeps GTS
broker-independent in practice, not just in the abstract base class.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable

from broker_adapter_base import BrokerAdapterBase, _NullBroker

logger = logging.getLogger("gts.broker.broker_registry")
if not logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"))
    logger.addHandler(_h)
    logger.setLevel(logging.INFO)


BrokerFactory = Callable[..., BrokerAdapterBase]


@dataclass(frozen=True)
class BrokerRegistration:
    name: str
    factory: BrokerFactory
    description: str = ""
    registered_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class BrokerNotFoundError(KeyError):
    """Raised when a caller asks for a broker name that was never registered."""


class BrokerRegistry:
    """
    Central registry mapping broker name -> factory function that builds
    a ready-to-use BrokerAdapterBase instance.

    Usage
    -----
        registry = BrokerRegistry()
        registry.register("null_broker", lambda: _NullBroker(), description="test/dry-run broker")
        broker = registry.get("null_broker")
        broker.connect()
    """

    def __init__(self) -> None:
        self._registrations: dict[str, BrokerRegistration] = {}

    # ------------------------------------------------------------------ #

    def register(self, name: str, factory: BrokerFactory, description: str = "", overwrite: bool = False) -> None:
        if not name or not name.strip():
            raise ValueError("Broker name must be a non-empty string.")
        if name in self._registrations and not overwrite:
            raise ValueError(
                f"Broker '{name}' is already registered. Pass overwrite=True "
                f"to replace it deliberately."
            )
        self._registrations[name] = BrokerRegistration(name=name, factory=factory, description=description)
        logger.info("Registered broker '%s' (%s)", name, description or "no description")

    def unregister(self, name: str) -> None:
        if name in self._registrations:
            del self._registrations[name]
            logger.info("Unregistered broker '%s'", name)

    def get(self, name: str, **factory_kwargs) -> BrokerAdapterBase:
        """Build and return a fresh adapter instance for the given broker name."""
        registration = self._registrations.get(name)
        if registration is None:
            raise BrokerNotFoundError(
                f"No broker registered under name '{name}'. "
                f"Known brokers: {sorted(self._registrations)}"
            )
        adapter = registration.factory(**factory_kwargs)
        if not isinstance(adapter, BrokerAdapterBase):
            raise TypeError(
                f"Factory for broker '{name}' did not return a BrokerAdapterBase "
                f"instance (got {type(adapter).__name__})."
            )
        return adapter

    def list_brokers(self) -> list[str]:
        return sorted(self._registrations)

    def is_registered(self, name: str) -> bool:
        return name in self._registrations


def build_default_registry() -> BrokerRegistry:
    """
    Builds a registry pre-populated with the null/test broker. Concrete
    broker integrations (Zerodha, IBKR, etc.) register themselves into
    this same registry at their own module's import time via
    registry.register(...); this default registry only guarantees a
    dry-run option always exists.
    """
    registry = BrokerRegistry()
    registry.register("null_broker", _NullBroker, description="No-op broker for tests/dry runs.")
    return registry


def main(argv: list[str] | None = None) -> int:
    """CLI smoke-test: python broker_registry.py"""
    registry = build_default_registry()
    print("Registered brokers:", registry.list_brokers())

    broker = registry.get("null_broker")
    broker.connect()
    print(broker.health_check())

    try:
        registry.get("does_not_exist")
    except BrokerNotFoundError as exc:
        print(f"Expected error: {exc}")

    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
