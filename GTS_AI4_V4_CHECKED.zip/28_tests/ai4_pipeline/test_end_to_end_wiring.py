"""
test_end_to_end_wiring.py
MODULE: 28_tests (AI-4 pipeline)
OWNER : AI-4
PURPOSE: Proves the full AI-4 registry mapping (27_system.ai4_bootstrap)
         actually works end-to-end: a paper trade flows through to the
         ledger, trade_book, and reporting engines with correct numbers,
         AND a live order correctly passes through live_gate + kill_switch.

This is the "nothing left unwired" acceptance test for AI-4 scope 09-19.
"""

import sys, os

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_GTS_ROOT = os.path.abspath(os.path.join(_THIS_DIR, "..", ".."))
sys.path.insert(0, os.path.join(_GTS_ROOT, "27_system"))

from ai4_bootstrap import build_registry
from live_gate import GateResult  # noqa: F401  (sanity import through wired path)


def test_registry_builds_and_health_check_passes():
    registry = build_registry(starting_capital=500000)
    status = registry.health_check()
    assert all(v is not None for v in status.values())
    assert status["kill_switch_tripped"] is False


def test_paper_trade_flows_into_ledger_and_trade_book():
    registry = build_registry(starting_capital=100000)

    # simulate a strategy signal -> paper fill -> ledger + trade_book entry
    registry.paper_engine.update_market_price("NIFTY", 100.0)
    order = registry.paper_engine.place_order("NIFTY", "BUY", 10, order_type="MARKET",
                                               strategy_id="S1") \
        if False else registry.paper_engine.place_order(
            "NIFTY",
            __import__("paper_engine").OrderSide.BUY,
            10,
            order_type="MARKET",
            strategy_id="S1",
        )
    assert order.status.value == "FILLED"

    registry.ledger.record_buy("NIFTY", cost=order.avg_fill_price * order.filled_qty, order_id=order.order_id)
    registry.trade_book.open_trade("NIFTY", "S1", "LONG",
                                    entry_price=order.avg_fill_price, entry_qty=order.filled_qty)

    registry.paper_engine.update_market_price("NIFTY", 110.0)
    exit_order = registry.paper_engine.place_order(
        "NIFTY", __import__("paper_engine").OrderSide.SELL, 10,
        order_type="MARKET", strategy_id="S1",
    )
    registry.ledger.record_sell("NIFTY", proceeds=exit_order.avg_fill_price * exit_order.filled_qty,
                                 order_id=exit_order.order_id)
    closed = registry.trade_book.close_trade("NIFTY", "S1",
                                              exit_price=exit_order.avg_fill_price,
                                              exit_qty=exit_order.filled_qty)

    assert closed is not None
    assert closed.realized_pnl > 0
    assert registry.ledger.current_balance() != 100000  # ledger moved


def test_trade_report_reflects_closed_trades():
    registry = build_registry(starting_capital=100000)
    registry.trade_book.open_trade("GOLD", "S1", "LONG", entry_price=50, entry_qty=4)
    registry.trade_book.close_trade("GOLD", "S1", exit_price=55, exit_qty=4)

    report = registry.trade_report_engine.generate(strategy_id="S1")
    assert len(report.rows) == 1
    assert report.summary_by_strategy["S1"]["pnl"] == 20


def test_live_order_blocked_without_certification():
    registry = build_registry()
    order = registry.live_engine.submit_signal("CRUDE", "BUY", 1, strategy_id="UNCERTIFIED_STRATEGY")
    assert order.status.value == "REJECTED"
    assert order.error in ("NO_CERTIFICATION_RECORD",)


def test_live_order_blocked_by_kill_switch():
    registry = build_registry()
    registry.kill_switch.trip(reason="manual_test_trip")
    order = registry.live_engine.submit_signal("CRUDE", "BUY", 1, strategy_id="S1")
    assert order.status.value == "REJECTED"
    assert order.error == "KILL_SWITCH_ACTIVE"


def test_risk_report_generates_with_wired_portfolio_manager():
    registry = build_registry()
    registry.portfolio_manager.set_positions([
        {"symbol": "NIFTY", "quantity": 10, "last_price": 100, "avg_price": 95},
    ])
    report = registry.risk_report_engine.generate(account_equity=100000)
    assert report.gross_exposure == 1000
    assert report.kill_switch_active is False


if __name__ == "__main__":
    test_registry_builds_and_health_check_passes()
    test_paper_trade_flows_into_ledger_and_trade_book()
    test_trade_report_reflects_closed_trades()
    test_live_order_blocked_without_certification()
    test_live_order_blocked_by_kill_switch()
    test_risk_report_generates_with_wired_portfolio_manager()
    print("END-TO-END WIRING: ALL TESTS PASSED — AI-4 registry mapping is complete.")
