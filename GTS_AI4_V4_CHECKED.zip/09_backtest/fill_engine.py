"""
GTS — Global Trading System
Module   : 09_backtest
File     : fill_engine.py
Owner    : AI-4 (Backtest + Risk + Execution + Production)

PURPOSE
-------
Simulates order execution during a backtest: consumes OrderEvent objects,
determines a realistic fill price (base price + slippage) and commission,
optionally caps fill quantity against available bar volume (partial
fills), and publishes FillEvent objects back onto the EventEngine.

CONTRACT
--------
INPUT      : MarketEvent (to track latest price/volume per symbol) and
             OrderEvent (to fill) via EventEngine subscription.
OUTPUT     : FillEvent published back onto the same EventEngine. If an
             order cannot be filled at all (no market data yet for the
             symbol, or LIMIT price never reached), no FillEvent is
             published and the rejection is logged + counted in stats;
             it does not raise, so one unfillable order never stops a run.
CALLER     : backtest_engine.py wires this module's `on_order_event` to
             EventType.ORDER and `on_market_event` to EventType.MARKET.
CALLEE     : event_engine.py only (EventType, MarketEvent, OrderEvent,
             FillEvent, EventEngine).
DEPENDENCIES: event_engine.py (same module, sibling file) + Python
             standard library only.

ARCHITECTURAL RULES ENFORCED
-----------------------------
- No guessing: an order for a symbol with no prior MarketEvent is refused
  (logged + counted), never filled at an invented price.
- No undocumented files: every public class/method documented below.
- Deterministic: slippage/commission models are pure functions of their
  inputs (price, quantity, side) — no hidden randomness by default, which
  is required for reproducible backtests. A seeded-random slippage model
  is provided separately (RandomSlippageModel) for stress-testing, and it
  takes an explicit seed so runs stay reproducible even with it enabled.
"""

from __future__ import annotations

import logging
import random
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Optional

from event_engine import (
    EventEngine,
    EventType,
    FillEvent,
    MarketEvent,
    OrderEvent,
)

logger = logging.getLogger("gts.backtest.fill_engine")


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class FillEngineError(Exception):
    """Base exception for all fill_engine failures."""


class InvalidModelParameterError(FillEngineError):
    """Raised when a slippage/commission model is constructed with an
    out-of-range parameter (e.g. a negative rate)."""


# ---------------------------------------------------------------------------
# Slippage models
# ---------------------------------------------------------------------------

class SlippageModel(ABC):
    """Base class for slippage models. A slippage model answers: given the
    last known market price and an order, what price does it actually fill
    at? Slippage always moves the fill price *against* the trader (worse
    for BUY = higher, worse for SELL = lower) — that is enforced here, not
    left to subclasses, so a buggy model can never accidentally produce
    favorable slippage that inflates backtest returns.
    """

    @abstractmethod
    def apply(self, base_price: float, side: str, quantity: float) -> float:
        """Return the simulated fill price for an order of `quantity` on
        `side` ("BUY"/"SELL") given `base_price` (last known market price).
        Must return a price that is worse for the trader than base_price
        (or equal to it for zero-slippage models)."""
        raise NotImplementedError


class NoSlippageModel(SlippageModel):
    """Fills exactly at the last known market price. Useful for unit tests
    and for isolating strategy performance from execution-cost effects."""

    def apply(self, base_price: float, side: str, quantity: float) -> float:
        return base_price


class FixedPointSlippageModel(SlippageModel):
    """Adds/subtracts a fixed absolute number of price points, regardless
    of order size. Simple and deterministic — good default for liquid
    instruments where size impact is negligible relative to spread."""

    def __init__(self, points: float):
        if points < 0:
            raise InvalidModelParameterError(f"points must be >= 0, got {points!r}")
        self.points = points

    def apply(self, base_price: float, side: str, quantity: float) -> float:
        if side == "BUY":
            return base_price + self.points
        return base_price - self.points


class PercentageSlippageModel(SlippageModel):
    """Moves price by a fixed percentage of base_price, regardless of
    order size. Scales naturally across instruments trading at very
    different absolute price levels (e.g. NIFTY vs. a penny stock)."""

    def __init__(self, rate: float):
        if not (0.0 <= rate < 1.0):
            raise InvalidModelParameterError(f"rate must be in [0.0, 1.0), got {rate!r}")
        self.rate = rate

    def apply(self, base_price: float, side: str, quantity: float) -> float:
        delta = base_price * self.rate
        if side == "BUY":
            return base_price + delta
        return base_price - delta


class VolumeImpactSlippageModel(SlippageModel):
    """Slippage grows with order size relative to the bar's traded volume
    — larger orders relative to liquidity move the price more. Requires
    the caller (FillEngine) to pass the current bar's volume in via
    `set_bar_volume` before each `apply` call; falls back to a minimum
    rate if no volume is known yet, rather than guessing a value.

    fill_price = base_price * (1 + impact_coefficient * (quantity / volume))
    """

    def __init__(self, impact_coefficient: float, min_rate: float = 0.0):
        if impact_coefficient < 0:
            raise InvalidModelParameterError(
                f"impact_coefficient must be >= 0, got {impact_coefficient!r}"
            )
        if not (0.0 <= min_rate < 1.0):
            raise InvalidModelParameterError(f"min_rate must be in [0.0, 1.0), got {min_rate!r}")
        self.impact_coefficient = impact_coefficient
        self.min_rate = min_rate
        self._current_volume: Optional[float] = None

    def set_bar_volume(self, volume: Optional[float]) -> None:
        """Called by FillEngine before apply() so this model knows the
        current bar's traded volume."""
        self._current_volume = volume

    def apply(self, base_price: float, side: str, quantity: float) -> float:
        if not self._current_volume or self._current_volume <= 0:
            rate = self.min_rate
        else:
            rate = max(self.min_rate, self.impact_coefficient * (quantity / self._current_volume))
        delta = base_price * rate
        if side == "BUY":
            return base_price + delta
        return base_price - delta


class RandomSlippageModel(SlippageModel):
    """Adds slippage drawn uniformly from [0, max_rate] of base_price, for
    stress-testing strategies against variable execution quality. Takes an
    explicit seed so backtests remain fully reproducible even with
    randomness enabled — two runs with the same seed produce identical
    slippage sequences."""

    def __init__(self, max_rate: float, seed: int):
        if not (0.0 <= max_rate < 1.0):
            raise InvalidModelParameterError(f"max_rate must be in [0.0, 1.0), got {max_rate!r}")
        self.max_rate = max_rate
        self._rng = random.Random(seed)

    def apply(self, base_price: float, side: str, quantity: float) -> float:
        rate = self._rng.uniform(0.0, self.max_rate)
        delta = base_price * rate
        if side == "BUY":
            return base_price + delta
        return base_price - delta


# ---------------------------------------------------------------------------
# Commission models
# ---------------------------------------------------------------------------

class CommissionModel(ABC):
    """Base class for commission models — answers: how much does this fill
    cost in transaction fees?"""

    @abstractmethod
    def calculate(self, fill_price: float, quantity: float) -> float:
        """Return commission (always >= 0) for a fill of `quantity` units
        at `fill_price`."""
        raise NotImplementedError


class ZeroCommissionModel(CommissionModel):
    """No commission. Useful for unit tests and isolating gross returns."""

    def calculate(self, fill_price: float, quantity: float) -> float:
        return 0.0


class FixedCommissionModel(CommissionModel):
    """A flat fee per fill, independent of price or size (e.g. a broker
    charging a flat 20 currency units per executed order)."""

    def __init__(self, flat_fee: float):
        if flat_fee < 0:
            raise InvalidModelParameterError(f"flat_fee must be >= 0, got {flat_fee!r}")
        self.flat_fee = flat_fee

    def calculate(self, fill_price: float, quantity: float) -> float:
        return self.flat_fee


class PercentageCommissionModel(CommissionModel):
    """Commission as a percentage of notional value (fill_price * quantity)."""

    def __init__(self, rate: float, minimum: float = 0.0):
        if not (0.0 <= rate < 1.0):
            raise InvalidModelParameterError(f"rate must be in [0.0, 1.0), got {rate!r}")
        if minimum < 0:
            raise InvalidModelParameterError(f"minimum must be >= 0, got {minimum!r}")
        self.rate = rate
        self.minimum = minimum

    def calculate(self, fill_price: float, quantity: float) -> float:
        return max(self.minimum, fill_price * quantity * self.rate)


class PerUnitCommissionModel(CommissionModel):
    """Commission as a fixed amount per unit traded (e.g. per share, per
    contract), with an optional minimum per fill."""

    def __init__(self, rate_per_unit: float, minimum: float = 0.0):
        if rate_per_unit < 0:
            raise InvalidModelParameterError(f"rate_per_unit must be >= 0, got {rate_per_unit!r}")
        if minimum < 0:
            raise InvalidModelParameterError(f"minimum must be >= 0, got {minimum!r}")
        self.rate_per_unit = rate_per_unit
        self.minimum = minimum

    def calculate(self, fill_price: float, quantity: float) -> float:
        return max(self.minimum, self.rate_per_unit * quantity)


# ---------------------------------------------------------------------------
# Bar cache (latest market state per symbol)
# ---------------------------------------------------------------------------

@dataclass
class _BarState:
    """Latest known market state for one symbol."""

    close: float
    volume: Optional[float] = None
    bar_time: float = 0.0


# ---------------------------------------------------------------------------
# Fill engine stats
# ---------------------------------------------------------------------------

@dataclass
class FillEngineStats:
    """Runtime counters exposed for health_check.py and reporting."""

    orders_seen: int = 0
    fills_generated: int = 0
    orders_rejected_no_market_data: int = 0
    orders_rejected_limit_not_reached: int = 0
    partial_fills: int = 0
    total_commission: float = 0.0
    by_symbol: Dict[str, int] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Fill engine
# ---------------------------------------------------------------------------

class FillEngine:
    """Consumes OrderEvent, produces FillEvent, using pluggable slippage
    and commission models. Register with an EventEngine via:

        fill_engine = FillEngine(engine, slippage_model, commission_model)
        engine.subscribe(EventType.MARKET, fill_engine.on_market_event)
        engine.subscribe(EventType.ORDER, fill_engine.on_order_event)

    Partial fills: if `max_fill_ratio_of_volume` is set (0.0, 1.0], an
    order's fillable quantity is capped to that fraction of the current
    bar's volume. The unfilled remainder is dropped (a real broker adapter
    in 15_broker would instead re-queue it for the next bar/tick — that
    behavior belongs to 15_broker/17_live_trading, not to this backtest
    fill simulator, per the "core engines independent from strategies /
    other modules stay in their own lane" architectural rule).
    """

    def __init__(
        self,
        engine: EventEngine,
        slippage_model: Optional[SlippageModel] = None,
        commission_model: Optional[CommissionModel] = None,
        max_fill_ratio_of_volume: Optional[float] = None,
    ):
        """
        Args:
            engine: the EventEngine this FillEngine will publish FillEvent
                objects onto. Not subscribed to automatically — the caller
                wires on_market_event/on_order_event explicitly so wiring
                stays visible and auditable in backtest_engine.py.
            slippage_model: defaults to NoSlippageModel if not given.
            commission_model: defaults to ZeroCommissionModel if not given.
            max_fill_ratio_of_volume: optional cap in (0.0, 1.0] limiting
                fill quantity to this fraction of the current bar's
                volume. None disables the cap (full quantity always
                attempted, subject only to market-data availability).

        Raises:
            InvalidModelParameterError: if max_fill_ratio_of_volume is
                given but not in (0.0, 1.0].
        """
        if max_fill_ratio_of_volume is not None and not (0.0 < max_fill_ratio_of_volume <= 1.0):
            raise InvalidModelParameterError(
                f"max_fill_ratio_of_volume must be in (0.0, 1.0], got {max_fill_ratio_of_volume!r}"
            )
        self._engine = engine
        self._slippage_model: SlippageModel = slippage_model or NoSlippageModel()
        self._commission_model: CommissionModel = commission_model or ZeroCommissionModel()
        self._max_fill_ratio_of_volume = max_fill_ratio_of_volume
        self._bars: Dict[str, _BarState] = {}
        self.stats = FillEngineStats()

    # -- event handlers -----------------------------------------------------

    def on_market_event(self, event: MarketEvent) -> None:
        """Cache the latest close price and volume for event.symbol so a
        later OrderEvent for that symbol can be filled. `data` is expected
        to contain a "close" key and, optionally, a "volume" key — both
        owned/produced by 01_market_data upstream; missing "close" is
        treated as a data-quality bug and logged, not guessed."""
        if event.event_type is not EventType.MARKET:
            return  # defensive: only ever called for MARKET, but explicit is safer than assuming
        close = event.data.get("close")
        if close is None:
            logger.error(
                "MarketEvent for %s at bar_time=%s missing 'close' in data — cannot cache price",
                event.symbol, event.bar_time,
            )
            return
        self._bars[event.symbol] = _BarState(
            close=float(close),
            volume=event.data.get("volume"),
            bar_time=event.bar_time,
        )

    def on_order_event(self, event: OrderEvent) -> None:
        """Attempt to fill `event`. Publishes a FillEvent onto self._engine
        on success. On failure (no market data yet, or LIMIT price not
        reached), logs the reason and increments the matching stats
        counter — never raises, and never publishes a partial or
        fabricated fill in the failure case."""
        if event.event_type is not EventType.ORDER:
            return
        self.stats.orders_seen += 1

        bar = self._bars.get(event.symbol)
        if bar is None:
            self.stats.orders_rejected_no_market_data += 1
            logger.warning(
                "Order for %s (order_event_id=%s) rejected: no market data seen yet for this symbol",
                event.symbol, event.event_id,
            )
            return

        if event.order_type == "LIMIT" and not self._limit_price_reached(event, bar.close):
            self.stats.orders_rejected_limit_not_reached += 1
            logger.info(
                "LIMIT order for %s (order_event_id=%s) not filled: limit_price=%s not reached "
                "(bar close=%s)",
                event.symbol, event.event_id, event.limit_price, bar.close,
            )
            return

        base_price = event.limit_price if event.order_type == "LIMIT" else bar.close

        if isinstance(self._slippage_model, VolumeImpactSlippageModel):
            self._slippage_model.set_bar_volume(bar.volume)
        fill_price = self._slippage_model.apply(base_price, event.side, event.quantity)

        fill_quantity = self._apply_volume_cap(event, bar)
        if fill_quantity <= 0:
            self.stats.orders_rejected_no_market_data += 1
            logger.warning(
                "Order for %s (order_event_id=%s) rejected: zero fillable quantity after "
                "volume cap (bar volume=%s)",
                event.symbol, event.event_id, bar.volume,
            )
            return
        if fill_quantity < event.quantity:
            self.stats.partial_fills += 1
            logger.info(
                "Partial fill for %s (order_event_id=%s): requested=%s filled=%s",
                event.symbol, event.event_id, event.quantity, fill_quantity,
            )

        commission = self._commission_model.calculate(fill_price, fill_quantity)

        fill_event = FillEvent(
            symbol=event.symbol,
            quantity=fill_quantity,
            side=event.side,
            fill_price=fill_price,
            commission=commission,
            strategy_id=event.strategy_id,
            order_event_id=event.event_id,
        )
        self._engine.publish(fill_event)

        self.stats.fills_generated += 1
        self.stats.total_commission += commission
        self.stats.by_symbol[event.symbol] = self.stats.by_symbol.get(event.symbol, 0) + 1

    # -- internal helpers -----------------------------------------------------

    @staticmethod
    def _limit_price_reached(event: OrderEvent, bar_close: float) -> bool:
        """A BUY limit fills only if the market traded at or below the
        limit price; a SELL limit fills only if the market traded at or
        above it. Using bar close as the reference price is a simplifying
        assumption for bar-based backtests (intrabar high/low crossing the
        limit is not modeled here) — this is a documented limitation, not
        a silent guess: a tick-level fill_engine variant would be a
        separate, more precise implementation."""
        if event.side == "BUY":
            return bar_close <= event.limit_price
        return bar_close >= event.limit_price

    def _apply_volume_cap(self, event: OrderEvent, bar: _BarState) -> float:
        """Return the fillable quantity for `event`, capped by
        max_fill_ratio_of_volume if configured and bar.volume is known.
        If the cap is configured but volume is unknown, the order is
        filled in full rather than guessed-down — an unknown denominator
        cannot produce a meaningful cap."""
        if self._max_fill_ratio_of_volume is None or bar.volume is None:
            return event.quantity
        cap = bar.volume * self._max_fill_ratio_of_volume
        return min(event.quantity, cap)

    def reset(self) -> None:
        """Clear cached bar state and stats. Call between independent
        backtest runs in the same process."""
        self._bars.clear()
        self.stats = FillEngineStats()
