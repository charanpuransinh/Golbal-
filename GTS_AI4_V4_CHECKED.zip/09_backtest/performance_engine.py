"""
GTS — Global Trading System
Module   : 09_backtest
File     : performance_engine.py
Owner    : AI-4 (Backtest + Risk + Execution + Production)

PURPOSE
-------
Consumes FillEvent (to update positions/cash and realize P&L) and
MarketEvent (to mark open positions to market for the equity curve), and
exposes standard performance metrics: total return, max drawdown, Sharpe
ratio, win rate, profit factor, and a full closed-trade history.

CONTRACT
--------
INPUT      : FillEvent, MarketEvent via EventEngine subscription.
OUTPUT     : No events published — this module is a pure sink/reporter.
             Its public methods (summary(), equity_curve, closed_trades)
             are read by backtest_engine.py and 19_reporting at the end of
             a run (or at checkpoints during a run).
CALLER     : backtest_engine.py wires on_fill_event -> EventType.FILL and
             on_market_event -> EventType.MARKET.
CALLEE     : event_engine.py only (EventType, FillEvent, MarketEvent).
DEPENDENCIES: event_engine.py (same module, sibling file) + Python
             standard library only (math for sqrt in Sharpe ratio).

ARCHITECTURAL RULES ENFORCED
-----------------------------
- No guessing: metrics that need data not yet available (e.g. Sharpe ratio
  with fewer than 2 equity points) return None rather than a fabricated
  number — callers must handle None explicitly.
- Position accounting uses the weighted-average-cost method, applied
  consistently for long and short positions and for direct position
  flips (e.g. long 10 -> sell 15 -> short 5 realizes P&L on the first 10
  and opens a fresh short lot on the remaining 5), so realized P&L is
  always attributable to an actual closed quantity, never estimated.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from event_engine import EventType, FillEvent, MarketEvent

logger = logging.getLogger("gts.backtest.performance_engine")


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class PerformanceEngineError(Exception):
    """Base exception for all performance_engine failures."""


class InsufficientDataError(PerformanceEngineError):
    """Raised by metric methods that require the caller to explicitly
    opt into a fabricated/degenerate result instead of getting None back
    silently (see `sharpe_ratio(..., strict=True)`)."""


# ---------------------------------------------------------------------------
# Data records
# ---------------------------------------------------------------------------

@dataclass
class Position:
    """Current open position for one symbol.

    quantity: signed — positive means long, negative means short, zero
        means flat. Always kept consistent with avg_price: avg_price is
        meaningless (and left at its last value) when quantity == 0.
    avg_price: weighted-average entry price of the currently open lot.
    opened_at: timestamp the position was opened from flat; used as
        ClosedTrade.entry_time when the position is eventually closed.
    """

    quantity: float = 0.0
    avg_price: float = 0.0
    opened_at: float = 0.0


@dataclass
class ClosedTrade:
    """A realized (closed) trade — the unit performance metrics operate on.

    side: "LONG" or "SHORT" — the direction of the position that was
        closed (i.e. "LONG" means this closes a long position, meaning
        the closing fill itself was a SELL).
    quantity: the size that was closed by this trade record. A single
        fill can produce zero, one, or two ClosedTrade records (e.g. a
        flip from long to short produces one record closing the long
        and opens a fresh short with no record until it too is closed).
    """

    symbol: str
    side: str
    quantity: float
    entry_price: float
    exit_price: float
    realized_pnl: float
    commission: float
    entry_time: float
    exit_time: float
    strategy_id: str


@dataclass
class EquityPoint:
    """One point on the equity curve."""

    timestamp: float
    equity: float
    cash: float
    realized_pnl_cumulative: float


# ---------------------------------------------------------------------------
# Performance engine
# ---------------------------------------------------------------------------

class PerformanceEngine:
    """Tracks positions, cash, realized P&L and the equity curve for a
    backtest run, and computes standard performance metrics from them.

    Register with an EventEngine via:

        perf = PerformanceEngine(starting_cash=1_000_000.0)
        engine.subscribe(EventType.MARKET, perf.on_market_event)
        engine.subscribe(EventType.FILL, perf.on_fill_event)

    Equity is recorded (an EquityPoint appended) on every MarketEvent for
    a symbol this engine holds a position in, and on every FillEvent —
    this gives a mark-to-market curve that reacts both to price moves and
    to trading activity, which max_drawdown() and sharpe_ratio() operate
    on directly.
    """

    def __init__(self, starting_cash: float):
        """
        Args:
            starting_cash: initial account cash. Must be > 0.

        Raises:
            ValueError: if starting_cash <= 0.
        """
        if starting_cash <= 0:
            raise ValueError(f"starting_cash must be > 0, got {starting_cash!r}")
        self.starting_cash = starting_cash
        self.cash = starting_cash
        self.realized_pnl_cumulative = 0.0
        self.positions: Dict[str, Position] = {}
        self._last_price: Dict[str, float] = {}
        self.closed_trades: List[ClosedTrade] = []
        self.equity_curve: List[EquityPoint] = []

    # -- event handlers -----------------------------------------------------

    def on_market_event(self, event: MarketEvent) -> None:
        """Update the last known price for event.symbol and, if a position
        in that symbol is currently open, record a fresh mark-to-market
        equity point."""
        if event.event_type is not EventType.MARKET:
            return
        close = event.data.get("close")
        if close is None:
            logger.error(
                "MarketEvent for %s at bar_time=%s missing 'close' — cannot mark to market",
                event.symbol, event.bar_time,
            )
            return
        self._last_price[event.symbol] = float(close)
        if event.symbol in self.positions and self.positions[event.symbol].quantity != 0:
            self._record_equity_point(event.timestamp)

    def on_fill_event(self, event: FillEvent) -> None:
        """Apply `event` to cash and the relevant Position, realizing P&L
        on any quantity that closes/reduces/flips the existing position,
        then record a fresh equity point."""
        if event.event_type is not EventType.FILL:
            return

        self._last_price[event.symbol] = event.fill_price
        position = self.positions.setdefault(event.symbol, Position())
        signed_fill_qty = event.quantity if event.side == "BUY" else -event.quantity

        # Cash always moves by the literal fill notional + commission,
        # regardless of position direction — this is real money accounting,
        # independent of the average-cost P&L bookkeeping below.
        if event.side == "BUY":
            self.cash -= event.quantity * event.fill_price + event.commission
        else:
            self.cash += event.quantity * event.fill_price - event.commission

        same_direction_or_opening = (
            position.quantity == 0
            or (position.quantity > 0 and signed_fill_qty > 0)
            or (position.quantity < 0 and signed_fill_qty < 0)
        )

        if same_direction_or_opening:
            self._increase_position(position, event, signed_fill_qty)
        else:
            self._reduce_or_flip_position(position, event, signed_fill_qty)

        self._record_equity_point(event.timestamp)

    # -- position mutation helpers --------------------------------------------

    def _increase_position(self, position: Position, event: FillEvent, signed_fill_qty: float) -> None:
        """Grow (or open) a position in the same direction as the fill —
        weighted-average the entry price, no P&L realized."""
        if position.quantity == 0:
            position.opened_at = event.timestamp
            position.avg_price = event.fill_price
            position.quantity = signed_fill_qty
            return
        old_abs_qty = abs(position.quantity)
        new_abs_qty = old_abs_qty + event.quantity
        position.avg_price = (
            (old_abs_qty * position.avg_price) + (event.quantity * event.fill_price)
        ) / new_abs_qty
        position.quantity += signed_fill_qty

    def _reduce_or_flip_position(self, position: Position, event: FillEvent, signed_fill_qty: float) -> None:
        """Fill is opposite direction to the current position: realize
        P&L on the overlapping quantity, and if the fill is larger than
        the open position, flip into a fresh position in the new
        direction for the remainder."""
        was_long = position.quantity > 0
        closing_qty = min(abs(position.quantity), event.quantity)
        remaining_fill_qty = event.quantity - closing_qty

        if was_long:
            realized = closing_qty * (event.fill_price - position.avg_price)
            side_label = "LONG"
        else:
            realized = closing_qty * (position.avg_price - event.fill_price)
            side_label = "SHORT"

        commission_for_close = event.commission * (closing_qty / event.quantity) if event.quantity else 0.0

        self.closed_trades.append(
            ClosedTrade(
                symbol=event.symbol,
                side=side_label,
                quantity=closing_qty,
                entry_price=position.avg_price,
                exit_price=event.fill_price,
                realized_pnl=realized,
                commission=commission_for_close,
                entry_time=position.opened_at,
                exit_time=event.timestamp,
                strategy_id=event.strategy_id,
            )
        )
        self.realized_pnl_cumulative += realized

        if was_long:
            position.quantity -= closing_qty
        else:
            position.quantity += closing_qty

        if remaining_fill_qty > 0:
            # Flip: fully closed the old position and there's leftover fill
            # quantity that opens a brand-new position in the other direction.
            position.opened_at = event.timestamp
            position.avg_price = event.fill_price
            position.quantity = remaining_fill_qty if event.side == "BUY" else -remaining_fill_qty
        elif position.quantity == 0:
            position.avg_price = 0.0
            position.opened_at = 0.0

    # -- equity curve ---------------------------------------------------------

    def _record_equity_point(self, timestamp: float) -> None:
        equity = self.cash
        for symbol, position in self.positions.items():
            if position.quantity == 0:
                continue
            price = self._last_price.get(symbol)
            if price is None:
                logger.error(
                    "No last known price for open position in %s at t=%s — "
                    "excluding it from equity mark (equity will understate exposure)",
                    symbol, timestamp,
                )
                continue
            equity += position.quantity * price
        self.equity_curve.append(
            EquityPoint(
                timestamp=timestamp,
                equity=equity,
                cash=self.cash,
                realized_pnl_cumulative=self.realized_pnl_cumulative,
            )
        )

    # -- metrics ---------------------------------------------------------------

    def total_return(self) -> Optional[float]:
        """Return total return as a fraction (0.05 == +5%) from
        starting_cash to the latest equity point. Returns None if no
        equity points have been recorded yet."""
        if not self.equity_curve:
            return None
        return (self.equity_curve[-1].equity - self.starting_cash) / self.starting_cash

    def max_drawdown(self) -> Optional[float]:
        """Return maximum drawdown as a positive fraction (0.20 == -20%
        peak-to-trough drop). Returns None if fewer than 1 equity point
        exists."""
        if not self.equity_curve:
            return None
        peak = self.equity_curve[0].equity
        max_dd = 0.0
        for point in self.equity_curve:
            peak = max(peak, point.equity)
            if peak > 0:
                dd = (peak - point.equity) / peak
                max_dd = max(max_dd, dd)
        return max_dd

    def sharpe_ratio(
        self,
        risk_free_rate: float = 0.0,
        periods_per_year: int = 252,
        strict: bool = False,
    ) -> Optional[float]:
        """Return the annualized Sharpe ratio computed from period-over-
        period returns of the equity curve.

        Args:
            risk_free_rate: annualized risk-free rate, subtracted before
                annualizing (e.g. 0.06 for 6%/year).
            periods_per_year: number of equity-curve periods per year,
                used to annualize the mean and stdev of per-period
                returns (252 for daily bars, adjust for other bar sizes).
            strict: if True, raise InsufficientDataError instead of
                returning None when there isn't enough data.

        Returns:
            The Sharpe ratio, or None (unless strict=True, which raises
            instead) if fewer than 3 equity points exist or if the
            standard deviation of returns is exactly zero (a flat equity
            curve has an undefined Sharpe ratio, not a zero one).
        """
        if len(self.equity_curve) < 3:
            if strict:
                raise InsufficientDataError(
                    f"sharpe_ratio needs >= 3 equity points, have {len(self.equity_curve)}"
                )
            return None

        returns: List[float] = []
        for prev, curr in zip(self.equity_curve, self.equity_curve[1:]):
            if prev.equity == 0:
                continue
            returns.append((curr.equity - prev.equity) / prev.equity)

        if len(returns) < 2:
            if strict:
                raise InsufficientDataError("sharpe_ratio needs >= 2 non-degenerate period returns")
            return None

        mean_return = sum(returns) / len(returns)
        variance = sum((r - mean_return) ** 2 for r in returns) / (len(returns) - 1)
        stdev = math.sqrt(variance)

        if stdev == 0.0:
            if strict:
                raise InsufficientDataError("sharpe_ratio undefined: zero standard deviation of returns")
            return None

        period_risk_free = risk_free_rate / periods_per_year
        return ((mean_return - period_risk_free) / stdev) * math.sqrt(periods_per_year)

    def win_rate(self) -> Optional[float]:
        """Return the fraction of closed trades with realized_pnl > 0.
        Returns None if there are no closed trades yet."""
        if not self.closed_trades:
            return None
        wins = sum(1 for t in self.closed_trades if t.realized_pnl > 0)
        return wins / len(self.closed_trades)

    def profit_factor(self) -> Optional[float]:
        """Return sum(winning P&L) / abs(sum(losing P&L)). Returns None if
        there are no closed trades, and math.inf if there are winning
        trades but zero losing P&L (a genuinely undefined-denominator
        case, distinct from "no data")."""
        if not self.closed_trades:
            return None
        gains = sum(t.realized_pnl for t in self.closed_trades if t.realized_pnl > 0)
        losses = abs(sum(t.realized_pnl for t in self.closed_trades if t.realized_pnl < 0))
        if losses == 0:
            return math.inf if gains > 0 else None
        return gains / losses

    def summary(self) -> Dict[str, object]:
        """Return a single dict snapshot of every metric above, for
        19_reporting to consume without calling each method separately.
        Values that are currently None/undefined are included as None,
        never coerced to 0 — a consumer must not confuse "no trades yet"
        with "zero performance"."""
        return {
            "starting_cash": self.starting_cash,
            "ending_equity": self.equity_curve[-1].equity if self.equity_curve else None,
            "total_return": self.total_return(),
            "max_drawdown": self.max_drawdown(),
            "sharpe_ratio": self.sharpe_ratio(),
            "win_rate": self.win_rate(),
            "profit_factor": self.profit_factor(),
            "total_closed_trades": len(self.closed_trades),
            "realized_pnl_cumulative": self.realized_pnl_cumulative,
        }

    def reset(self) -> None:
        """Reset all state to a fresh run with the same starting_cash.
        Call between independent backtest runs in the same process."""
        self.cash = self.starting_cash
        self.realized_pnl_cumulative = 0.0
        self.positions.clear()
        self._last_price.clear()
        self.closed_trades.clear()
        self.equity_curve.clear()
