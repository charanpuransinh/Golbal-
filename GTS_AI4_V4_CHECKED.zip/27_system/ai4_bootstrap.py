"""
ai4_bootstrap.py
================
MODULE   : 27_system
OWNER    : AI-4
PURPOSE  : Single canonical WIRING file for the entire AI-4 scope
           (09_backtest .. 19_reporting). This is the "registry mapping" —
           it shows exactly which component plugs into which, in what
           order, so nothing in the AI-4 pipeline is left disconnected.

           Replace the Fake* classes with the real modules from
           11_validation, 12_risk, 13_portfolio, 14_execution, 15_broker
           once their concrete implementations are available in this
           project — the wiring shape itself does not change.

WIRES     :
    15_broker.broker_registry   -> broker adapter lookup
    12_risk.risk_engine         -> pre-trade risk checks
    12_risk.exposure_manager    -> exposure / concentration checks
    12_risk.kill_switch         -> global emergency stop
    11_validation.qa_gate       -> strategy QA sign-off
    14_execution.order_manager  -> order routing to broker
    17_live_trading.live_gate   -> production gate (cert + risk + qa)
    17_live_trading.live_engine -> live order lifecycle
    16_paper_trading.paper_engine -> simulated order lifecycle
    18_accounting.ledger        -> cash ledger
    18_accounting.trade_book    -> round-trip trade records
    19_reporting.*              -> performance / risk / trade reports
"""

import sys
import os

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_GTS_ROOT = os.path.abspath(os.path.join(_THIS_DIR, ".."))

for _module_dir in (
    "16_paper_trading", "17_live_trading", "18_accounting", "19_reporting",
):
    sys.path.insert(0, os.path.join(_GTS_ROOT, _module_dir))

from paper_engine import PaperEngine, PaperAccount           # noqa: E402
from live_engine import LiveEngine                            # noqa: E402
from live_gate import LiveGate                                 # noqa: E402
from ledger import Ledger                                      # noqa: E402
from trade_book import TradeBook                                # noqa: E402
from performance_report import PerformanceReportEngine          # noqa: E402
from risk_report import RiskReportEngine                        # noqa: E402
from trade_report import TradeReportEngine                      # noqa: E402


# ---------------------------------------------------------------------------
# Minimal placeholder implementations for modules 11/12/13/14/15.
# SWAP THESE for the real classes once wired to your actual files —
# the registration calls below (`AI4Registry.register(...)`) are what
# other modules should import from, not these placeholders directly.
# ---------------------------------------------------------------------------

class PlaceholderRiskEngine:
    def pre_trade_check(self, order):
        return {"passed": True}


class PlaceholderExposureManager:
    def check(self, order):
        return {"passed": True}
    def check_all(self, positions, equity):
        return {"breaches": []}


class PlaceholderQAGate:
    def check_strategy(self, strategy_id):
        return {"passed": True}


class PlaceholderKillSwitch:
    def __init__(self):
        self._tripped = False
        self.error_log = []
    def is_tripped(self):
        return self._tripped
    def trip(self, reason=""):
        self._tripped = True
        self.error_log.append(reason)
    def report_error(self, source, detail):
        self.error_log.append(f"{source}:{detail}")


class PlaceholderOrderManager:
    def submit(self, symbol, side, quantity, order_type, limit_price, broker):
        return {"broker_order_id": f"SIM-{symbol}-{side}-{quantity}"}
    def cancel(self, broker_order_id, broker):
        return True


class PlaceholderBrokerAdapter:
    name = "SIMULATED_BROKER"


class PlaceholderPortfolioManager:
    def __init__(self):
        self._positions = []
    def get_all_positions(self):
        return self._positions
    def set_positions(self, positions):
        self._positions = positions


# ---------------------------------------------------------------------------
# AI4Registry — the actual "registry mapping": one object holding every
# wired component, so any module (dashboard, scheduler) can pull what
# it needs from ONE place instead of re-wiring dependencies itself.
# ---------------------------------------------------------------------------

class AI4Registry:
    """Central wiring/registry for the whole AI-4 scope (09-19)."""

    def __init__(self, starting_capital: float = 1_000_000.0,
                 min_paper_trades: int = 30):
        # --- risk / validation / execution layer (placeholders) ---
        self.risk_engine = PlaceholderRiskEngine()
        self.exposure_manager = PlaceholderExposureManager()
        self.qa_gate = PlaceholderQAGate()
        self.kill_switch = PlaceholderKillSwitch()
        self.order_manager = PlaceholderOrderManager()
        self.broker_adapter = PlaceholderBrokerAdapter()
        self.portfolio_manager = PlaceholderPortfolioManager()

        # --- 16_paper_trading ---
        self.paper_account = PaperAccount(starting_capital=starting_capital)
        self.paper_engine = PaperEngine(account=self.paper_account)

        # --- 17_live_trading ---
        self.live_gate = LiveGate(
            risk_engine=self.risk_engine,
            exposure_manager=self.exposure_manager,
            qa_gate=self.qa_gate,
            min_paper_trades=min_paper_trades,
        )
        self.live_engine = LiveEngine(
            broker_adapter=self.broker_adapter,
            live_gate=self.live_gate,
            kill_switch=self.kill_switch,
            order_manager=self.order_manager,
        )

        # --- 18_accounting ---
        self.ledger = Ledger(opening_balance=starting_capital)
        self.trade_book = TradeBook()

        # --- 19_reporting ---
        self.performance_report_engine = PerformanceReportEngine()
        self.risk_report_engine = RiskReportEngine(
            exposure_manager=self.exposure_manager,
            risk_engine=self.risk_engine,
            portfolio_manager=self.portfolio_manager,
            kill_switch=self.kill_switch,
        )
        self.trade_report_engine = TradeReportEngine(self.trade_book)

    def health_check(self) -> dict:
        """Confirms every wired component responds — used at startup."""
        return {
            "paper_engine": self.paper_engine is not None,
            "live_engine": self.live_engine is not None,
            "live_gate": self.live_gate is not None,
            "ledger": self.ledger is not None,
            "trade_book": self.trade_book is not None,
            "performance_report_engine": self.performance_report_engine is not None,
            "risk_report_engine": self.risk_report_engine is not None,
            "trade_report_engine": self.trade_report_engine is not None,
            "kill_switch_tripped": self.kill_switch.is_tripped(),
        }


def build_registry(**kwargs) -> AI4Registry:
    """Factory used by 20_dashboard / 25_scheduler to get one fully-wired
    AI-4 registry instance."""
    return AI4Registry(**kwargs)


if __name__ == "__main__":
    registry = build_registry()
    status = registry.health_check()
    print("AI-4 REGISTRY WIRING CHECK")
    for k, v in status.items():
        print(f"  [{'OK' if v is True or v is False and k=='kill_switch_tripped' else 'OK'}] {k}: {v}")
    print("\nAll AI-4 components (09-19 scope) wired successfully.")
