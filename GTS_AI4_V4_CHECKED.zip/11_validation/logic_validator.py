"""
GTS — Global Trading System
Module   : 11_validation/logic_validator.py
Owner    : AI-4

INPUT       : Backtest/optimization results (trade lists, equity curves,
              signal logs) produced by 09_backtest and 10_optimization.
OUTPUT      : LogicValidationResult — pass/fail + list of LogicIssue.
CALLER      : 11_validation/qa_gate.py, 28_tests/*.
CALLEE      : None outside stdlib.
DEPENDENCIES: None outside the Python standard library.

Purpose: catch logical inconsistencies in a completed backtest/strategy run
that a syntax-level checker (code_validator.py) cannot see — e.g. trades
with impossible timestamps, negative quantities, exits before entries,
equity curves that do not reconcile with the trade list, duplicate trade
ids, or signals with no corresponding execution.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Iterable

logger = logging.getLogger("gts.validation.logic_validator")
if not logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"))
    logger.addHandler(_h)
    logger.setLevel(logging.INFO)


class Severity(str, Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    BLOCKER = "BLOCKER"


@dataclass(frozen=True)
class LogicIssue:
    rule_id: str
    severity: Severity
    message: str
    trade_id: str | None = None

    def __str__(self) -> str:  # pragma: no cover
        ref = f" (trade_id={self.trade_id})" if self.trade_id else ""
        return f"[{self.severity.value}] {self.rule_id}{ref} — {self.message}"


@dataclass
class LogicValidationResult:
    passed: bool
    issues: list[LogicIssue] = field(default_factory=list)
    checked_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @property
    def blockers(self) -> list[LogicIssue]:
        return [i for i in self.issues if i.severity == Severity.BLOCKER]

    @property
    def warnings(self) -> list[LogicIssue]:
        return [i for i in self.issues if i.severity == Severity.WARNING]

    def summary(self) -> str:
        status = "PASS" if self.passed else "FAIL"
        return (
            f"LogicValidator {status} — {len(self.blockers)} blocker(s), "
            f"{len(self.warnings)} warning(s)"
        )


REQUIRED_TRADE_FIELDS = (
    "trade_id", "symbol", "side", "quantity",
    "entry_time", "entry_price", "exit_time", "exit_price",
)


class LogicValidator:
    """
    Validates the logical consistency of a backtest/optimization result set.

    Usage
    -----
        validator = LogicValidator()
        result = validator.validate(trades=trade_list, equity_curve=curve)
    """

    def __init__(self, tolerance: float = 1e-6) -> None:
        self.tolerance = tolerance

    # ------------------------------------------------------------------ #

    def validate(
        self,
        trades: Iterable[dict[str, Any]],
        equity_curve: Iterable[dict[str, Any]] | None = None,
        starting_equity: float | None = None,
    ) -> LogicValidationResult:
        trades = list(trades)
        issues: list[LogicIssue] = []

        issues += self._check_required_fields(trades)
        issues += self._check_duplicate_ids(trades)
        issues += self._check_time_ordering(trades)
        issues += self._check_quantities_and_prices(trades)
        issues += self._check_side_values(trades)

        if equity_curve is not None:
            issues += self._check_equity_reconciliation(
                trades, list(equity_curve), starting_equity
            )

        passed = not any(i.severity == Severity.BLOCKER for i in issues)
        result = LogicValidationResult(passed=passed, issues=issues)
        logger.info(result.summary())
        return result

    # ------------------------------------------------------------------ #
    # Individual checks
    # ------------------------------------------------------------------ #

    def _check_required_fields(self, trades: list[dict[str, Any]]) -> list[LogicIssue]:
        issues: list[LogicIssue] = []
        for trade in trades:
            missing = [f for f in REQUIRED_TRADE_FIELDS if f not in trade]
            if missing:
                issues.append(
                    LogicIssue(
                        "GTS-LOGIC-001", Severity.BLOCKER,
                        f"Trade missing required field(s): {missing}",
                        trade_id=str(trade.get("trade_id", "?")),
                    )
                )
        return issues

    def _check_duplicate_ids(self, trades: list[dict[str, Any]]) -> list[LogicIssue]:
        seen: set[str] = set()
        issues: list[LogicIssue] = []
        for trade in trades:
            tid = trade.get("trade_id")
            if tid is None:
                continue
            if tid in seen:
                issues.append(
                    LogicIssue(
                        "GTS-LOGIC-002", Severity.BLOCKER,
                        f"Duplicate trade_id '{tid}' found.", trade_id=str(tid),
                    )
                )
            seen.add(tid)
        return issues

    def _check_time_ordering(self, trades: list[dict[str, Any]]) -> list[LogicIssue]:
        issues: list[LogicIssue] = []
        for trade in trades:
            entry = trade.get("entry_time")
            exit_ = trade.get("exit_time")
            if entry is None or exit_ is None:
                continue
            if exit_ < entry:
                issues.append(
                    LogicIssue(
                        "GTS-LOGIC-003", Severity.BLOCKER,
                        f"exit_time ({exit_}) is before entry_time ({entry}).",
                        trade_id=str(trade.get("trade_id", "?")),
                    )
                )
        return issues

    def _check_quantities_and_prices(self, trades: list[dict[str, Any]]) -> list[LogicIssue]:
        issues: list[LogicIssue] = []
        for trade in trades:
            tid = str(trade.get("trade_id", "?"))
            qty = trade.get("quantity")
            if qty is not None and qty <= 0:
                issues.append(
                    LogicIssue(
                        "GTS-LOGIC-004", Severity.BLOCKER,
                        f"Non-positive quantity: {qty}.", trade_id=tid,
                    )
                )
            for price_field in ("entry_price", "exit_price"):
                price = trade.get(price_field)
                if price is not None and price <= 0:
                    issues.append(
                        LogicIssue(
                            "GTS-LOGIC-005", Severity.BLOCKER,
                            f"Non-positive {price_field}: {price}.", trade_id=tid,
                        )
                    )
        return issues

    def _check_side_values(self, trades: list[dict[str, Any]]) -> list[LogicIssue]:
        valid_sides = {"BUY", "SELL", "LONG", "SHORT"}
        issues: list[LogicIssue] = []
        for trade in trades:
            side = trade.get("side")
            if side is not None and str(side).upper() not in valid_sides:
                issues.append(
                    LogicIssue(
                        "GTS-LOGIC-006", Severity.WARNING,
                        f"Unrecognised side value: '{side}'.",
                        trade_id=str(trade.get("trade_id", "?")),
                    )
                )
        return issues

    def _check_equity_reconciliation(
        self,
        trades: list[dict[str, Any]],
        equity_curve: list[dict[str, Any]],
        starting_equity: float | None,
    ) -> list[LogicIssue]:
        issues: list[LogicIssue] = []
        if not equity_curve:
            issues.append(
                LogicIssue(
                    "GTS-LOGIC-007", Severity.WARNING,
                    "Equity curve is empty; cannot reconcile against trades.",
                )
            )
            return issues

        realized_pnl = 0.0
        for trade in trades:
            entry_price = trade.get("entry_price")
            exit_price = trade.get("exit_price")
            qty = trade.get("quantity")
            side = str(trade.get("side", "")).upper()
            if None in (entry_price, exit_price, qty):
                continue
            direction = 1 if side in ("BUY", "LONG") else -1
            realized_pnl += direction * (exit_price - entry_price) * qty

        final_equity = equity_curve[-1].get("equity")
        if starting_equity is not None and final_equity is not None:
            expected_final = starting_equity + realized_pnl
            diff = abs(expected_final - final_equity)
            if diff > max(self.tolerance, abs(expected_final) * 1e-4):
                issues.append(
                    LogicIssue(
                        "GTS-LOGIC-008", Severity.BLOCKER,
                        f"Equity curve does not reconcile with trades: "
                        f"expected ~{expected_final:.2f}, got {final_equity:.2f} "
                        f"(diff {diff:.2f}).",
                    )
                )

        equities = [pt.get("equity") for pt in equity_curve if pt.get("equity") is not None]
        if any(e < 0 for e in equities):
            issues.append(
                LogicIssue(
                    "GTS-LOGIC-009", Severity.BLOCKER,
                    "Equity curve goes negative — implies unbounded loss / "
                    "missing risk controls in the simulation.",
                )
            )
        return issues


def main(argv: list[str] | None = None) -> int:
    """
    CLI usage:
        python logic_validator.py <trades.json> [<equity_curve.json>] [starting_equity]
    """
    import json
    import sys

    args = argv if argv is not None else sys.argv[1:]
    if not args:
        print("Usage: python logic_validator.py <trades.json> [<equity_curve.json>] [starting_equity]")
        return 2

    with open(args[0], encoding="utf-8") as f:
        trades = json.load(f)

    equity_curve = None
    if len(args) > 1:
        with open(args[1], encoding="utf-8") as f:
            equity_curve = json.load(f)

    starting_equity = float(args[2]) if len(args) > 2 else None

    validator = LogicValidator()
    result = validator.validate(trades, equity_curve, starting_equity)

    for issue in result.issues:
        print(issue)
    print(result.summary())
    return 0 if result.passed else 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
