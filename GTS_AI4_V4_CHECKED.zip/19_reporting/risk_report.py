"""
risk_report.py
===============
MODULE   : 19_reporting
OWNER    : AI-4
PURPOSE  : Produces point-in-time and historical risk exposure reports —
           position concentration, leverage, VaR, exposure vs limits —
           pulling live state from 12_risk and 13_portfolio.

INPUT    : Current positions, risk limits, historical returns
OUTPUT   : RiskReport object for dashboard / audit / owner review
CALLER   : 20_dashboard, 27_system (scheduled audit jobs)
CALLEE   : 12_risk.risk_engine, 12_risk.exposure_manager,
           13_portfolio.portfolio_manager
DEPENDS  : risk_engine, exposure_manager, portfolio_manager
"""

from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class PositionRisk:
    symbol: str
    quantity: float
    market_value: float
    exposure_pct: float
    unrealized_pnl: float


@dataclass
class RiskReport:
    total_exposure: float = 0.0
    net_exposure: float = 0.0
    gross_exposure: float = 0.0
    leverage: float = 0.0
    largest_position_pct: float = 0.0
    value_at_risk_95: Optional[float] = None
    limit_breaches: List[str] = field(default_factory=list)
    positions: List[PositionRisk] = field(default_factory=list)
    kill_switch_active: bool = False


class RiskReportEngine:

    def __init__(self, exposure_manager, risk_engine, portfolio_manager, kill_switch=None):
        self.exposure_manager = exposure_manager
        self.risk_engine = risk_engine
        self.portfolio_manager = portfolio_manager
        self.kill_switch = kill_switch

    def _historical_var(self, returns: List[float], confidence: float = 0.95) -> Optional[float]:
        if not returns:
            return None
        sorted_r = sorted(returns)
        index = int((1 - confidence) * len(sorted_r))
        index = max(0, min(index, len(sorted_r) - 1))
        return abs(sorted_r[index])

    def generate(self, account_equity: float, historical_returns: Optional[List[float]] = None) -> RiskReport:
        report = RiskReport()
        positions = self.portfolio_manager.get_all_positions()  # expects list of dict-like

        gross = 0.0
        net = 0.0
        pos_risks: List[PositionRisk] = []

        for pos in positions:
            market_value = pos["quantity"] * pos["last_price"]
            gross += abs(market_value)
            net += market_value
            exposure_pct = (abs(market_value) / account_equity) if account_equity else 0.0
            unrealized = (pos["last_price"] - pos["avg_price"]) * pos["quantity"]
            pos_risks.append(PositionRisk(
                symbol=pos["symbol"], quantity=pos["quantity"], market_value=market_value,
                exposure_pct=exposure_pct, unrealized_pnl=unrealized,
            ))

        report.positions = pos_risks
        report.gross_exposure = gross
        report.net_exposure = net
        report.total_exposure = gross
        report.leverage = (gross / account_equity) if account_equity else 0.0
        report.largest_position_pct = max((p.exposure_pct for p in pos_risks), default=0.0)

        if historical_returns:
            report.value_at_risk_95 = self._historical_var(historical_returns, 0.95)

        breach_check = self.exposure_manager.check_all(positions, account_equity)
        report.limit_breaches = breach_check.get("breaches", [])

        if self.kill_switch is not None:
            report.kill_switch_active = self.kill_switch.is_tripped()

        return report
