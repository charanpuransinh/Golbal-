"""
GTS — Global Trading System
Module   : 11_validation/data_validator.py
Owner    : AI-4

INPUT       : Market data records (OHLCV bars, tick data, options chain
              snapshots) from 01_market_data / 03_data_engine.
OUTPUT      : DataValidationResult — pass/fail + list of DataIssue.
CALLER      : 09_backtest (before feeding data into event_engine.py),
              11_validation/qa_gate.py.
CALLEE      : None outside stdlib.
DEPENDENCIES: None outside the Python standard library.

Purpose: guarantee that market data fed into backtest/live engines is
clean — no gaps beyond tolerance, no negative/zero prices, no OHLC
violations (high < low, close outside high/low range), no duplicate or
out-of-order timestamps, no NaN/None values.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Iterable

logger = logging.getLogger("gts.validation.data_validator")
if not logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"))
    logger.addHandler(_h)
    logger.setLevel(logging.INFO)


class Severity(str, Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    BLOCKER = "BLOCKER"


@dataclass(frozen=True)
class DataIssue:
    rule_id: str
    severity: Severity
    message: str
    index: int | None = None
    timestamp: Any = None

    def __str__(self) -> str:  # pragma: no cover
        ref = ""
        if self.index is not None:
            ref = f" (row={self.index}"
            ref += f", ts={self.timestamp})" if self.timestamp is not None else ")"
        return f"[{self.severity.value}] {self.rule_id}{ref} — {self.message}"


@dataclass
class DataValidationResult:
    passed: bool
    issues: list[DataIssue] = field(default_factory=list)
    rows_checked: int = 0
    checked_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @property
    def blockers(self) -> list[DataIssue]:
        return [i for i in self.issues if i.severity == Severity.BLOCKER]

    @property
    def warnings(self) -> list[DataIssue]:
        return [i for i in self.issues if i.severity == Severity.WARNING]

    def summary(self) -> str:
        status = "PASS" if self.passed else "FAIL"
        return (
            f"DataValidator {status} — {self.rows_checked} row(s) checked, "
            f"{len(self.blockers)} blocker(s), {len(self.warnings)} warning(s)"
        )


REQUIRED_OHLCV_FIELDS = ("timestamp", "open", "high", "low", "close", "volume")


class DataValidator:
    """
    Validates OHLCV market-data series before use in backtest/live engines.

    Usage
    -----
        validator = DataValidator(expected_interval_seconds=60)
        result = validator.validate(bars)
    """

    def __init__(
        self,
        expected_interval_seconds: float | None = None,
        gap_tolerance_multiplier: float = 3.0,
        max_price_jump_pct: float = 0.20,
    ) -> None:
        self.expected_interval_seconds = expected_interval_seconds
        self.gap_tolerance_multiplier = gap_tolerance_multiplier
        self.max_price_jump_pct = max_price_jump_pct

    # ------------------------------------------------------------------ #

    def validate(self, bars: Iterable[dict[str, Any]]) -> DataValidationResult:
        bars = list(bars)
        issues: list[DataIssue] = []

        issues += self._check_required_fields(bars)
        issues += self._check_nan_none(bars)
        issues += self._check_positive_prices(bars)
        issues += self._check_ohlc_consistency(bars)
        issues += self._check_timestamp_order(bars)
        issues += self._check_gaps(bars)
        issues += self._check_price_jumps(bars)
        issues += self._check_volume(bars)

        passed = not any(i.severity == Severity.BLOCKER for i in issues)
        result = DataValidationResult(passed=passed, issues=issues, rows_checked=len(bars))
        logger.info(result.summary())
        return result

    # ------------------------------------------------------------------ #
    # Individual checks
    # ------------------------------------------------------------------ #

    def _check_required_fields(self, bars: list[dict[str, Any]]) -> list[DataIssue]:
        issues: list[DataIssue] = []
        for i, bar in enumerate(bars):
            missing = [f for f in REQUIRED_OHLCV_FIELDS if f not in bar]
            if missing:
                issues.append(
                    DataIssue(
                        "GTS-DATA-001", Severity.BLOCKER,
                        f"Bar missing required field(s): {missing}", index=i,
                    )
                )
        return issues

    def _check_nan_none(self, bars: list[dict[str, Any]]) -> list[DataIssue]:
        issues: list[DataIssue] = []
        for i, bar in enumerate(bars):
            for field_name in REQUIRED_OHLCV_FIELDS:
                val = bar.get(field_name)
                if val is None:
                    issues.append(
                        DataIssue(
                            "GTS-DATA-002", Severity.BLOCKER,
                            f"Field '{field_name}' is None.", index=i,
                            timestamp=bar.get("timestamp"),
                        )
                    )
                elif isinstance(val, float) and math.isnan(val):
                    issues.append(
                        DataIssue(
                            "GTS-DATA-003", Severity.BLOCKER,
                            f"Field '{field_name}' is NaN.", index=i,
                            timestamp=bar.get("timestamp"),
                        )
                    )
        return issues

    def _check_positive_prices(self, bars: list[dict[str, Any]]) -> list[DataIssue]:
        issues: list[DataIssue] = []
        for i, bar in enumerate(bars):
            for field_name in ("open", "high", "low", "close"):
                val = bar.get(field_name)
                if isinstance(val, (int, float)) and val <= 0:
                    issues.append(
                        DataIssue(
                            "GTS-DATA-004", Severity.BLOCKER,
                            f"Non-positive {field_name}: {val}.", index=i,
                            timestamp=bar.get("timestamp"),
                        )
                    )
        return issues

    def _check_ohlc_consistency(self, bars: list[dict[str, Any]]) -> list[DataIssue]:
        issues: list[DataIssue] = []
        for i, bar in enumerate(bars):
            o, h, l, c = bar.get("open"), bar.get("high"), bar.get("low"), bar.get("close")
            if None in (o, h, l, c):
                continue
            if h < l:
                issues.append(
                    DataIssue(
                        "GTS-DATA-005", Severity.BLOCKER,
                        f"high ({h}) < low ({l}).", index=i, timestamp=bar.get("timestamp"),
                    )
                )
                continue
            if not (l <= o <= h):
                issues.append(
                    DataIssue(
                        "GTS-DATA-006", Severity.BLOCKER,
                        f"open ({o}) outside [low={l}, high={h}].", index=i,
                        timestamp=bar.get("timestamp"),
                    )
                )
            if not (l <= c <= h):
                issues.append(
                    DataIssue(
                        "GTS-DATA-007", Severity.BLOCKER,
                        f"close ({c}) outside [low={l}, high={h}].", index=i,
                        timestamp=bar.get("timestamp"),
                    )
                )
        return issues

    def _check_timestamp_order(self, bars: list[dict[str, Any]]) -> list[DataIssue]:
        issues: list[DataIssue] = []
        seen_ts: set[Any] = set()
        prev_ts = None
        for i, bar in enumerate(bars):
            ts = bar.get("timestamp")
            if ts is None:
                continue
            if ts in seen_ts:
                issues.append(
                    DataIssue(
                        "GTS-DATA-008", Severity.BLOCKER,
                        f"Duplicate timestamp {ts}.", index=i, timestamp=ts,
                    )
                )
            seen_ts.add(ts)
            if prev_ts is not None and ts < prev_ts:
                issues.append(
                    DataIssue(
                        "GTS-DATA-009", Severity.BLOCKER,
                        f"Timestamp out of order: {ts} follows {prev_ts}.",
                        index=i, timestamp=ts,
                    )
                )
            prev_ts = ts
        return issues

    def _check_gaps(self, bars: list[dict[str, Any]]) -> list[DataIssue]:
        issues: list[DataIssue] = []
        if self.expected_interval_seconds is None:
            return issues
        threshold = timedelta(seconds=self.expected_interval_seconds * self.gap_tolerance_multiplier)
        prev_dt = None
        for i, bar in enumerate(bars):
            ts = bar.get("timestamp")
            dt = self._to_datetime(ts)
            if dt is None:
                continue
            if prev_dt is not None and (dt - prev_dt) > threshold:
                issues.append(
                    DataIssue(
                        "GTS-DATA-010", Severity.WARNING,
                        f"Gap of {(dt - prev_dt)} exceeds tolerance "
                        f"({threshold}).", index=i, timestamp=ts,
                    )
                )
            prev_dt = dt
        return issues

    def _check_price_jumps(self, bars: list[dict[str, Any]]) -> list[DataIssue]:
        issues: list[DataIssue] = []
        prev_close = None
        for i, bar in enumerate(bars):
            close = bar.get("close")
            if isinstance(close, (int, float)) and prev_close:
                pct_change = abs(close - prev_close) / prev_close
                if pct_change > self.max_price_jump_pct:
                    issues.append(
                        DataIssue(
                            "GTS-DATA-011", Severity.WARNING,
                            f"Close moved {pct_change:.1%} from previous bar "
                            f"(limit {self.max_price_jump_pct:.1%}) — possible "
                            f"bad tick or corporate action.",
                            index=i, timestamp=bar.get("timestamp"),
                        )
                    )
            if isinstance(close, (int, float)):
                prev_close = close
        return issues

    def _check_volume(self, bars: list[dict[str, Any]]) -> list[DataIssue]:
        issues: list[DataIssue] = []
        for i, bar in enumerate(bars):
            vol = bar.get("volume")
            if isinstance(vol, (int, float)) and vol < 0:
                issues.append(
                    DataIssue(
                        "GTS-DATA-012", Severity.BLOCKER,
                        f"Negative volume: {vol}.", index=i, timestamp=bar.get("timestamp"),
                    )
                )
        return issues

    @staticmethod
    def _to_datetime(ts: Any) -> datetime | None:
        if isinstance(ts, datetime):
            return ts
        if isinstance(ts, (int, float)):
            try:
                return datetime.fromtimestamp(ts, tz=timezone.utc)
            except (OverflowError, OSError, ValueError):
                return None
        if isinstance(ts, str):
            try:
                return datetime.fromisoformat(ts)
            except ValueError:
                return None
        return None


def main(argv: list[str] | None = None) -> int:
    """
    CLI usage:
        python data_validator.py <bars.json> [expected_interval_seconds]
    """
    import json
    import sys

    args = argv if argv is not None else sys.argv[1:]
    if not args:
        print("Usage: python data_validator.py <bars.json> [expected_interval_seconds]")
        return 2

    with open(args[0], encoding="utf-8") as f:
        bars = json.load(f)

    interval = float(args[1]) if len(args) > 1 else None
    validator = DataValidator(expected_interval_seconds=interval)
    result = validator.validate(bars)

    for issue in result.issues:
        print(issue)
    print(result.summary())
    return 0 if result.passed else 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
