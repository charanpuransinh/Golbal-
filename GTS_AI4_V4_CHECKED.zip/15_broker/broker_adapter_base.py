"""
GTS — Global Trading System
Module   : 15_broker/broker_adapter_base.py
Owner    : AI-4

INPUT       : Orders from 14_execution/execution_engine.py.
OUTPUT      : BrokerFillResponse (fill/rejection) back to execution_engine.py;
              raw account/position data for reconciliation.
CALLER      : 14_execution/execution_engine.py (only ever through this
              interface — never a concrete subclass directly), 15_broker
              (concrete adapters subclass this).
CALLEE       : None outside stdlib (concrete subclasses will call out to
              actual broker SDKs/APIs — this base module intentionally
              has zero network dependencies).
DEPENDENCIES: Standard library only.

Purpose: define the single abstract contract every broker integration in
GTS must satisfy. This is what makes GTS broker-independent (Master
Blueprint section 1: "broker-independent ... platform") — swapping
brokers means writing one new subclass here, with zero changes to
14_execution or anything upstream of it.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum


class ConnectionStatus(str, Enum):
    DISCONNECTED = "DISCONNECTED"
    CONNECTING = "CONNECTING"
    CONNECTED = "CONNECTED"
    ERROR = "ERROR"


@dataclass(frozen=True)
class BrokerOrderRequest:
    """The minimal order shape every adapter must accept.
    Matches the fields execution_engine.py's OrderLike Protocol provides."""
    order_id: str
    symbol: str
    side: str
    quantity: float
    order_type: str = "MARKET"
    limit_price: float | None = None
    stop_price: float | None = None


@dataclass(frozen=True)
class BrokerFillResponse:
    """Must mirror 14_execution/execution_engine.py's BrokerFillResponse
    shape exactly — duplicated here (rather than imported) so 15_broker
    has zero import-time dependency on 14_execution, keeping the
    dependency direction one-way (execution depends on broker, not the
    reverse)."""
    status: str                       # FILLED / PARTIALLY_FILLED / REJECTED / ERROR
    filled_quantity: float
    average_fill_price: float
    broker_order_id: str = ""
    message: str = ""


@dataclass(frozen=True)
class BrokerPosition:
    symbol: str
    quantity: float
    average_price: float


@dataclass
class BrokerHealth:
    status: ConnectionStatus
    last_heartbeat_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    message: str = ""

    @property
    def is_healthy(self) -> bool:
        return self.status == ConnectionStatus.CONNECTED


class TransientBrokerError(Exception):
    """Retryable failure (timeout, connectivity blip). Matches the type
    execution_engine.py catches for its retry loop — concrete adapters
    should raise this (not a broker-SDK-specific exception) for anything
    execution_engine.py should retry."""


class BrokerAuthenticationError(Exception):
    """Fatal — credentials invalid/expired. Never retried automatically."""


class BrokerAdapterBase(ABC):
    """
    Abstract base every concrete broker integration must subclass.

    Concrete subclasses live in 15_broker/ (e.g. broker_adapter_zerodha.py,
    broker_adapter_ibkr.py — not created by AI-4; strategy/broker-specific
    adapters are added by whichever team owns that integration) and are
    looked up via broker_registry.py.

    Usage
    -----
        class MyBroker(BrokerAdapterBase):
            def connect(self): ...
            def disconnect(self): ...
            def submit_order(self, order): ...
            def cancel_order(self, broker_order_id): ...
            def get_positions(self): ...
            def health_check(self): ...
    """

    def __init__(self, name: str) -> None:
        self.name = name

    # ------------------------------------------------------------------ #
    # Required interface — every concrete adapter must implement all of these.
    # ------------------------------------------------------------------ #

    @abstractmethod
    def connect(self) -> None:
        """Establish the broker connection/session. Raise
        BrokerAuthenticationError on invalid credentials."""
        raise NotImplementedError

    @abstractmethod
    def disconnect(self) -> None:
        """Cleanly close the broker connection/session."""
        raise NotImplementedError

    @abstractmethod
    def submit_order(self, order: BrokerOrderRequest) -> BrokerFillResponse:
        """
        Submit an order. Must raise TransientBrokerError for anything
        retryable (timeouts, rate limits, connectivity blips) — any other
        exception is treated by execution_engine.py as fatal/non-retryable.
        """
        raise NotImplementedError

    @abstractmethod
    def cancel_order(self, broker_order_id: str) -> bool:
        """Cancel a previously submitted order. Returns True if cancelled."""
        raise NotImplementedError

    @abstractmethod
    def get_positions(self) -> list[BrokerPosition]:
        """Fetch current broker-side positions, for reconciliation against
        13_portfolio's internally tracked book."""
        raise NotImplementedError

    @abstractmethod
    def health_check(self) -> BrokerHealth:
        """Report current connection health, used by 17_live_trading's
        live_gate.py before allowing live order flow."""
        raise NotImplementedError

    # ------------------------------------------------------------------ #
    # Shared, non-overridable convenience behaviour.
    # ------------------------------------------------------------------ #

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"<{self.__class__.__name__} name={self.name!r}>"


class _NullBroker(BrokerAdapterBase):
    """
    Reference/no-op implementation, used for tests and dry runs. Not a
    real integration — every call is a deterministic, harmless stub.
    """

    def __init__(self) -> None:
        super().__init__(name="null_broker")
        self._connected = False

    def connect(self) -> None:
        self._connected = True

    def disconnect(self) -> None:
        self._connected = False

    def submit_order(self, order: BrokerOrderRequest) -> BrokerFillResponse:
        if not self._connected:
            raise TransientBrokerError("Not connected.")
        return BrokerFillResponse(
            status="FILLED",
            filled_quantity=order.quantity,
            average_fill_price=order.limit_price or 0.0,
            broker_order_id=f"NULL-{order.order_id}",
            message="filled by null broker",
        )

    def cancel_order(self, broker_order_id: str) -> bool:
        return True

    def get_positions(self) -> list[BrokerPosition]:
        return []

    def health_check(self) -> BrokerHealth:
        status = ConnectionStatus.CONNECTED if self._connected else ConnectionStatus.DISCONNECTED
        return BrokerHealth(status=status)


def main(argv: list[str] | None = None) -> int:
    """CLI smoke-test: python broker_adapter_base.py"""
    broker = _NullBroker()
    print(broker.health_check())
    broker.connect()
    print(broker.health_check())
    response = broker.submit_order(
        BrokerOrderRequest(order_id="ORD-1", symbol="NIFTY", side="BUY", quantity=50, limit_price=20000)
    )
    print(response)
    broker.disconnect()
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
