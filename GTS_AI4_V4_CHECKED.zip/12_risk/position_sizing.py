"""
GTS — Global Trading System
Module   : 12_risk/position_sizing.py
Owner    : AI-4

INPUT       : Requested order quantity, optional volatility/confidence
              inputs for adaptive sizing.
OUTPUT      : SizingResult — approved quantity (capped) + explanation.
CALLER      : 12_risk/risk_engine.py.
CALLEE      : None outside stdlib.
DEPENDENCIES: Standard library only.

Purpose: enforce per-order position-size limits and provide optional
volatility-adjusted / fixed-fractional sizing so that no single order can
exceed configured bounds regardless of what a strategy requests.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class SizingResult:
    approved_quantity: float
    requested_quantity: float
    was_capped: bool
    message: str = ""
    evaluated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class PositionSizer:
    """
    Caps and (optionally) computes position size.

    Usage
    -----
        sizer = PositionSizer(max_position_size=100)
        result = sizer.size(requested_quantity=250)
        # result.approved_quantity == 100, result.was_capped == True
    """

    def __init__(self, max_position_size: float, min_position_size: float = 0.0) -> None:
        if max_position_size <= 0:
            raise ValueError("max_position_size must be positive.")
        if min_position_size < 0:
            raise ValueError("min_position_size cannot be negative.")
        self.max_position_size = max_position_size
        self.min_position_size = min_position_size

    # ------------------------------------------------------------------ #

    def size(self, requested_quantity: float) -> SizingResult:
        """Cap a raw requested quantity to the configured hard limit."""
        if requested_quantity < 0:
            return SizingResult(
                approved_quantity=0.0,
                requested_quantity=requested_quantity,
                was_capped=True,
                message=f"Negative requested quantity {requested_quantity} rejected.",
            )

        approved = min(requested_quantity, self.max_position_size)
        if 0 < approved < self.min_position_size:
            return SizingResult(
                approved_quantity=0.0,
                requested_quantity=requested_quantity,
                was_capped=True,
                message=(
                    f"Requested quantity {requested_quantity} below minimum "
                    f"tradable size {self.min_position_size}."
                ),
            )

        was_capped = approved != requested_quantity
        message = (
            f"Quantity capped from {requested_quantity} to {approved} "
            f"(max_position_size={self.max_position_size})."
            if was_capped else ""
        )
        return SizingResult(
            approved_quantity=approved,
            requested_quantity=requested_quantity,
            was_capped=was_capped,
            message=message,
        )

    def fixed_fractional(
        self,
        equity: float,
        risk_per_trade_pct: float,
        entry_price: float,
        stop_price: float,
    ) -> SizingResult:
        """
        Fixed-fractional sizing: risk a fixed % of equity per trade, based
        on distance between entry and stop. Result is still capped by
        size() before being returned.
        """
        if entry_price == stop_price:
            return SizingResult(
                approved_quantity=0.0,
                requested_quantity=0.0,
                was_capped=True,
                message="entry_price equals stop_price — cannot size (zero risk-per-unit).",
            )

        risk_amount = equity * risk_per_trade_pct
        risk_per_unit = abs(entry_price - stop_price)
        raw_quantity = risk_amount / risk_per_unit
        result = self.size(raw_quantity)
        result.message = (
            f"Fixed-fractional sizing: risk_amount={risk_amount:.2f}, "
            f"risk_per_unit={risk_per_unit:.4f} -> raw_qty={raw_quantity:.4f}. "
            + result.message
        ).strip()
        return result


def main(argv: list[str] | None = None) -> int:
    """CLI smoke-test: python position_sizing.py"""
    sizer = PositionSizer(max_position_size=100)
    print(sizer.size(250))
    print(sizer.fixed_fractional(equity=100_000, risk_per_trade_pct=0.01, entry_price=100, stop_price=98))
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
