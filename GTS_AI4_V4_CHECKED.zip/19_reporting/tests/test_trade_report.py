"""
test_trade_report.py
MODULE: 19_reporting (tests)
OWNER : AI-4
Covers: report generation from trade_book, per-strategy/symbol summaries, CSV export.
"""

import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..",
                                                  "18_accounting")))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from trade_book import TradeBook
from trade_report import TradeReportEngine


def _sample_book():
    book = TradeBook()
    book.open_trade("NIFTY", "S1", "LONG", entry_price=100, entry_qty=10)
    book.close_trade("NIFTY", "S1", exit_price=110, exit_qty=10)
    book.open_trade("GOLD", "S2", "LONG", entry_price=50, entry_qty=2)
    book.close_trade("GOLD", "S2", exit_price=45, exit_qty=2)
    return book


def test_report_row_count_matches_closed_trades():
    engine = TradeReportEngine(_sample_book())
    report = engine.generate()
    assert len(report.rows) == 2


def test_summary_by_strategy():
    engine = TradeReportEngine(_sample_book())
    report = engine.generate()
    assert report.summary_by_strategy["S1"]["pnl"] == 100
    assert report.summary_by_strategy["S2"]["pnl"] == -10


def test_summary_by_symbol():
    engine = TradeReportEngine(_sample_book())
    report = engine.generate()
    assert "NIFTY" in report.summary_by_symbol
    assert "GOLD" in report.summary_by_symbol


def test_filter_by_strategy_id():
    engine = TradeReportEngine(_sample_book())
    report = engine.generate(strategy_id="S1")
    assert len(report.rows) == 1
    assert report.rows[0].symbol == "NIFTY"


def test_csv_export_has_header_and_rows():
    engine = TradeReportEngine(_sample_book())
    report = engine.generate()
    csv_text = engine.to_csv(report)
    lines = csv_text.strip().split("\n")
    assert lines[0].startswith("trade_id,symbol")
    assert len(lines) == 3  # header + 2 trades


if __name__ == "__main__":
    test_report_row_count_matches_closed_trades()
    test_summary_by_strategy()
    test_summary_by_symbol()
    test_filter_by_strategy_id()
    test_csv_export_has_header_and_rows()
    print("trade_report: ALL TESTS PASSED")
