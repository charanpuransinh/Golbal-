"""
performance_report.py
======================
MODULE   : 19_reporting
OWNER    : AI-4
PURPOSE  : Computes standard strategy/account performance metrics
           (returns, Sharpe, drawdown, win rate, profit factor) from
           closed trades and equity curve data.

INPUT    : TradeRecord list (18_accounting.trade_book), equity curve series
OUTPUT   : PerformanceReport dict/object, ready for dashboard or export
CALLER   : 20_dashboard, 19_reporting (aggregation), owner review
CALLEE   : 18_accounting.trade_book
DEPENDS  : trade_book
"""

from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class PerformanceReport:
    total_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    win_rate: float = 0.0
    gross_profit: float = 0.0
    gross_loss: float = 0.0
    profit_factor: float = 0.0
    total_pnl: float = 0.0
    avg_win: float = 0.0
    avg_loss: float = 0.0
    largest_win: float = 0.0
    largest_loss: float = 0.0
    max_drawdown: float = 0.0
    max_drawdown_pct: float = 0.0
    sharpe_ratio: Optional[float] = None
    sortino_ratio: Optional[float] = None
    cagr: Optional[float] = None
    extra: Dict = field(default_factory=dict)


class PerformanceReportEngine:

    def __init__(self, risk_free_rate: float = 0.0, periods_per_year: int = 252):
        self.risk_free_rate = risk_free_rate
        self.periods_per_year = periods_per_year

    def from_trades(self, trades: List) -> PerformanceReport:
        report = PerformanceReport()
        if not trades:
            return report

        pnls = [t.realized_pnl for t in trades]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p < 0]

        report.total_trades = len(pnls)
        report.winning_trades = len(wins)
        report.losing_trades = len(losses)
        report.win_rate = len(wins) / len(pnls) if pnls else 0.0
        report.gross_profit = sum(wins)
        report.gross_loss = abs(sum(losses))
        report.profit_factor = (
            report.gross_profit / report.gross_loss if report.gross_loss > 0 else float("inf")
        )
        report.total_pnl = sum(pnls)
        report.avg_win = (sum(wins) / len(wins)) if wins else 0.0
        report.avg_loss = (sum(losses) / len(losses)) if losses else 0.0
        report.largest_win = max(wins) if wins else 0.0
        report.largest_loss = min(losses) if losses else 0.0
        return report

    def with_equity_curve(self, report: PerformanceReport, equity_curve: List[float]) -> PerformanceReport:
        """Adds drawdown, Sharpe, Sortino, CAGR from an equity curve series."""
        if len(equity_curve) < 2:
            return report

        peak = equity_curve[0]
        max_dd = 0.0
        max_dd_pct = 0.0
        for value in equity_curve:
            peak = max(peak, value)
            dd = peak - value
            dd_pct = (dd / peak) if peak > 0 else 0.0
            max_dd = max(max_dd, dd)
            max_dd_pct = max(max_dd_pct, dd_pct)
        report.max_drawdown = max_dd
        report.max_drawdown_pct = max_dd_pct

        returns = [
            (equity_curve[i] / equity_curve[i - 1]) - 1.0
            for i in range(1, len(equity_curve)) if equity_curve[i - 1] != 0
        ]
        if returns:
            mean_r = sum(returns) / len(returns)
            variance = sum((r - mean_r) ** 2 for r in returns) / len(returns)
            std_r = math.sqrt(variance)
            downside = [r for r in returns if r < 0]
            downside_var = (sum(r ** 2 for r in downside) / len(downside)) if downside else 0.0
            downside_std = math.sqrt(downside_var)

            if std_r > 0:
                report.sharpe_ratio = (
                    (mean_r - self.risk_free_rate / self.periods_per_year) / std_r
                ) * math.sqrt(self.periods_per_year)
            if downside_std > 0:
                report.sortino_ratio = (
                    (mean_r - self.risk_free_rate / self.periods_per_year) / downside_std
                ) * math.sqrt(self.periods_per_year)

            n_periods = len(equity_curve) - 1
            years = n_periods / self.periods_per_year if self.periods_per_year else 1
            if equity_curve[0] > 0 and years > 0:
                report.cagr = (equity_curve[-1] / equity_curve[0]) ** (1 / years) - 1

        return report

    def generate(self, trades: List, equity_curve: Optional[List[float]] = None) -> PerformanceReport:
        report = self.from_trades(trades)
        if equity_curve:
            report = self.with_equity_curve(report, equity_curve)
        return report
