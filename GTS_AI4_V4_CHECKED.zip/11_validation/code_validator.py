"""
GTS — Global Trading System
Module   : 11_validation/code_validator.py
Owner    : AI-4 (Backtest + Risk + Execution + Production)
Purpose  : Static validation of Python source files before they are allowed
           to progress through the Production Gate
           (Backtest -> Optimization -> Walk Forward -> Stress Test ->
            Risk Test -> QA -> Paper Trade -> Live Approval).

INPUT       : One or more .py file paths, or a directory to scan recursively.
OUTPUT      : ValidationReport (per file) + CodeValidationResult (aggregate).
CALLER      : 11_validation/qa_gate.py, 28_tests/*, CI pipeline, CLI.
CALLEE      : Python stdlib only (ast, py_compile, pathlib, dataclasses).
DEPENDENCIES: None outside the Python standard library (by design — a
              validator must not depend on the code it validates, or on
              third-party packages that may themselves be unvalidated).

This file does NOT execute the code it validates. All checks are static
(AST-based) so that untrusted / unfinished strategy code can never run
during validation.
"""

from __future__ import annotations

import ast
import logging
import py_compile
import tempfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Iterable

logger = logging.getLogger("gts.validation.code_validator")
if not logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(
        logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    )
    logger.addHandler(_handler)
    logger.setLevel(logging.INFO)


# --------------------------------------------------------------------------- #
# Severity / Issue model
# --------------------------------------------------------------------------- #

class Severity(str, Enum):
    """How serious an issue is. BLOCKER fails the QA gate outright."""
    INFO = "INFO"
    WARNING = "WARNING"
    BLOCKER = "BLOCKER"


@dataclass(frozen=True)
class ValidationIssue:
    """A single finding produced by one of the checks below."""
    rule_id: str
    severity: Severity
    message: str
    file: str
    line: int = 0
    col: int = 0

    def __str__(self) -> str:  # pragma: no cover - cosmetic
        loc = f"{self.file}:{self.line}:{self.col}"
        return f"[{self.severity.value}] {self.rule_id} @ {loc} — {self.message}"


@dataclass
class ValidationReport:
    """Result of validating a single file."""
    file: str
    passed: bool
    issues: list[ValidationIssue] = field(default_factory=list)
    checked_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    @property
    def blockers(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == Severity.BLOCKER]

    @property
    def warnings(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == Severity.WARNING]


@dataclass
class CodeValidationResult:
    """Aggregate result across every file that was checked."""
    reports: list[ValidationReport] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(r.passed for r in self.reports)

    @property
    def total_blockers(self) -> int:
        return sum(len(r.blockers) for r in self.reports)

    @property
    def total_warnings(self) -> int:
        return sum(len(r.warnings) for r in self.reports)

    def summary(self) -> str:
        status = "PASS" if self.passed else "FAIL"
        return (
            f"CodeValidator {status} — {len(self.reports)} file(s) checked, "
            f"{self.total_blockers} blocker(s), {self.total_warnings} warning(s)"
        )


# --------------------------------------------------------------------------- #
# Rule configuration
# --------------------------------------------------------------------------- #

# Modules / calls that must never appear in trading-system code paths that
# reach the Production Gate. Kept intentionally small and explicit — this is
# a safety allow/deny list, not a linter substitute.
BANNED_CALLS: dict[str, str] = {
    "eval": "Dynamic eval() can execute arbitrary code — forbidden in GTS.",
    "exec": "Dynamic exec() can execute arbitrary code — forbidden in GTS.",
    "os.system": "Shell execution is forbidden in strategy/engine code.",
    "subprocess.Popen": "Direct subprocess spawning is forbidden here; use 27_system.",
    "pickle.loads": "Unpickling untrusted data is a code-execution risk.",
    "input": "Blocking interactive input() is forbidden in engine code.",
}

BANNED_IMPORTS: set[str] = {
    "pickle",  # allowed only inside 23_database, flagged elsewhere as WARNING
}

MAX_FUNCTION_LINES = 120
MAX_CYCLOMATIC_COMPLEXITY = 15
MAX_FILE_LINES = 1500


# --------------------------------------------------------------------------- #
# AST visitor — collects issues in a single pass
# --------------------------------------------------------------------------- #

class _Visitor(ast.NodeVisitor):
    def __init__(self, filename: str, source_lines: list[str]) -> None:
        self.filename = filename
        self.source_lines = source_lines
        self.issues: list[ValidationIssue] = []

    # ---- helpers ---------------------------------------------------- #

    def _add(self, node: ast.AST, rule_id: str, severity: Severity, message: str) -> None:
        self.issues.append(
            ValidationIssue(
                rule_id=rule_id,
                severity=severity,
                message=message,
                file=self.filename,
                line=getattr(node, "lineno", 0),
                col=getattr(node, "col_offset", 0),
            )
        )

    @staticmethod
    def _dotted_name(node: ast.AST) -> str | None:
        """Best-effort reconstruction of dotted call names, e.g. os.system."""
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            base = _Visitor._dotted_name(node.value)
            return f"{base}.{node.attr}" if base else node.attr
        return None

    @staticmethod
    def _cyclomatic_complexity(fn: ast.AST) -> int:
        """Simple McCabe-style complexity: 1 + branching nodes."""
        complexity = 1
        branch_nodes = (
            ast.If, ast.For, ast.AsyncFor, ast.While, ast.Try,
            ast.ExceptHandler, ast.With, ast.AsyncWith,
            ast.BoolOp, ast.IfExp,
        )
        for child in ast.walk(fn):
            if isinstance(child, branch_nodes):
                complexity += 1
        return complexity

    # ---- visitors ----------------------------------------------------- #

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            root = alias.name.split(".")[0]
            if root in BANNED_IMPORTS:
                self._add(
                    node, "GTS-IMPORT-001", Severity.WARNING,
                    f"Import of '{alias.name}' requires review "
                    f"(restricted to trusted modules only).",
                )
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        root = (node.module or "").split(".")[0]
        if root in BANNED_IMPORTS:
            self._add(
                node, "GTS-IMPORT-001", Severity.WARNING,
                f"Import from '{node.module}' requires review "
                f"(restricted to trusted modules only).",
            )
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        name = self._dotted_name(node.func)
        if name in BANNED_CALLS:
            self._add(
                node, "GTS-CALL-001", Severity.BLOCKER, BANNED_CALLS[name],
            )
        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check_function(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check_function(node)
        self.generic_visit(node)

    def _check_function(self, node: ast.AST) -> None:
        end_line = getattr(node, "end_lineno", None) or node.lineno
        length = end_line - node.lineno + 1
        if length > MAX_FUNCTION_LINES:
            self._add(
                node, "GTS-LEN-001", Severity.WARNING,
                f"Function '{getattr(node, 'name', '?')}' is {length} lines "
                f"(limit {MAX_FUNCTION_LINES}) — consider splitting it.",
            )
        complexity = self._cyclomatic_complexity(node)
        if complexity > MAX_CYCLOMATIC_COMPLEXITY:
            self._add(
                node, "GTS-COMPLEX-001", Severity.WARNING,
                f"Function '{getattr(node, 'name', '?')}' has cyclomatic "
                f"complexity {complexity} (limit {MAX_CYCLOMATIC_COMPLEXITY}).",
            )
        # Bare except is a BLOCKER in a trading system: silent failure risk.
        for child in ast.walk(node):
            if isinstance(child, ast.ExceptHandler) and child.type is None:
                self._add(
                    child, "GTS-EXC-001", Severity.BLOCKER,
                    "Bare 'except:' is forbidden — it can silently swallow "
                    "errors during live/paper trading. Catch specific "
                    "exceptions instead.",
                )

    def visit_Assert(self, node: ast.Assert) -> None:
        self._add(
            node, "GTS-ASSERT-001", Severity.WARNING,
            "assert statements are stripped when Python runs with -O; "
            "do not rely on assert for runtime validation logic.",
        )
        self.generic_visit(node)


# --------------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------------- #

class CodeValidator:
    """
    Static, non-executing validator for GTS Python source files.

    Usage
    -----
        validator = CodeValidator()
        result = validator.validate_paths(["11_validation/code_validator.py"])
        if not result.passed:
            for report in result.reports:
                for issue in report.issues:
                    print(issue)
    """

    def __init__(
        self,
        max_function_lines: int = MAX_FUNCTION_LINES,
        max_complexity: int = MAX_CYCLOMATIC_COMPLEXITY,
        max_file_lines: int = MAX_FILE_LINES,
    ) -> None:
        self.max_function_lines = max_function_lines
        self.max_complexity = max_complexity
        self.max_file_lines = max_file_lines

    # ------------------------------------------------------------------ #

    def validate_paths(self, paths: Iterable[str | Path]) -> CodeValidationResult:
        """Validate a mix of files and/or directories."""
        files: list[Path] = []
        for raw in paths:
            p = Path(raw)
            if p.is_dir():
                files.extend(sorted(p.rglob("*.py")))
            elif p.suffix == ".py":
                files.append(p)
            else:
                logger.warning("Skipping non-Python path: %s", p)

        result = CodeValidationResult()
        for file_path in files:
            result.reports.append(self.validate_file(file_path))
        logger.info(result.summary())
        return result

    def validate_file(self, path: str | Path) -> ValidationReport:
        """Validate a single .py file and return its report."""
        path = Path(path)
        filename = str(path)
        issues: list[ValidationIssue] = []

        try:
            source = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as exc:
            issues.append(
                ValidationIssue(
                    rule_id="GTS-READ-001",
                    severity=Severity.BLOCKER,
                    message=f"Could not read file: {exc}",
                    file=filename,
                )
            )
            return ValidationReport(file=filename, passed=False, issues=issues)

        # 1. Syntax check via py_compile (catches everything ast.parse would,
        #    plus some encoding edge cases), writing bytecode to a temp dir
        #    so the source tree is never touched.
        with tempfile.TemporaryDirectory() as tmp_dir:
            try:
                py_compile.compile(
                    str(path), cfile=str(Path(tmp_dir) / "out.pyc"), doraise=True
                )
            except py_compile.PyCompileError as exc:
                issues.append(
                    ValidationIssue(
                        rule_id="GTS-SYNTAX-001",
                        severity=Severity.BLOCKER,
                        message=f"Syntax error: {exc.msg}",
                        file=filename,
                    )
                )
                return ValidationReport(file=filename, passed=False, issues=issues)

        # 2. File length check.
        line_count = source.count("\n") + 1
        if line_count > self.max_file_lines:
            issues.append(
                ValidationIssue(
                    rule_id="GTS-LEN-002",
                    severity=Severity.WARNING,
                    message=(
                        f"File is {line_count} lines "
                        f"(limit {self.max_file_lines}) — consider splitting "
                        f"into smaller modules."
                    ),
                    file=filename,
                )
            )

        # 3. AST-based structural / safety checks.
        try:
            tree = ast.parse(source, filename=filename)
        except SyntaxError as exc:  # pragma: no cover - already caught above
            issues.append(
                ValidationIssue(
                    rule_id="GTS-SYNTAX-002",
                    severity=Severity.BLOCKER,
                    message=f"Syntax error: {exc.msg}",
                    file=filename,
                )
            )
            return ValidationReport(file=filename, passed=False, issues=issues)

        visitor = _Visitor(filename, source.splitlines())
        visitor.visit(tree)
        issues.extend(visitor.issues)

        passed = not any(i.severity == Severity.BLOCKER for i in issues)
        return ValidationReport(file=filename, passed=passed, issues=issues)


# --------------------------------------------------------------------------- #
# CLI entry point
# --------------------------------------------------------------------------- #

def main(argv: list[str] | None = None) -> int:
    """
    CLI usage:
        python code_validator.py <file_or_dir> [<file_or_dir> ...]

    Exit code 0 = all files passed (no BLOCKER issues).
    Exit code 1 = at least one file failed.
    """
    import sys

    args = argv if argv is not None else sys.argv[1:]
    if not args:
        print("Usage: python code_validator.py <file_or_dir> [...]")
        return 2

    validator = CodeValidator()
    result = validator.validate_paths(args)

    for report in result.reports:
        status = "PASS" if report.passed else "FAIL"
        print(f"\n{report.file} — {status}")
        for issue in report.issues:
            print(f"  {issue}")

    print(f"\n{result.summary()}")
    return 0 if result.passed else 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
