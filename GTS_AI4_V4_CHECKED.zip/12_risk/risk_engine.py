"""
GTS — Global Trading System
Module   : 12_risk/risk_engine.py
Owner    : AI-4

INPUT       : Proposed orders/signals from 08_signal_engine (via
              14_execution), current portfolio state from 13_portfolio,
              and a RiskLimits configuration.
OUTPUT      : RiskDecision (APPROVE / REJECT / REDUCE) per proposed order,
              plus a running RiskState snapshot.
CALLER      : 14_execution/order_manager.py (every order must pass through
              risk_engine.evaluate() before reaching order_validator.py),
              16_paper_trading/paper_engine.py, 17_live_trading/live_gate.py.
CALLEE      : 12_risk/position_sizing.py, 12_risk/exposure_manager.py,
              12_risk/drawdown_guard.py, 12_risk/kill_switch.py (all
              siblings — risk_engine.py is the orchestrator for this
              package).
DEPENDENCIES: Standard library only.

Purpose: this is the central, non-bypassable risk authority for GTS. Every
order — backtest, paper, or live — is evaluated here before it may
proceed. It composes the four specialist checkers in this package
(position sizing, exposure, drawdown, kill switch) into one verdict, and
NEVER allows a strategy or execution module to override its REJECT
decision (Master Blueprint: "Live trading requires validation and risk
gates", "No strategy creation authority").
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any

logger = logging.getLogger("gts.risk.risk_engine")
if not logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"))
    logger.addHandler(_h)
    logger.setLevel(logging.INFO)


class RiskVerdict(str, Enum):
    APPROVE = "APPROVE"
    REDUCE = "REDUCE"   # order allowed but quantity must be reduced
    REJECT = "REJECT"


@dataclass(frozen=True)
class RiskLimits:
    """Hard, configured risk limits. Immutable once the engine is built."""
    max_position_size: float
    max_daily_loss: float
    max_gross_exposure: float
    max_symbol_exposure_pct: float = 0.25   # of max_gross_exposure
    max_drawdown_pct: float = 0.20          # of peak equity
    max_orders_per_minute: int = 60


@dataclass
class PortfolioState:
    """Minimal snapshot of current portfolio state needed for risk checks."""
    equity: float
    peak_equity: float
    daily_realized_pnl: float
    positions: dict[str, float] = field(default_factory=dict)  # symbol -> qty
    gross_exposure: float = 0.0
    orders_this_minute: int = 0
    kill_switch_active: bool = False


@dataclass(frozen=True)
class OrderProposal:
    symbol: str
    side: str          # BUY / SELL
    quantity: float
    price: float
    strategy_id: str


@dataclass
class RiskDecision:
    verdict: RiskVerdict
    order: OrderProposal
    approved_quantity: float
    reasons: list[str] = field(default_factory=list)
    evaluated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @property
    def approved(self) -> bool:
        return self.verdict != RiskVerdict.REJECT

    def __str__(self) -> str:  # pragma: no cover
        reason_str = "; ".join(self.reasons) if self.reasons else "ok"
        return (
            f"{self.verdict.value} {self.order.side} {self.approved_quantity} "
            f"{self.order.symbol} — {reason_str}"
        )


class RiskEngine:
    """
    Central risk authority. Composes position sizing, exposure, drawdown
    and kill-switch checks into a single, authoritative decision per order.

    Usage
    -----
        engine = RiskEngine(limits)
        decision = engine.evaluate(order, portfolio_state)
        if not decision.approved:
            # do not route order to execution
            ...
    """

    def __init__(self, limits: RiskLimits) -> None:
        self.limits = limits
        # Imported lazily / lightly coupled: these are the sibling modules.
        # Declared as attributes so tests can inject fakes.
        from drawdown_guard import DrawdownGuard
        from exposure_manager import ExposureManager
        from kill_switch import KillSwitch
        from position_sizing import PositionSizer

        self.position_sizer = PositionSizer(max_position_size=limits.max_position_size)
        self.exposure_manager = ExposureManager(
            max_gross_exposure=limits.max_gross_exposure,
            max_symbol_exposure_pct=limits.max_symbol_exposure_pct,
        )
        self.drawdown_guard = DrawdownGuard(max_drawdown_pct=limits.max_drawdown_pct)
        self.kill_switch = KillSwitch()

    # ------------------------------------------------------------------ #

    def evaluate(self, order: OrderProposal, state: PortfolioState) -> RiskDecision:
        reasons: list[str] = []

        # 1. Kill switch is absolute — nothing overrides it.
        if state.kill_switch_active or self.kill_switch.is_active():
            reasons.append("Kill switch is active — all new orders rejected.")
            return self._reject(order, reasons)

        # 2. Daily loss limit — absolute, non-negotiable.
        if state.daily_realized_pnl <= -abs(self.limits.max_daily_loss):
            reasons.append(
                f"Daily realized loss {state.daily_realized_pnl:.2f} breaches "
                f"limit -{self.limits.max_daily_loss:.2f}."
            )
            self.kill_switch.trip("daily_loss_limit_breached")
            return self._reject(order, reasons)

        # 3. Drawdown guard.
        dd_result = self.drawdown_guard.check(state.equity, state.peak_equity)
        if dd_result.breached:
            reasons.append(dd_result.message)
            return self._reject(order, reasons)

        # 4. Order rate limiting — protects against runaway/looping strategies.
        if state.orders_this_minute >= self.limits.max_orders_per_minute:
            reasons.append(
                f"Order rate limit exceeded "
                f"({state.orders_this_minute}/{self.limits.max_orders_per_minute} per minute)."
            )
            return self._reject(order, reasons)

        # 5. Position sizing.
        sizing_result = self.position_sizer.size(order.quantity)
        approved_qty = sizing_result.approved_quantity
        if sizing_result.was_capped:
            reasons.append(sizing_result.message)

        if approved_qty <= 0:
            reasons.append("Approved quantity reduced to zero by position sizing.")
            return self._reject(order, reasons)

        # 6. Exposure limits (gross + per-symbol).
        exposure_result = self.exposure_manager.check(
            symbol=order.symbol,
            side=order.side,
            quantity=approved_qty,
            price=order.price,
            current_positions=state.positions,
            current_gross_exposure=state.gross_exposure,
        )
        if exposure_result.rejected:
            reasons.append(exposure_result.message)
            return self._reject(order, reasons)
        if exposure_result.approved_quantity < approved_qty:
            approved_qty = exposure_result.approved_quantity
            reasons.append(exposure_result.message)

        if approved_qty <= 0:
            reasons.append("Approved quantity reduced to zero by exposure limits.")
            return self._reject(order, reasons)

        verdict = RiskVerdict.APPROVE if approved_qty == order.quantity else RiskVerdict.REDUCE
        decision = RiskDecision(
            verdict=verdict, order=order, approved_quantity=approved_qty, reasons=reasons,
        )
        logger.info(str(decision))
        return decision

    # ------------------------------------------------------------------ #

    def _reject(self, order: OrderProposal, reasons: list[str]) -> RiskDecision:
        decision = RiskDecision(
            verdict=RiskVerdict.REJECT, order=order, approved_quantity=0.0, reasons=reasons,
        )
        logger.warning(str(decision))
        return decision


def main(argv: list[str] | None = None) -> int:
    """
    CLI smoke-test usage:
        python risk_engine.py
    Runs a small self-contained demo scenario (no external files needed).
    """
    limits = RiskLimits(
        max_position_size=100,
        max_daily_loss=5000,
        max_gross_exposure=100_000,
    )
    engine = RiskEngine(limits)
    state = PortfolioState(
        equity=100_000, peak_equity=100_000, daily_realized_pnl=0.0,
        positions={}, gross_exposure=0.0, orders_this_minute=0,
    )
    order = OrderProposal(symbol="NIFTY", side="BUY", quantity=50, price=20000, strategy_id="demo")
    decision = engine.evaluate(order, state)
    print(decision)
    return 0 if decision.approved else 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
