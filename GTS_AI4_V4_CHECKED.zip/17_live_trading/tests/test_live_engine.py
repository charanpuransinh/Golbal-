"""
test_live_engine.py
MODULE: 17_live_trading (tests)
OWNER : AI-4
Covers: kill-switch block, gate rejection, successful send, fill callback.
Uses lightweight fakes for broker/order_manager/risk/exposure/qa so this
test runs standalone without real broker credentials.
"""

import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from live_engine import LiveEngine, LiveOrderStatus
from live_gate import LiveGate, GateResult


class FakeKillSwitch:
    def __init__(self, tripped=False):
        self._tripped = tripped
        self.errors = []
    def is_tripped(self):
        return self._tripped
    def report_error(self, source, detail):
        self.errors.append((source, detail))


class FakeOrderManager:
    def __init__(self, fail=False):
        self.fail = fail
        self.sent = []
        self.cancelled = []
    def submit(self, symbol, side, quantity, order_type, limit_price, broker):
        if self.fail:
            raise RuntimeError("broker_rejected")
        self.sent.append((symbol, side, quantity))
        return {"broker_order_id": f"BRK-{symbol}-{len(self.sent)}"}
    def cancel(self, broker_order_id, broker):
        self.cancelled.append(broker_order_id)


class AlwaysApproveGate:
    def check(self, order):
        return GateResult(True, "OK")


class AlwaysRejectGate:
    def check(self, order):
        return GateResult(False, "NOT_CERTIFIED")


def test_kill_switch_blocks_order():
    engine = LiveEngine(broker_adapter=object(), live_gate=AlwaysApproveGate(),
                         kill_switch=FakeKillSwitch(tripped=True), order_manager=FakeOrderManager())
    order = engine.submit_signal("NIFTY", "BUY", 1, strategy_id="S1")
    assert order.status == LiveOrderStatus.REJECTED
    assert order.error == "KILL_SWITCH_ACTIVE"


def test_gate_rejects_uncertified_strategy():
    engine = LiveEngine(broker_adapter=object(), live_gate=AlwaysRejectGate(),
                         kill_switch=FakeKillSwitch(), order_manager=FakeOrderManager())
    order = engine.submit_signal("NIFTY", "BUY", 1, strategy_id="S1")
    assert order.status == LiveOrderStatus.REJECTED
    assert order.error == "NOT_CERTIFIED"


def test_successful_order_reaches_broker():
    om = FakeOrderManager()
    engine = LiveEngine(broker_adapter=object(), live_gate=AlwaysApproveGate(),
                         kill_switch=FakeKillSwitch(), order_manager=om)
    order = engine.submit_signal("GOLD", "BUY", 3, strategy_id="S1")
    assert order.status == LiveOrderStatus.ACKED
    assert order.broker_order_id is not None
    assert len(om.sent) == 1


def test_broker_error_trips_kill_switch_report():
    ks = FakeKillSwitch()
    engine = LiveEngine(broker_adapter=object(), live_gate=AlwaysApproveGate(),
                         kill_switch=ks, order_manager=FakeOrderManager(fail=True))
    order = engine.submit_signal("SILVER", "BUY", 1, strategy_id="S1")
    assert order.status == LiveOrderStatus.ERROR
    assert len(ks.errors) == 1


def test_fill_callback_updates_order():
    om = FakeOrderManager()
    engine = LiveEngine(broker_adapter=object(), live_gate=AlwaysApproveGate(),
                         kill_switch=FakeKillSwitch(), order_manager=om)
    order = engine.submit_signal("CRUDE", "BUY", 5, strategy_id="S1")
    engine.on_broker_fill(order.broker_order_id, fill_qty=5, fill_price=101.5)
    assert order.status == LiveOrderStatus.FILLED
    assert order.avg_fill_price == 101.5


if __name__ == "__main__":
    test_kill_switch_blocks_order()
    test_gate_rejects_uncertified_strategy()
    test_successful_order_reaches_broker()
    test_broker_error_trips_kill_switch_report()
    test_fill_callback_updates_order()
    print("live_engine: ALL TESTS PASSED")
