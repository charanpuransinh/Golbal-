"""
GTS — Global Trading System
Module   : 13_portfolio/pnl_engine.py
Owner    : AI-4

INPUT       : Fills (executed trades) from 14_execution/execution_engine.py
              or 09_backtest/fill_engine.py, and mark prices from
              01_market_data.
OUTPUT      : PnLSnapshot per symbol and portfolio-level, feeding
              12_risk/drawdown_guard.py (equity/peak) and
              18_accounting/ledger.py.
CALLER      : 13_portfolio/portfolio_manager.py, 12_risk/risk_engine.py
              (via PortfolioState), 19_reporting/performance_report.py.
CALLEE      : None outside stdlib.
DEPENDENCIES: Standard library only.

Purpose: single source of truth for realized and unrealized P&L. Tracks
a running average-cost basis per symbol, computes realized P&L on each
closing fill, and unrealized P&L against the latest mark price. Also
tracks the running equity high-water mark that drawdown_guard.py needs.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class Fill:
    symbol: str
    side: str           # BUY / SELL
    quantity: float
    price: float
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class SymbolPosition:
    symbol: str
    quantity: float = 0.0          # signed: +long, -short
    avg_cost: float = 0.0
    realized_pnl: float = 0.0

    def unrealized_pnl(self, mark_price: float) -> float:
        return (mark_price - self.avg_cost) * self.quantity


@dataclass
class PnLSnapshot:
    starting_equity: float
    realized_pnl: float
    unrealized_pnl: float
    equity: float
    peak_equity: float
    daily_realized_pnl: float
    per_symbol: dict[str, SymbolPosition] = field(default_factory=dict)
    taken_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @property
    def total_pnl(self) -> float:
        return self.realized_pnl + self.unrealized_pnl

    @property
    def drawdown_pct(self) -> float:
        if self.peak_equity <= 0:
            return 0.0
        return max(0.0, (self.peak_equity - self.equity) / self.peak_equity)


class PnLEngine:
    """
    Tracks positions, average cost, and realized/unrealized P&L across the
    whole portfolio using a running weighted-average-cost method.

    Usage
    -----
        engine = PnLEngine(starting_equity=100_000)
        engine.apply_fill(Fill("NIFTY", "BUY", 10, 20000))
        engine.mark({"NIFTY": 20150})
        snapshot = engine.snapshot()
    """

    def __init__(self, starting_equity: float) -> None:
        if starting_equity <= 0:
            raise ValueError("starting_equity must be positive.")
        self.starting_equity = starting_equity
        self.positions: dict[str, SymbolPosition] = {}
        self._marks: dict[str, float] = {}
        self._peak_equity = starting_equity
        self._daily_realized_pnl = 0.0
        self._current_day: str | None = None

    # ------------------------------------------------------------------ #

    def apply_fill(self, fill: Fill) -> SymbolPosition:
        """Apply an executed fill, updating average cost and realized P&L."""
        self._roll_day_if_needed(fill.timestamp)

        pos = self.positions.setdefault(fill.symbol, SymbolPosition(symbol=fill.symbol))
        direction = 1 if fill.side.upper() in ("BUY", "LONG") else -1
        fill_qty = direction * fill.quantity

        if pos.quantity == 0 or (pos.quantity > 0) == (fill_qty > 0):
            # Same direction (or opening from flat): extend the position,
            # blend the average cost.
            new_qty = pos.quantity + fill_qty
            if new_qty != 0:
                pos.avg_cost = (
                    (pos.avg_cost * abs(pos.quantity)) + (fill.price * abs(fill_qty))
                ) / abs(new_qty)
            pos.quantity = new_qty
        else:
            # Opposite direction: this fill closes some or all of the
            # existing position (and may flip it).
            closing_qty = min(abs(fill_qty), abs(pos.quantity))
            realized = (fill.price - pos.avg_cost) * closing_qty * (1 if pos.quantity > 0 else -1)
            pos.realized_pnl += realized
            self._daily_realized_pnl += realized

            remaining_fill_qty = abs(fill_qty) - closing_qty
            new_qty = pos.quantity + fill_qty
            pos.quantity = new_qty
            if remaining_fill_qty > 0:
                # Position flipped direction — new average cost is this
                # fill's price for the flipped-into portion.
                pos.avg_cost = fill.price
            elif new_qty == 0:
                pos.avg_cost = 0.0

        self.positions[fill.symbol] = pos
        return pos

    def mark(self, mark_prices: dict[str, float]) -> None:
        """Update latest mark prices used for unrealized P&L / equity."""
        self._marks.update(mark_prices)

    def snapshot(self) -> PnLSnapshot:
        realized_total = sum(p.realized_pnl for p in self.positions.values())
        unrealized_total = 0.0
        for symbol, pos in self.positions.items():
            mark_price = self._marks.get(symbol, pos.avg_cost)
            unrealized_total += pos.unrealized_pnl(mark_price)

        equity = self.starting_equity + realized_total + unrealized_total
        self._peak_equity = max(self._peak_equity, equity)

        return PnLSnapshot(
            starting_equity=self.starting_equity,
            realized_pnl=realized_total,
            unrealized_pnl=unrealized_total,
            equity=equity,
            peak_equity=self._peak_equity,
            daily_realized_pnl=self._daily_realized_pnl,
            per_symbol=dict(self.positions),
        )

    def reset_daily_pnl(self) -> None:
        """Call at session/day boundary (typically driven by 25_scheduler)."""
        self._daily_realized_pnl = 0.0

    # ------------------------------------------------------------------ #

    def _roll_day_if_needed(self, timestamp: str) -> None:
        day = timestamp[:10]  # ISO date portion, good enough for day-rollover
        if self._current_day is None:
            self._current_day = day
            return
        if day != self._current_day:
            self._current_day = day
            self.reset_daily_pnl()


def main(argv: list[str] | None = None) -> int:
    """CLI smoke-test: python pnl_engine.py"""
    engine = PnLEngine(starting_equity=100_000)
    engine.apply_fill(Fill("NIFTY", "BUY", 10, 20000))
    engine.mark({"NIFTY": 20150})
    snap = engine.snapshot()
    print(f"equity={snap.equity:.2f} realized={snap.realized_pnl:.2f} unrealized={snap.unrealized_pnl:.2f}")

    engine.apply_fill(Fill("NIFTY", "SELL", 10, 20150))
    snap = engine.snapshot()
    print(f"equity={snap.equity:.2f} realized={snap.realized_pnl:.2f} unrealized={snap.unrealized_pnl:.2f}")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
