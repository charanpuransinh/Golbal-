"""
GTS — Global Trading System
Module   : 09_backtest
File     : backtest_engine.py
Owner    : AI-4 (Backtest + Risk + Execution + Production)

PURPOSE
-------
Top-level orchestrator for a single backtest run. Owns one EventEngine,
one FillEngine and one PerformanceEngine, wires them together correctly,
and drives historical market data through them bar by bar. Strategy
(07_strategy), signal (08_signal_engine) and risk (12_risk) components —
owned by other AIs per the Master Blueprint — attach to the same
EventEngine via `BacktestEngine.subscribe(...)`; this file does not
implement or guess at their logic, only provides the substrate they run
on, per the "no modification of another AI's owned files / no strategy
creation authority" rule in GTS_AI4_WORKING_README.md.

CONTRACT
--------
INPUT      : An ordered iterable of market bars (symbol, bar_time, data)
             supplied by the caller (ultimately sourced from
             01_market_data, outside this module's ownership) via
             `feed_market_data`/`run`.
OUTPUT     : A BacktestRunResult containing the performance summary,
             closed-trade history, equity curve, and fill/event stats for
             the run. Nothing is written to disk here — persistence is
             19_reporting's responsibility.
CALLER     : A human/operator script, or 10_optimization when running many
             backtests for parameter search / walk-forward testing.
CALLEE     : event_engine.py, fill_engine.py, performance_engine.py (all
             sibling files in 09_backtest, all owned by AI-4).
DEPENDENCIES: event_engine.py, fill_engine.py, performance_engine.py +
             Python standard library only (uuid for run identifiers,
             logging).

ARCHITECTURAL RULES ENFORCED
-----------------------------
- No guessing: market bars must arrive with non-decreasing bar_time per
  symbol; an out-of-order bar is refused (raised as OutOfOrderDataError)
  rather than silently reordered, since silently reordering historical
  data is exactly the kind of lookahead-bias bug a backtest engine must
  never introduce.
- No modification of another AI's owned files: this file only *drives*
  external strategy/signal/risk handlers via publish/subscribe; it never
  implements strategy or risk logic itself.
- Reproducibility: run() takes an explicit `run_id` (auto-generated with
  uuid4 if omitted) purely as a label for correlating events/reports —
  it never affects computed results, keeping two runs over identical
  bars and identical handler configuration numerically identical.
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

from event_engine import (
    BacktestEndEvent,
    BacktestStartEvent,
    Event,
    EventEngine,
    EventType,
    MarketEvent,
)
from fill_engine import CommissionModel, FillEngine, SlippageModel
from performance_engine import PerformanceEngine

logger = logging.getLogger("gts.backtest.backtest_engine")

# One market bar as supplied by the caller: (symbol, bar_time, data_dict).
# data_dict must contain at least "close"; "volume" is optional but needed
# for VolumeImpactSlippageModel / max_fill_ratio_of_volume in fill_engine.
MarketBar = Tuple[str, float, Dict[str, Any]]


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class BacktestEngineError(Exception):
    """Base exception for all backtest_engine failures."""


class OutOfOrderDataError(BacktestEngineError):
    """Raised when a market bar's bar_time is earlier than the previous
    bar seen for the same symbol — historical data must be strictly
    non-decreasing in time per symbol to avoid lookahead bias."""


# ---------------------------------------------------------------------------
# Run result
# ---------------------------------------------------------------------------

@dataclass
class BacktestRunResult:
    """Everything produced by one call to BacktestEngine.run()."""

    run_id: str
    bars_processed: int
    summary: Dict[str, object]
    closed_trades: List[Any] = field(default_factory=list)
    equity_curve: List[Any] = field(default_factory=list)
    event_engine_stats: Any = None
    fill_engine_stats: Any = None


# ---------------------------------------------------------------------------
# Backtest engine
# ---------------------------------------------------------------------------

class BacktestEngine:
    """Orchestrates one backtest run.

    Typical usage:

        bt = BacktestEngine(
            starting_cash=1_000_000.0,
            slippage_model=PercentageSlippageModel(0.0005),
            commission_model=PerUnitCommissionModel(0.5, minimum=5.0),
        )

        # externally-owned strategy/signal/risk components attach here:
        bt.subscribe(EventType.MARKET, my_strategy.on_market_event)
        bt.subscribe(EventType.SIGNAL, my_risk_engine.on_signal_event)
        bt.subscribe(EventType.ORDER, my_risk_engine.on_order_event)  # or pass-through to fill

        result = bt.run(bars)
        print(result.summary)
    """

    def __init__(
        self,
        starting_cash: float,
        slippage_model: Optional[SlippageModel] = None,
        commission_model: Optional[CommissionModel] = None,
        max_fill_ratio_of_volume: Optional[float] = None,
        strict_mode: bool = False,
    ):
        """
        Args:
            starting_cash: initial account cash, forwarded to
                PerformanceEngine (must be > 0 — see its own validation).
            slippage_model: forwarded to FillEngine (defaults to
                NoSlippageModel there if omitted).
            commission_model: forwarded to FillEngine (defaults to
                ZeroCommissionModel there if omitted).
            max_fill_ratio_of_volume: forwarded to FillEngine.
            strict_mode: forwarded to EventEngine — if True, a handler
                exception (in *any* subscribed handler, including
                externally-owned strategy/risk code) stops the run
                immediately instead of being logged and skipped.
        """
        self.event_engine = EventEngine(strict_mode=strict_mode)
        self.fill_engine = FillEngine(
            self.event_engine,
            slippage_model=slippage_model,
            commission_model=commission_model,
            max_fill_ratio_of_volume=max_fill_ratio_of_volume,
        )
        self.performance_engine = PerformanceEngine(starting_cash=starting_cash)

        # Core wiring owned by this file: every MarketEvent reaches both
        # the fill engine (to cache price/volume for future orders) and
        # the performance engine (to mark open positions to market).
        # Every ORDER reaches the fill engine. Every FILL reaches the
        # performance engine. External strategy/signal/risk handlers are
        # added on top of this via `subscribe` — they never replace it.
        self.event_engine.subscribe(EventType.MARKET, self.fill_engine.on_market_event)
        self.event_engine.subscribe(EventType.MARKET, self.performance_engine.on_market_event)
        self.event_engine.subscribe(EventType.ORDER, self.fill_engine.on_order_event)
        self.event_engine.subscribe(EventType.FILL, self.performance_engine.on_fill_event)

        self._last_bar_time: Dict[str, float] = {}
        self._bars_processed = 0

    # -- external wiring ------------------------------------------------------

    def subscribe(self, event_type: EventType, handler: Callable[[Event], None]) -> None:
        """Attach an externally-owned handler (strategy, signal, or risk
        component) to `event_type`. Thin pass-through to the underlying
        EventEngine — kept here so callers only ever need to import
        BacktestEngine, not reach into `.event_engine` directly."""
        self.event_engine.subscribe(event_type, handler)

    def publish(self, event: Event) -> None:
        """Publish an arbitrary event directly (rarely needed — normal use
        is `feed_market_data`/`run` for MarketEvent; this exists for
        externally-owned components that need to inject e.g. a
        RiskRejectEvent for audit purposes)."""
        self.event_engine.publish(event)

    def current_bar_time(self, symbol: str) -> Optional[float]:
        """Return the bar_time of the most recent MarketEvent fed for
        `symbol`, or None if no bar has been fed for it yet. Convenience
        for externally-owned strategy/signal/risk handlers that need to
        stamp SignalEvent/OrderEvent.bar_time correctly (see
        SignalEvent.bar_time docstring in event_engine.py for why this
        must be historical market time, not wall-clock time) without each
        one having to track it independently."""
        return self._last_bar_time.get(symbol)

    # -- data feed -------------------------------------------------------------

    def feed_market_data(self, bars: Iterable[MarketBar]) -> int:
        """Publish one MarketEvent per bar, in the order given, running the
        event loop to completion after each bar so that any SIGNAL/ORDER/
        FILL chain triggered by that bar fully resolves before the next
        bar is published (a backtest must never let bar N+1's data
        influence a decision about bar N).

        Args:
            bars: iterable of (symbol, bar_time, data) tuples. `data` must
                contain a "close" key (see MarketEvent/fill_engine/
                performance_engine contracts); "volume" is optional.

        Returns:
            The number of bars fed in this call.

        Raises:
            OutOfOrderDataError: if any bar's bar_time is earlier than the
                previous bar_time seen for the same symbol.
        """
        count = 0
        for symbol, bar_time, data in bars:
            prev_time = self._last_bar_time.get(symbol)
            if prev_time is not None and bar_time < prev_time:
                raise OutOfOrderDataError(
                    f"Out-of-order bar for {symbol}: bar_time={bar_time} < previous bar_time={prev_time}"
                )
            self._last_bar_time[symbol] = bar_time

            event = MarketEvent(symbol=symbol, bar_time=bar_time, data=data)
            self.event_engine.publish(event)
            self.event_engine.run_once()
            count += 1
            self._bars_processed += 1
        return count

    # -- full run ---------------------------------------------------------------

    def run(self, bars: Iterable[MarketBar], run_id: Optional[str] = None) -> BacktestRunResult:
        """Run a complete backtest over `bars` and return the result.

        Publishes BacktestStartEvent before the first bar and
        BacktestEndEvent after the last, so subscribed reporting/logging
        handlers can bracket the run without polling.

        Args:
            bars: see feed_market_data.
            run_id: optional label for this run; auto-generated (uuid4)
                if omitted. Never affects computed results (see module
                docstring's Reproducibility note).

        Returns:
            BacktestRunResult with the full summary, closed trades, equity
            curve and engine stats for this run.
        """
        resolved_run_id = run_id or str(uuid.uuid4())
        logger.info("Backtest run %s starting", resolved_run_id)

        self.event_engine.publish(BacktestStartEvent(run_id=resolved_run_id))
        self.event_engine.run_once()

        bars_this_run = self.feed_market_data(bars)

        self.event_engine.publish(BacktestEndEvent(run_id=resolved_run_id))
        self.event_engine.run_once()

        logger.info(
            "Backtest run %s complete: %d bars processed, %d fills, %d handler errors",
            resolved_run_id, bars_this_run,
            self.fill_engine.stats.fills_generated,
            self.event_engine.stats.handler_errors,
        )

        return BacktestRunResult(
            run_id=resolved_run_id,
            bars_processed=bars_this_run,
            summary=self.performance_engine.summary(),
            closed_trades=list(self.performance_engine.closed_trades),
            equity_curve=list(self.performance_engine.equity_curve),
            event_engine_stats=self.event_engine.stats,
            fill_engine_stats=self.fill_engine.stats,
        )

    # -- lifecycle ---------------------------------------------------------------

    def reset(self) -> None:
        """Reset all owned engines (event, fill, performance) and this
        engine's own bar-ordering state to run a fresh, independent
        backtest in the same process. Does NOT unsubscribe externally
        registered strategy/signal/risk handlers — call
        `self.event_engine.unsubscribe(...)` explicitly if a handler
        should not carry over to the next run."""
        self.event_engine.reset()
        self.fill_engine.reset()
        self.performance_engine.reset()
        self._last_bar_time.clear()
        self._bars_processed = 0
