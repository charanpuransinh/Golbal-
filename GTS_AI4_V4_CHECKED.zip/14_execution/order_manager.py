"""
GTS — Global Trading System
Module   : 14_execution/order_manager.py
Owner    : AI-4

INPUT       : Raw order proposals from 08_signal_engine (via a strategy's
              generate_signal), current PortfolioState from
              13_portfolio/portfolio_manager.py, instrument specs from
              02_instruments.
OUTPUT      : ExecutionResult per order, plus fills forwarded to
              13_portfolio/portfolio_manager.py.
CALLER      : 16_paper_trading/paper_engine.py, 17_live_trading/live_engine.py.
CALLEE       : 12_risk/risk_engine.py, 14_execution/order_validator.py,
              14_execution/execution_engine.py (this file is the
              orchestrator for the whole order lifecycle).
DEPENDENCIES: Standard library only.

Purpose: enforce the mandatory order lifecycle for every single order in
GTS, with no bypass path:

    Signal -> Risk Gate -> Order Validation -> Execution -> Fill -> Portfolio

If risk_engine.py rejects, the order never reaches order_validator.py.
If order_validator.py rejects, the order never reaches execution_engine.py.
Only a confirmed fill is ever forwarded to the portfolio book.
"""

from __future__ import annotations

import itertools
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum

from execution_engine import (
    BrokerAdapter,
    ExecutionEngine,
    ExecutionResult,
    ExecutionStatus,
)
from order_validator import InstrumentSpec, Order, OrderType, OrderValidator

logger = logging.getLogger("gts.execution.order_manager")
if not logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"))
    logger.addHandler(_h)
    logger.setLevel(logging.INFO)


class LifecycleStage(str, Enum):
    RISK_REJECTED = "RISK_REJECTED"
    VALIDATION_REJECTED = "VALIDATION_REJECTED"
    EXECUTED = "EXECUTED"


@dataclass
class OrderLifecycleResult:
    order_id: str
    stage: LifecycleStage
    execution_result: ExecutionResult | None = None
    reasons: list[str] = field(default_factory=list)
    processed_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @property
    def is_success(self) -> bool:
        return (
            self.stage == LifecycleStage.EXECUTED
            and self.execution_result is not None
            and self.execution_result.is_success
        )

    def __str__(self) -> str:  # pragma: no cover
        base = f"{self.stage.value} order={self.order_id}"
        if self.execution_result is not None:
            base += f" | {self.execution_result}"
        if self.reasons:
            base += f" | reasons={'; '.join(self.reasons)}"
        return base


class OrderManager:
    """
    Orchestrates the full order lifecycle: risk gate -> order validation
    -> execution -> (caller forwards resulting fills to portfolio).

    Usage
    -----
        manager = OrderManager(risk_engine=risk_engine, broker=broker_adapter)
        result = manager.submit(
            symbol="NIFTY", side="BUY", quantity=50, order_type=OrderType.MARKET,
            strategy_id="expiry_v1", instrument_spec=spec, portfolio_state=state,
        )
    """

    _order_id_counter = itertools.count(1)

    def __init__(
        self,
        risk_engine,  # 12_risk.risk_engine.RiskEngine — typed loosely to
                      # avoid a hard import-time coupling in this docstring
                      # example; production code should import the real type.
        broker: BrokerAdapter,
        order_id_prefix: str = "ORD",
    ) -> None:
        self.risk_engine = risk_engine
        self.order_validator = OrderValidator()
        self.execution_engine = ExecutionEngine(broker=broker)
        self.order_id_prefix = order_id_prefix

    # ------------------------------------------------------------------ #

    def submit(
        self,
        symbol: str,
        side: str,
        quantity: float,
        order_type: OrderType,
        strategy_id: str,
        instrument_spec: InstrumentSpec,
        portfolio_state,  # 12_risk.risk_engine.PortfolioState
        limit_price: float | None = None,
        stop_price: float | None = None,
        price_for_risk_check: float | None = None,
    ) -> OrderLifecycleResult:
        from risk_engine import OrderProposal  # local import: see order_manager

        order_id = self._next_order_id()

        # --- Stage 1: Risk Gate (mandatory, non-bypassable) --- #
        proposal = OrderProposal(
            symbol=symbol,
            side=side,
            quantity=quantity,
            price=price_for_risk_check if price_for_risk_check is not None else (limit_price or 0.0),
            strategy_id=strategy_id,
        )
        risk_decision = self.risk_engine.evaluate(proposal, portfolio_state)
        if not risk_decision.approved:
            result = OrderLifecycleResult(
                order_id=order_id,
                stage=LifecycleStage.RISK_REJECTED,
                reasons=list(risk_decision.reasons),
            )
            logger.warning(str(result))
            return result

        approved_quantity = risk_decision.approved_quantity

        # --- Stage 2: Order Validation --- #
        order = Order(
            order_id=order_id,
            symbol=symbol,
            side=side,
            quantity=approved_quantity,
            order_type=order_type,
            limit_price=limit_price,
            stop_price=stop_price,
            strategy_id=strategy_id,
        )
        validation_result = self.order_validator.validate(order, instrument_spec)
        if not validation_result.passed:
            result = OrderLifecycleResult(
                order_id=order_id,
                stage=LifecycleStage.VALIDATION_REJECTED,
                reasons=[str(i) for i in validation_result.issues],
            )
            logger.warning(str(result))
            return result

        # --- Stage 3: Execution --- #
        execution_result = self.execution_engine.execute(order)
        result = OrderLifecycleResult(
            order_id=order_id,
            stage=LifecycleStage.EXECUTED,
            execution_result=execution_result,
            reasons=[i.message for i in validation_result.issues if i.message],
        )
        logger.info(str(result))
        return result

    # ------------------------------------------------------------------ #

    def _next_order_id(self) -> str:
        return f"{self.order_id_prefix}-{next(self._order_id_counter):06d}"


def main(argv: list[str] | None = None) -> int:
    """CLI smoke-test: python order_manager.py"""
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "12_risk"))
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "13_portfolio"))

    from risk_engine import RiskEngine, RiskLimits  # noqa: E402
    from portfolio_manager import PortfolioManager  # noqa: E402
    from execution_engine import BrokerFillResponse  # noqa: E402

    class _FakeBroker:
        def submit_order(self, order):
            return BrokerFillResponse(
                status=ExecutionStatus.FILLED,
                filled_quantity=order.quantity,
                average_fill_price=20000.0,
                broker_order_id="FAKE-1",
            )

    risk_engine = RiskEngine(
        RiskLimits(max_position_size=100, max_daily_loss=5000, max_gross_exposure=10_000_000)
    )
    pm = PortfolioManager(starting_equity=100_000)
    spec = InstrumentSpec(symbol="NIFTY", tick_size=0.05, lot_size=50, max_quantity=500)

    manager = OrderManager(risk_engine=risk_engine, broker=_FakeBroker())
    result = manager.submit(
        symbol="NIFTY", side="BUY", quantity=50, order_type=OrderType.MARKET,
        strategy_id="expiry_v1", instrument_spec=spec,
        portfolio_state=pm.to_risk_state(), price_for_risk_check=20000,
    )
    print(result)
    return 0 if result.is_success else 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
