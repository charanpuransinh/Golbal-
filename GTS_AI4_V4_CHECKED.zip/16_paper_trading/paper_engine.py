"""
paper_engine.py
================
MODULE   : 16_paper_trading
OWNER    : AI-4
PURPOSE  : Simulates live order execution using paper (virtual) money.
           Mirrors the live_engine's interface exactly so a strategy can
           be switched from paper -> live with zero code change.

INPUT    : Signal objects from 08_signal_engine, market data ticks
OUTPUT   : PaperOrder / PaperFill objects, updated PaperAccount state
CALLER   : 20_dashboard (paper trading tab), 25_scheduler
CALLEE   : 12_risk.risk_engine, 13_portfolio.pnl_engine
DEPENDS  : risk_engine, position_sizing, pnl_engine
"""

from __future__ import annotations
import uuid
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional


class OrderSide(Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderStatus(Enum):
    PENDING = "PENDING"
    FILLED = "FILLED"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    REJECTED = "REJECTED"
    CANCELLED = "CANCELLED"


@dataclass
class PaperOrder:
    order_id: str
    symbol: str
    side: OrderSide
    quantity: float
    order_type: str = "MARKET"        # MARKET / LIMIT / SL / SL-M
    limit_price: Optional[float] = None
    stop_price: Optional[float] = None
    status: OrderStatus = OrderStatus.PENDING
    filled_qty: float = 0.0
    avg_fill_price: float = 0.0
    created_at: float = field(default_factory=time.time)
    strategy_id: Optional[str] = None
    meta: Dict = field(default_factory=dict)


@dataclass
class PaperFill:
    fill_id: str
    order_id: str
    symbol: str
    side: OrderSide
    quantity: float
    price: float
    timestamp: float
    slippage: float = 0.0
    commission: float = 0.0


class PaperAccount:
    """Virtual account: cash, positions, realized/unrealized PnL."""

    def __init__(self, starting_capital: float = 1_000_000.0):
        self.starting_capital = starting_capital
        self.cash = starting_capital
        self.positions: Dict[str, Dict] = {}   # symbol -> {qty, avg_price}
        self.realized_pnl = 0.0
        self.trade_log: List[PaperFill] = []

    def apply_fill(self, fill: PaperFill):
        pos = self.positions.setdefault(fill.symbol, {"qty": 0.0, "avg_price": 0.0})
        signed_qty = fill.quantity if fill.side == OrderSide.BUY else -fill.quantity
        cost = fill.price * fill.quantity + fill.commission

        if fill.side == OrderSide.BUY:
            self.cash -= cost
            new_qty = pos["qty"] + signed_qty
            if new_qty != 0:
                pos["avg_price"] = (
                    (pos["avg_price"] * pos["qty"]) + (fill.price * fill.quantity)
                ) / new_qty
            pos["qty"] = new_qty
        else:
            self.cash += (fill.price * fill.quantity) - fill.commission
            realized = (fill.price - pos["avg_price"]) * fill.quantity
            self.realized_pnl += realized
            pos["qty"] += signed_qty

        self.trade_log.append(fill)

    def unrealized_pnl(self, last_prices: Dict[str, float]) -> float:
        total = 0.0
        for symbol, pos in self.positions.items():
            if pos["qty"] == 0:
                continue
            last_price = last_prices.get(symbol, pos["avg_price"])
            total += (last_price - pos["avg_price"]) * pos["qty"]
        return total

    def equity(self, last_prices: Dict[str, float]) -> float:
        return self.cash + self.unrealized_pnl(last_prices) + sum(
            pos["qty"] * pos.get("avg_price", 0.0) for pos in self.positions.values()
        )


class PaperEngine:
    """
    Simulated execution engine.
    Same public interface as live_engine.LiveEngine:
        place_order(), cancel_order(), get_open_orders()
    so strategies remain broker-agnostic.
    """

    def __init__(self, account: Optional[PaperAccount] = None,
                 slippage_bps: float = 1.0, commission_per_trade: float = 0.0):
        self.account = account or PaperAccount()
        self.slippage_bps = slippage_bps
        self.commission_per_trade = commission_per_trade
        self.orders: Dict[str, PaperOrder] = {}
        self._last_prices: Dict[str, float] = {}

    def update_market_price(self, symbol: str, price: float):
        self._last_prices[symbol] = price

    def place_order(self, symbol: str, side: OrderSide, quantity: float,
                     order_type: str = "MARKET", limit_price: float = None,
                     stop_price: float = None, strategy_id: str = None) -> PaperOrder:
        order_id = str(uuid.uuid4())
        order = PaperOrder(
            order_id=order_id, symbol=symbol, side=side, quantity=quantity,
            order_type=order_type, limit_price=limit_price, stop_price=stop_price,
            strategy_id=strategy_id,
        )
        self.orders[order_id] = order
        self._try_fill(order)
        return order

    def cancel_order(self, order_id: str) -> bool:
        order = self.orders.get(order_id)
        if order and order.status == OrderStatus.PENDING:
            order.status = OrderStatus.CANCELLED
            return True
        return False

    def get_open_orders(self) -> List[PaperOrder]:
        return [o for o in self.orders.values() if o.status == OrderStatus.PENDING]

    # ------------------------------------------------------------------
    def _try_fill(self, order: PaperOrder):
        market_price = self._last_prices.get(order.symbol)
        if market_price is None:
            order.status = OrderStatus.REJECTED
            order.meta["reason"] = "NO_MARKET_PRICE"
            return

        fill_price = market_price
        if order.order_type == "MARKET":
            slip = market_price * (self.slippage_bps / 10_000.0)
            fill_price = market_price + slip if order.side == OrderSide.BUY else market_price - slip
        elif order.order_type == "LIMIT":
            if order.side == OrderSide.BUY and market_price > order.limit_price:
                return  # stays pending
            if order.side == OrderSide.SELL and market_price < order.limit_price:
                return
            fill_price = order.limit_price

        fill = PaperFill(
            fill_id=str(uuid.uuid4()), order_id=order.order_id, symbol=order.symbol,
            side=order.side, quantity=order.quantity, price=fill_price,
            timestamp=time.time(), slippage=abs(fill_price - market_price),
            commission=self.commission_per_trade,
        )
        order.status = OrderStatus.FILLED
        order.filled_qty = order.quantity
        order.avg_fill_price = fill_price
        self.account.apply_fill(fill)

    def account_snapshot(self) -> Dict:
        return {
            "cash": self.account.cash,
            "realized_pnl": self.account.realized_pnl,
            "unrealized_pnl": self.account.unrealized_pnl(self._last_prices),
            "equity": self.account.equity(self._last_prices),
            "positions": self.account.positions,
        }
