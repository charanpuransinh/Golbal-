"""
test_live_gate.py
MODULE: 17_live_trading (tests)
OWNER : AI-4
Covers: certification stage completeness, paper-trade minimum, QA/risk/
exposure checks all gating live eligibility correctly.
"""

import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from live_gate import LiveGate


class FakeRiskEngine:
    def pre_trade_check(self, order):
        return {"passed": True}


class FakeExposureManager:
    def check(self, order):
        return {"passed": True}


class FakeQAGate:
    def check_strategy(self, strategy_id):
        return {"passed": True}


def _full_cert_gate():
    gate = LiveGate(FakeRiskEngine(), FakeExposureManager(), FakeQAGate(), min_paper_trades=10)
    for stage in ["backtest", "optimization", "walk_forward", "stress_test", "risk_test", "qa_gate"]:
        gate.register_certification("S1", stage, True)
    gate.register_certification("S1", "paper_trade", True, trade_count=15)
    return gate


class DummyOrder:
    def __init__(self, strategy_id):
        self.strategy_id = strategy_id


def test_missing_certification_rejected():
    gate = LiveGate(FakeRiskEngine(), FakeExposureManager(), FakeQAGate())
    result = gate.check(DummyOrder("UNKNOWN_STRATEGY"))
    assert result.approved is False
    assert result.reason == "NO_CERTIFICATION_RECORD"


def test_incomplete_stage_rejected():
    gate = LiveGate(FakeRiskEngine(), FakeExposureManager(), FakeQAGate())
    gate.register_certification("S1", "backtest", True)
    result = gate.check(DummyOrder("S1"))
    assert result.approved is False
    assert "STAGE_NOT_PASSED" in result.reason


def test_insufficient_paper_trades_rejected():
    gate = LiveGate(FakeRiskEngine(), FakeExposureManager(), FakeQAGate(), min_paper_trades=50)
    for stage in ["backtest", "optimization", "walk_forward", "stress_test", "risk_test", "qa_gate"]:
        gate.register_certification("S1", stage, True)
    gate.register_certification("S1", "paper_trade", True, trade_count=5)
    result = gate.check(DummyOrder("S1"))
    assert result.approved is False
    assert "INSUFFICIENT_PAPER_TRADES" in result.reason


def test_fully_certified_strategy_approved():
    gate = _full_cert_gate()
    result = gate.check(DummyOrder("S1"))
    assert result.approved is True


def test_no_strategy_id_rejected():
    gate = _full_cert_gate()
    result = gate.check(DummyOrder(None))
    assert result.approved is False
    assert result.reason == "NO_STRATEGY_ID_ON_ORDER"


if __name__ == "__main__":
    test_missing_certification_rejected()
    test_incomplete_stage_rejected()
    test_insufficient_paper_trades_rejected()
    test_fully_certified_strategy_approved()
    test_no_strategy_id_rejected()
    print("live_gate: ALL TESTS PASSED")
