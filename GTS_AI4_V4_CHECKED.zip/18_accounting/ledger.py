"""
ledger.py
=========
MODULE   : 18_accounting
OWNER    : AI-4
PURPOSE  : Double-entry style cash/position ledger. Single source of
           truth for cash movements, fees, and running balances across
           paper and live accounts.

INPUT    : Fill events from 16_paper_trading / 17_live_trading
OUTPUT   : LedgerEntry records, running balance, statements
CALLER   : 19_reporting.performance_report, 18_accounting.trade_book
CALLEE   : 23_database (persistence layer)
DEPENDS  : none (pure accounting logic; storage is injected)
"""

from __future__ import annotations
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional


class EntryType(Enum):
    TRADE_BUY = "TRADE_BUY"
    TRADE_SELL = "TRADE_SELL"
    FEE = "FEE"
    DEPOSIT = "DEPOSIT"
    WITHDRAWAL = "WITHDRAWAL"
    DIVIDEND = "DIVIDEND"
    ADJUSTMENT = "ADJUSTMENT"


@dataclass
class LedgerEntry:
    entry_id: str
    entry_type: EntryType
    symbol: Optional[str]
    amount: float               # positive = credit, negative = debit
    balance_after: float
    timestamp: float = field(default_factory=time.time)
    order_id: Optional[str] = None
    note: str = ""


class Ledger:
    """Append-only ledger. Never mutate a past entry — corrections are
    posted as new ADJUSTMENT entries so the audit trail stays intact."""

    def __init__(self, opening_balance: float = 0.0, storage=None):
        self.balance = opening_balance
        self.entries: List[LedgerEntry] = []
        self.storage = storage  # optional 23_database handle

    def _post(self, entry_type: EntryType, amount: float, symbol: str = None,
              order_id: str = None, note: str = "") -> LedgerEntry:
        self.balance += amount
        entry = LedgerEntry(
            entry_id=str(uuid.uuid4()), entry_type=entry_type, symbol=symbol,
            amount=amount, balance_after=self.balance, order_id=order_id, note=note,
        )
        self.entries.append(entry)
        if self.storage is not None:
            self.storage.save_ledger_entry(entry)
        return entry

    def record_buy(self, symbol: str, cost: float, order_id: str = None) -> LedgerEntry:
        return self._post(EntryType.TRADE_BUY, -abs(cost), symbol=symbol, order_id=order_id)

    def record_sell(self, symbol: str, proceeds: float, order_id: str = None) -> LedgerEntry:
        return self._post(EntryType.TRADE_SELL, abs(proceeds), symbol=symbol, order_id=order_id)

    def record_fee(self, amount: float, order_id: str = None, note: str = "") -> LedgerEntry:
        return self._post(EntryType.FEE, -abs(amount), order_id=order_id, note=note)

    def record_deposit(self, amount: float, note: str = "") -> LedgerEntry:
        return self._post(EntryType.DEPOSIT, abs(amount), note=note)

    def record_withdrawal(self, amount: float, note: str = "") -> LedgerEntry:
        return self._post(EntryType.WITHDRAWAL, -abs(amount), note=note)

    def record_adjustment(self, amount: float, note: str) -> LedgerEntry:
        return self._post(EntryType.ADJUSTMENT, amount, note=note)

    def statement(self, start_ts: float = None, end_ts: float = None) -> List[LedgerEntry]:
        entries = self.entries
        if start_ts is not None:
            entries = [e for e in entries if e.timestamp >= start_ts]
        if end_ts is not None:
            entries = [e for e in entries if e.timestamp <= end_ts]
        return entries

    def current_balance(self) -> float:
        return self.balance
