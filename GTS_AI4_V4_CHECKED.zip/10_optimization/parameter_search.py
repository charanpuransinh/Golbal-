"""
GTS — Global Trading System
Module   : 10_optimization
File     : parameter_search.py
Owner    : AI-4 (Backtest + Risk + Execution + Production)

PURPOSE
-------
Defines a strategy-agnostic parameter space and two search strategies
(exhaustive grid search, reproducible random search) that yield parameter
combinations for optimizer.py to evaluate. This file has no knowledge of
backtesting, strategies, or metrics — it only knows how to enumerate
dictionaries of {param_name: value} from a declared space.

CONTRACT
--------
INPUT      : A ParameterSpace built by the caller from
             {param_name: [candidate_values...]}.
OUTPUT     : An iterator of Dict[str, Any] parameter combinations.
CALLER     : optimizer.py (feeds combinations to the objective function),
             walk_forward.py (re-searches per rolling window).
CALLEE     : None — Python standard library only (itertools, random).
DEPENDENCIES: Python standard library only.

ARCHITECTURAL RULES ENFORCED
-----------------------------
- No guessing: an empty candidate list for any parameter is rejected at
  ParameterSpace construction time, not discovered later as a silently
  empty search.
- Reproducibility: RandomSearch requires an explicit seed — there is no
  seed-less constructor — so two optimization runs with the same space,
  seed and sample count always evaluate the exact same combinations in
  the exact same order.
"""

from __future__ import annotations

import itertools
import random
from dataclasses import dataclass
from typing import Any, Dict, Iterator, List, Sequence


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class ParameterSearchError(Exception):
    """Base exception for all parameter_search failures."""


class EmptyParameterSpaceError(ParameterSearchError):
    """Raised when a ParameterSpace has zero parameters, or any parameter
    has zero candidate values."""


# ---------------------------------------------------------------------------
# Parameter space
# ---------------------------------------------------------------------------

class ParameterSpace:
    """A declared set of parameters and their candidate values.

    Example:
        space = ParameterSpace({
            "fast_ma": [5, 10, 20],
            "slow_ma": [50, 100, 200],
            "stop_loss_pct": [0.01, 0.02, 0.03],
        })
    """

    def __init__(self, candidates: Dict[str, Sequence[Any]]):
        """
        Args:
            candidates: mapping of parameter name -> non-empty sequence of
                candidate values for that parameter.

        Raises:
            EmptyParameterSpaceError: if `candidates` is empty, or if any
                parameter's candidate sequence is empty.
        """
        if not candidates:
            raise EmptyParameterSpaceError("ParameterSpace must declare at least one parameter")
        for name, values in candidates.items():
            if len(values) == 0:
                raise EmptyParameterSpaceError(f"Parameter '{name}' has zero candidate values")
        # Store as tuples internally — candidate lists are read many times
        # (once per grid cell / random draw) and must never be mutated
        # out from under an in-progress search.
        self.candidates: Dict[str, tuple] = {name: tuple(values) for name, values in candidates.items()}

    @property
    def parameter_names(self) -> List[str]:
        return list(self.candidates.keys())

    def size(self) -> int:
        """Total number of distinct combinations a full grid search over
        this space would produce (product of each parameter's candidate
        count)."""
        total = 1
        for values in self.candidates.values():
            total *= len(values)
        return total


# ---------------------------------------------------------------------------
# Grid search
# ---------------------------------------------------------------------------

class GridSearch:
    """Exhaustive search: yields every combination of candidate values in
    `space`, in deterministic order (parameters iterate in the order they
    were declared in the `candidates` dict; each parameter's values iterate
    in the order given)."""

    def __init__(self, space: ParameterSpace):
        self.space = space

    def __iter__(self) -> Iterator[Dict[str, Any]]:
        names = self.space.parameter_names
        value_lists = [self.space.candidates[name] for name in names]
        for combo in itertools.product(*value_lists):
            yield dict(zip(names, combo))

    def __len__(self) -> int:
        return self.space.size()


# ---------------------------------------------------------------------------
# Random search
# ---------------------------------------------------------------------------

class RandomSearch:
    """Samples `n_samples` combinations from `space`, drawing each
    parameter's value uniformly (with replacement) from its candidate
    list, independently per parameter. Requires an explicit `seed` so runs
    are exactly reproducible — see module docstring's Reproducibility
    note.

    Note: with replacement means the same exact combination can
    theoretically be drawn more than once, especially when n_samples
    approaches or exceeds space.size(); this is a documented, deliberate
    simplification (sampling-without-replacement across a combinatorial
    space is a materially more complex algorithm) rather than a hidden
    limitation — callers needing exhaustive coverage should use GridSearch
    instead.
    """

    def __init__(self, space: ParameterSpace, n_samples: int, seed: int):
        if n_samples <= 0:
            raise ValueError(f"n_samples must be > 0, got {n_samples!r}")
        self.space = space
        self.n_samples = n_samples
        self.seed = seed

    def __iter__(self) -> Iterator[Dict[str, Any]]:
        rng = random.Random(self.seed)
        names = self.space.parameter_names
        for _ in range(self.n_samples):
            combo = {name: rng.choice(self.space.candidates[name]) for name in names}
            yield combo

    def __len__(self) -> int:
        return self.n_samples
