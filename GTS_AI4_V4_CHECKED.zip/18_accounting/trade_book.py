"""
trade_book.py
=============
MODULE   : 18_accounting
OWNER    : AI-4
PURPOSE  : Maintains the complete record of every executed trade
           (paper + live) as round-trip trade objects (entry + exit),
           independent of the raw fill-level ledger.

INPUT    : Fill events (entry & exit) from execution engines
OUTPUT   : TradeRecord objects (closed and open), trade history queries
CALLER   : 19_reporting.trade_report, 19_reporting.performance_report
CALLEE   : 18_accounting.ledger
DEPENDS  : ledger
"""

from __future__ import annotations
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional


class TradeStatus(Enum):
    OPEN = "OPEN"
    CLOSED = "CLOSED"


@dataclass
class TradeRecord:
    trade_id: str
    symbol: str
    strategy_id: Optional[str]
    side: str                       # LONG / SHORT
    entry_price: float
    entry_qty: float
    entry_time: float
    exit_price: Optional[float] = None
    exit_qty: float = 0.0
    exit_time: Optional[float] = None
    status: TradeStatus = TradeStatus.OPEN
    realized_pnl: float = 0.0
    fees: float = 0.0
    tags: Dict = field(default_factory=dict)

    def close(self, exit_price: float, exit_qty: float, exit_time: float = None):
        self.exit_price = exit_price
        self.exit_qty = exit_qty
        self.exit_time = exit_time or time.time()
        self.status = TradeStatus.CLOSED
        direction = 1 if self.side == "LONG" else -1
        self.realized_pnl = direction * (self.exit_price - self.entry_price) * self.exit_qty - self.fees


class TradeBook:
    """In-memory + optional persisted store of round-trip trades."""

    def __init__(self, storage=None):
        self.storage = storage
        self.trades: Dict[str, TradeRecord] = {}
        self._open_by_symbol_strategy: Dict[str, str] = {}  # key -> trade_id

    @staticmethod
    def _key(symbol: str, strategy_id: str) -> str:
        return f"{symbol}::{strategy_id}"

    def open_trade(self, symbol: str, strategy_id: str, side: str,
                    entry_price: float, entry_qty: float, fees: float = 0.0) -> TradeRecord:
        trade_id = str(uuid.uuid4())
        record = TradeRecord(
            trade_id=trade_id, symbol=symbol, strategy_id=strategy_id, side=side,
            entry_price=entry_price, entry_qty=entry_qty, entry_time=time.time(), fees=fees,
        )
        self.trades[trade_id] = record
        self._open_by_symbol_strategy[self._key(symbol, strategy_id)] = trade_id
        if self.storage is not None:
            self.storage.save_trade(record)
        return record

    def close_trade(self, symbol: str, strategy_id: str, exit_price: float,
                     exit_qty: float, extra_fees: float = 0.0) -> Optional[TradeRecord]:
        key = self._key(symbol, strategy_id)
        trade_id = self._open_by_symbol_strategy.pop(key, None)
        if not trade_id:
            return None
        record = self.trades[trade_id]
        record.fees += extra_fees
        record.close(exit_price, exit_qty)
        if self.storage is not None:
            self.storage.save_trade(record)
        return record

    def open_trades(self, strategy_id: str = None) -> List[TradeRecord]:
        trades = [t for t in self.trades.values() if t.status == TradeStatus.OPEN]
        if strategy_id:
            trades = [t for t in trades if t.strategy_id == strategy_id]
        return trades

    def closed_trades(self, strategy_id: str = None, symbol: str = None) -> List[TradeRecord]:
        trades = [t for t in self.trades.values() if t.status == TradeStatus.CLOSED]
        if strategy_id:
            trades = [t for t in trades if t.strategy_id == strategy_id]
        if symbol:
            trades = [t for t in trades if t.symbol == symbol]
        return trades

    def total_realized_pnl(self, strategy_id: str = None) -> float:
        return sum(t.realized_pnl for t in self.closed_trades(strategy_id=strategy_id))
