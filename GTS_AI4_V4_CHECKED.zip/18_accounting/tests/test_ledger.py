"""
test_ledger.py
MODULE: 18_accounting (tests)
OWNER : AI-4
Covers: buy/sell/fee/deposit/withdrawal posting, running balance, statement filtering.
"""

import sys, os, time
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from ledger import Ledger, EntryType


def test_deposit_increases_balance():
    ledger = Ledger(opening_balance=0)
    ledger.record_deposit(1000)
    assert ledger.current_balance() == 1000


def test_buy_decreases_balance():
    ledger = Ledger(opening_balance=1000)
    ledger.record_buy("NIFTY", 300)
    assert ledger.current_balance() == 700


def test_sell_increases_balance():
    ledger = Ledger(opening_balance=700)
    ledger.record_sell("NIFTY", 350)
    assert ledger.current_balance() == 1050


def test_fee_decreases_balance():
    ledger = Ledger(opening_balance=1050)
    ledger.record_fee(10)
    assert ledger.current_balance() == 1040


def test_statement_entry_types():
    ledger = Ledger(opening_balance=0)
    ledger.record_deposit(500)
    ledger.record_buy("GOLD", 100)
    entries = ledger.statement()
    types = [e.entry_type for e in entries]
    assert EntryType.DEPOSIT in types
    assert EntryType.TRADE_BUY in types


def test_adjustment_can_be_negative_or_positive():
    ledger = Ledger(opening_balance=100)
    ledger.record_adjustment(-20, note="correction")
    assert ledger.current_balance() == 80


if __name__ == "__main__":
    test_deposit_increases_balance()
    test_buy_decreases_balance()
    test_sell_increases_balance()
    test_fee_decreases_balance()
    test_statement_entry_types()
    test_adjustment_can_be_negative_or_positive()
    print("ledger: ALL TESTS PASSED")
