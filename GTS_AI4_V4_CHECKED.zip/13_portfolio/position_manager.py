"""
GTS — Global Trading System
Module   : 13_portfolio/position_manager.py
Owner    : AI-4

INPUT       : Fills from 14_execution/execution_engine.py, strategy_id
              tagging from 07_strategy.
OUTPUT      : Live position book — per-symbol and per-strategy views —
              consumed by 12_risk/exposure_manager.py and
              19_reporting/trade_report.py.
CALLER      : 13_portfolio/portfolio_manager.py.
CALLEE      : 13_portfolio/pnl_engine.py (delegates P&L math to it —
              position_manager.py owns "who holds what", pnl_engine.py
              owns "what is it worth").
DEPENDENCIES: Standard library only.

Purpose: maintain the authoritative record of open positions, broken
down both by symbol (for exposure_manager.py) and by strategy_id (so
each strategy's contribution to the book is independently visible, per
Master Blueprint's plugin-first, strategy-independent design).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from pnl_engine import Fill, PnLEngine, SymbolPosition


@dataclass
class StrategyPosition:
    strategy_id: str
    symbol: str
    quantity: float = 0.0
    avg_cost: float = 0.0


class PositionManager:
    """
    Tracks open positions at both the portfolio level (via PnLEngine) and
    the strategy level (via an internal per-strategy ledger).

    Usage
    -----
        manager = PositionManager(starting_equity=100_000)
        manager.apply_fill(Fill("NIFTY", "BUY", 10, 20000), strategy_id="expiry_v1")
        manager.mark({"NIFTY": 20150})
        book = manager.symbol_positions()
        by_strategy = manager.strategy_positions()
    """

    def __init__(self, starting_equity: float) -> None:
        self.pnl_engine = PnLEngine(starting_equity=starting_equity)
        self._strategy_positions: dict[tuple[str, str], StrategyPosition] = {}
        self._fill_log: list[tuple[str, Fill]] = []  # (strategy_id, fill)

    # ------------------------------------------------------------------ #

    def apply_fill(self, fill: Fill, strategy_id: str) -> SymbolPosition:
        """Route a fill into both the portfolio book and the strategy book."""
        self._fill_log.append((strategy_id, fill))

        symbol_pos = self.pnl_engine.apply_fill(fill)
        self._apply_strategy_fill(fill, strategy_id)
        return symbol_pos

    def mark(self, mark_prices: dict[str, float]) -> None:
        self.pnl_engine.mark(mark_prices)

    def symbol_positions(self) -> dict[str, SymbolPosition]:
        """Portfolio-level positions, keyed by symbol."""
        return dict(self.pnl_engine.positions)

    def strategy_positions(self, strategy_id: str | None = None) -> list[StrategyPosition]:
        """
        Strategy-level positions. Pass strategy_id to filter to one
        strategy, or omit to get every strategy's open positions.
        """
        positions = list(self._strategy_positions.values())
        if strategy_id is not None:
            positions = [p for p in positions if p.strategy_id == strategy_id]
        return [p for p in positions if p.quantity != 0]

    def net_exposure_by_symbol(self) -> dict[str, float]:
        """Signed net quantity per symbol, used by exposure_manager.py."""
        return {sym: pos.quantity for sym, pos in self.pnl_engine.positions.items()}

    def gross_exposure(self, mark_prices: dict[str, float] | None = None) -> float:
        """Sum of |quantity * price| across all open positions."""
        marks = mark_prices or self.pnl_engine._marks  # fall back to last known marks
        total = 0.0
        for symbol, pos in self.pnl_engine.positions.items():
            price = marks.get(symbol, pos.avg_cost)
            total += abs(pos.quantity) * price
        return total

    def fill_history(self, strategy_id: str | None = None) -> list[tuple[str, Fill]]:
        if strategy_id is None:
            return list(self._fill_log)
        return [(sid, f) for sid, f in self._fill_log if sid == strategy_id]

    # ------------------------------------------------------------------ #

    def _apply_strategy_fill(self, fill: Fill, strategy_id: str) -> None:
        key = (strategy_id, fill.symbol)
        pos = self._strategy_positions.setdefault(
            key, StrategyPosition(strategy_id=strategy_id, symbol=fill.symbol)
        )
        direction = 1 if fill.side.upper() in ("BUY", "LONG") else -1
        fill_qty = direction * fill.quantity

        if pos.quantity == 0 or (pos.quantity > 0) == (fill_qty > 0):
            new_qty = pos.quantity + fill_qty
            if new_qty != 0:
                pos.avg_cost = (
                    (pos.avg_cost * abs(pos.quantity)) + (fill.price * abs(fill_qty))
                ) / abs(new_qty)
            pos.quantity = new_qty
        else:
            closing_qty = min(abs(fill_qty), abs(pos.quantity))
            remaining_fill_qty = abs(fill_qty) - closing_qty
            new_qty = pos.quantity + fill_qty
            pos.quantity = new_qty
            if remaining_fill_qty > 0:
                pos.avg_cost = fill.price
            elif new_qty == 0:
                pos.avg_cost = 0.0

        self._strategy_positions[key] = pos


def main(argv: list[str] | None = None) -> int:
    """CLI smoke-test: python position_manager.py"""
    manager = PositionManager(starting_equity=100_000)
    manager.apply_fill(Fill("NIFTY", "BUY", 10, 20000), strategy_id="expiry_v1")
    manager.apply_fill(Fill("BANKNIFTY", "SELL", 5, 45000), strategy_id="scalper_v2")
    manager.mark({"NIFTY": 20150, "BANKNIFTY": 44900})

    print("Symbol positions:", manager.symbol_positions())
    print("Strategy positions:", manager.strategy_positions())
    print("Gross exposure:", manager.gross_exposure())
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
