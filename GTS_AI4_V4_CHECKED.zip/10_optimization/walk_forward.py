"""
GTS — Global Trading System
Module   : 10_optimization
File     : walk_forward.py
Owner    : AI-4 (Backtest + Risk + Execution + Production)

PURPOSE
-------
Splits an ordered sequence of historical bars into rolling train/test
windows, runs optimizer.py's Optimizer on each window's train segment to
find the best parameters, then evaluates those exact parameters
out-of-sample on the corresponding test segment. This is the walk-forward
validation step required by the Master Blueprint's production gate
("Backtest -> Optimization -> Walk Forward -> Stress Test -> ...") before
any strategy is eligible for paper trading.

CONTRACT
--------
INPUT      : An ordered sequence of bars (any type — this file is
             data-shape-agnostic; it only needs a way to read each bar's
             time to slice windows and to hand bar sub-sequences to
             caller-supplied objective builders), plus caller-supplied
             functions that build a train objective function and evaluate
             a parameter set out-of-sample on test bars.
OUTPUT     : List[WalkForwardResult], one per window, each carrying the
             best in-sample parameters, their in-sample metric, and the
             resulting out-of-sample metric.
CALLER     : A human/operator script running full walk-forward validation
             for a strategy before it is allowed into 16_paper_trading,
             per the production gate.
CALLEE     : optimizer.py (Optimizer, OptimizationResult) — same module,
             sibling file.
DEPENDENCIES: optimizer.py (sibling file) + Python standard library only.

ARCHITECTURAL RULES ENFORCED
-----------------------------
- No guessing / no lookahead: windows are strictly ordered and
  non-overlapping between a window's train segment and that same window's
  test segment (test always starts exactly where train ends); a window
  whose test segment would need bars beyond the end of the supplied data
  is never fabricated — window generation simply stops.
- If in-sample optimization finds no successful parameter combination for
  a window (Optimizer.best() returns None), that window's out-of-sample
  test is skipped entirely and recorded with skipped=True — a test is
  never run with fabricated or default parameters standing in for a
  failed optimization.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, TypeVar

from optimizer import Optimizer, OptimizationResult

logger = logging.getLogger("gts.optimization.walk_forward")

Bar = TypeVar("Bar")  # any bar representation the caller uses; this file never inspects its fields directly


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class WalkForwardError(Exception):
    """Base exception for all walk_forward failures."""


class InvalidWindowConfigError(WalkForwardError):
    """Raised when train_size, test_size, or step are non-positive."""


# ---------------------------------------------------------------------------
# Window definition
# ---------------------------------------------------------------------------

@dataclass
class WalkForwardWindow:
    """One rolling train/test split, expressed as index ranges into the
    original bar sequence plus the actual bar sub-sequences for
    convenience (so callers don't need to re-slice)."""

    window_index: int
    train_start_index: int
    train_end_index: int  # exclusive
    test_start_index: int
    test_end_index: int  # exclusive
    train_bars: Sequence[Bar]
    test_bars: Sequence[Bar]


def generate_windows(
    bars: Sequence[Bar],
    train_size: int,
    test_size: int,
    step: Optional[int] = None,
) -> List[WalkForwardWindow]:
    """Generate rolling walk-forward windows over `bars`.

    Args:
        bars: full ordered bar sequence (already validated for
            chronological order upstream — this function trusts the
            sequence order given, per "no guessing": it does not
            re-inspect timestamps, since it is deliberately
            data-shape-agnostic about what a "bar" is).
        train_size: number of bars in each window's train segment. Must
            be > 0.
        test_size: number of bars in each window's test segment,
            immediately following the train segment with no gap and no
            overlap. Must be > 0.
        step: number of bars to advance the window start by between
            windows. Defaults to test_size (the standard "anchored roll
            forward by exactly one test period" walk-forward scheme).
            Must be > 0 if given.

    Returns:
        A list of WalkForwardWindow, in order. The list may be empty if
        `bars` is shorter than train_size + test_size — that is not an
        error, since a caller may legitimately be probing whether enough
        data exists yet.

    Raises:
        InvalidWindowConfigError: if train_size, test_size, or step is
            not a positive integer.
    """
    if train_size <= 0:
        raise InvalidWindowConfigError(f"train_size must be > 0, got {train_size!r}")
    if test_size <= 0:
        raise InvalidWindowConfigError(f"test_size must be > 0, got {test_size!r}")
    resolved_step = step if step is not None else test_size
    if resolved_step <= 0:
        raise InvalidWindowConfigError(f"step must be > 0, got {step!r}")

    windows: List[WalkForwardWindow] = []
    total = len(bars)
    start = 0
    index = 0
    while True:
        train_start = start
        train_end = train_start + train_size
        test_start = train_end
        test_end = test_start + test_size
        if test_end > total:
            break
        windows.append(
            WalkForwardWindow(
                window_index=index,
                train_start_index=train_start,
                train_end_index=train_end,
                test_start_index=test_start,
                test_end_index=test_end,
                train_bars=bars[train_start:train_end],
                test_bars=bars[test_start:test_end],
            )
        )
        start += resolved_step
        index += 1
    return windows


# ---------------------------------------------------------------------------
# Walk-forward result
# ---------------------------------------------------------------------------

@dataclass
class WalkForwardResult:
    """Outcome of one window's optimize-on-train, evaluate-on-test cycle."""

    window: WalkForwardWindow
    skipped: bool
    skip_reason: Optional[str] = None
    best_params: Optional[Dict[str, Any]] = None
    train_metric_value: Optional[float] = None
    train_results_count: int = 0
    test_summary: Optional[Dict[str, object]] = None
    test_metric_value: Optional[float] = None


# ---------------------------------------------------------------------------
# Walk-forward runner
# ---------------------------------------------------------------------------

# Given a window's train bars, return an objective function suitable for
# optimizer.Optimizer (i.e. Callable[[params_dict], summary_dict]).
TrainObjectiveBuilder = Callable[[Sequence[Bar]], Callable[[Dict[str, Any]], Dict[str, object]]]

# Given a chosen parameter set and a window's test bars, return the
# out-of-sample summary dict (same shape objective functions return).
TestEvaluator = Callable[[Dict[str, Any], Sequence[Bar]], Dict[str, object]]


class WalkForwardRunner:
    """Drives optimizer.Optimizer across every window from generate_windows,
    then evaluates the winning in-sample parameters out-of-sample.

    Example:
        def build_train_objective(train_bars):
            def objective(params):
                bt = BacktestEngine(starting_cash=100000.0, ...)
                wire_my_strategy(bt, **params)
                return bt.run(train_bars).summary
            return objective

        def evaluate_test(params, test_bars):
            bt = BacktestEngine(starting_cash=100000.0, ...)
            wire_my_strategy(bt, **params)
            return bt.run(test_bars).summary

        runner = WalkForwardRunner(
            build_train_objective, evaluate_test,
            metric_name="sharpe_ratio", maximize=True,
        )
        results = runner.run(windows, param_combinations_factory=lambda: GridSearch(space))
    """

    def __init__(
        self,
        build_train_objective: TrainObjectiveBuilder,
        evaluate_test: TestEvaluator,
        metric_name: str,
        maximize: bool = True,
    ):
        self.build_train_objective = build_train_objective
        self.evaluate_test = evaluate_test
        self.metric_name = metric_name
        self.maximize = maximize

    def run(
        self,
        windows: Iterable[WalkForwardWindow],
        param_combinations_factory: Callable[[], Iterable[Dict[str, Any]]],
    ) -> List[WalkForwardResult]:
        """Run the full walk-forward cycle over `windows`.

        Args:
            windows: typically the output of generate_windows.
            param_combinations_factory: a zero-arg callable returning a
                fresh iterable of parameter combinations for each window
                (e.g. `lambda: GridSearch(space)`) — called once per
                window so a single-use iterator (like a generator
                expression) is never exhausted after window #1.

        Returns:
            One WalkForwardResult per window, in order.
        """
        results: List[WalkForwardResult] = []
        for window in windows:
            results.append(self._run_one_window(window, param_combinations_factory))
        return results

    def _run_one_window(
        self,
        window: WalkForwardWindow,
        param_combinations_factory: Callable[[], Iterable[Dict[str, Any]]],
    ) -> WalkForwardResult:
        train_objective = self.build_train_objective(window.train_bars)
        optimizer = Optimizer(train_objective, metric_name=self.metric_name, maximize=self.maximize)
        train_results: List[OptimizationResult] = optimizer.run(param_combinations_factory())

        best = optimizer.best(train_results)
        if best is None:
            logger.warning(
                "Window %d: no successful in-sample optimization result — skipping out-of-sample test",
                window.window_index,
            )
            return WalkForwardResult(
                window=window,
                skipped=True,
                skip_reason="no successful in-sample optimization result",
                train_results_count=len(train_results),
            )

        try:
            test_summary = self.evaluate_test(best.params, window.test_bars)
        except Exception as exc:  # noqa: BLE001 - isolate one window's OOS failure from the rest of the run
            logger.error(
                "Window %d: evaluate_test raised for best in-sample params %s: %s",
                window.window_index, best.params, exc, exc_info=True,
            )
            return WalkForwardResult(
                window=window,
                skipped=True,
                skip_reason=f"evaluate_test raised {type(exc).__name__}: {exc}",
                best_params=best.params,
                train_metric_value=best.metric_value,
                train_results_count=len(train_results),
            )

        test_metric_value = None
        if isinstance(test_summary, dict) and self.metric_name in test_summary:
            raw = test_summary[self.metric_name]
            if raw is not None:
                try:
                    test_metric_value = float(raw)
                except (TypeError, ValueError):
                    logger.warning(
                        "Window %d: out-of-sample metric '%s' value %r is not numeric",
                        window.window_index, self.metric_name, raw,
                    )

        return WalkForwardResult(
            window=window,
            skipped=False,
            best_params=best.params,
            train_metric_value=best.metric_value,
            train_results_count=len(train_results),
            test_summary=test_summary if isinstance(test_summary, dict) else None,
            test_metric_value=test_metric_value,
        )

    @staticmethod
    def average_out_of_sample_metric(results: List[WalkForwardResult]) -> Optional[float]:
        """Return the mean test_metric_value across all non-skipped
        results, or None if every window was skipped or had no numeric
        out-of-sample metric. Used as the single headline number
        summarizing walk-forward robustness across all windows."""
        values = [r.test_metric_value for r in results if not r.skipped and r.test_metric_value is not None]
        if not values:
            return None
        return sum(values) / len(values)
