GTS CLEAN VERIFIED MASTER PACK v1.0

Included verified/explicitly OK source packs:
1. GTS_V2.zip — LOCKED VERIFIED; options trading implementation incl. Greeks/Option Chain.
2. GTS_01_market_data_COMPLETED-8.zip — completed market-data pack.
3. GTS_02_instruments_COMPLETED-10.zip — completed instruments pack.
4. GTS_NewsEngine_V5_OK-1.zip — explicitly marked OK news engine pack.

Important:
- These source ZIPs are preserved as-is; no code was rewritten or merged in this cleanup pack.
- This is a conservative clean pack. Other source packs from the large collection were NOT included merely because they contain files; they remain candidates for separate code-level review.
- GTS V2 is locked and must not be modified/repaired/replaced/deleted.
