"""
test_paper_engine.py
MODULE: 16_paper_trading (tests)
OWNER : AI-4
Covers: order placement, market/limit fill logic, PnL, account snapshot.
"""

import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from paper_engine import PaperEngine, PaperAccount, OrderSide, OrderStatus


def test_market_buy_fills_immediately():
    engine = PaperEngine(account=PaperAccount(starting_capital=100000))
    engine.update_market_price("NIFTY", 100.0)
    order = engine.place_order("NIFTY", OrderSide.BUY, 10, order_type="MARKET")
    assert order.status == OrderStatus.FILLED
    assert order.filled_qty == 10
    assert engine.account.positions["NIFTY"]["qty"] == 10


def test_limit_buy_stays_pending_above_market():
    engine = PaperEngine()
    engine.update_market_price("NIFTY", 100.0)
    order = engine.place_order("NIFTY", OrderSide.BUY, 5, order_type="LIMIT", limit_price=95.0)
    assert order.status == OrderStatus.PENDING


def test_no_market_price_rejects_order():
    engine = PaperEngine()
    order = engine.place_order("UNKNOWN", OrderSide.BUY, 1)
    assert order.status == OrderStatus.REJECTED


def test_sell_realizes_pnl():
    engine = PaperEngine(account=PaperAccount(starting_capital=100000))
    engine.update_market_price("GOLD", 50.0)
    engine.place_order("GOLD", OrderSide.BUY, 2)
    engine.update_market_price("GOLD", 60.0)
    engine.place_order("GOLD", OrderSide.SELL, 2)
    assert engine.account.realized_pnl > 0


def test_cancel_pending_order():
    engine = PaperEngine()
    engine.update_market_price("SILVER", 10.0)
    order = engine.place_order("SILVER", OrderSide.BUY, 1, order_type="LIMIT", limit_price=5.0)
    assert engine.cancel_order(order.order_id) is True
    assert order.status == OrderStatus.CANCELLED


def test_account_snapshot_keys():
    engine = PaperEngine()
    snap = engine.account_snapshot()
    for key in ("cash", "realized_pnl", "unrealized_pnl", "equity", "positions"):
        assert key in snap


if __name__ == "__main__":
    test_market_buy_fills_immediately()
    test_limit_buy_stays_pending_above_market()
    test_no_market_price_rejects_order()
    test_sell_realizes_pnl()
    test_cancel_pending_order()
    test_account_snapshot_keys()
    print("paper_engine: ALL TESTS PASSED")
