"""
GTS — Global Trading System
Module   : 12_risk/drawdown_guard.py
Owner    : AI-4

INPUT       : Current equity and peak (high-water-mark) equity from
              13_portfolio/pnl_engine.py.
OUTPUT      : DrawdownCheckResult — breached flag + current drawdown %.
CALLER      : 12_risk/risk_engine.py.
CALLEE      : None outside stdlib.
DEPENDENCIES: Standard library only.

Purpose: track drawdown from the equity high-water mark and signal a
breach once it exceeds the configured limit. Supports tiered warning
levels so operators get advance notice before the hard stop trips.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class DrawdownCheckResult:
    breached: bool
    current_drawdown_pct: float
    warning_level: str  # "NONE", "CAUTION", "WARNING", "BREACH"
    message: str = ""
    evaluated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class DrawdownGuard:
    """
    Tracks equity drawdown from its running peak and flags a breach when
    the configured maximum drawdown is exceeded.

    Usage
    -----
        guard = DrawdownGuard(max_drawdown_pct=0.20)
        result = guard.check(equity=82_000, peak_equity=100_000)
        # result.current_drawdown_pct == 0.18, result.breached == False
    """

    def __init__(
        self,
        max_drawdown_pct: float,
        caution_threshold_pct: float = 0.5,
        warning_threshold_pct: float = 0.8,
    ) -> None:
        if not (0 < max_drawdown_pct <= 1):
            raise ValueError("max_drawdown_pct must be in (0, 1].")
        if not (0 < caution_threshold_pct < warning_threshold_pct < 1):
            raise ValueError(
                "Thresholds must satisfy 0 < caution < warning < 1 (as "
                "fractions of max_drawdown_pct)."
            )
        self.max_drawdown_pct = max_drawdown_pct
        self.caution_threshold_pct = caution_threshold_pct
        self.warning_threshold_pct = warning_threshold_pct

    # ------------------------------------------------------------------ #

    def check(self, equity: float, peak_equity: float) -> DrawdownCheckResult:
        if peak_equity <= 0:
            return DrawdownCheckResult(
                breached=True, current_drawdown_pct=1.0, warning_level="BREACH",
                message=f"Invalid peak_equity ({peak_equity}) — treating as full breach.",
            )

        effective_peak = max(peak_equity, equity)
        drawdown_pct = max(0.0, (effective_peak - equity) / effective_peak)

        if drawdown_pct >= self.max_drawdown_pct:
            return DrawdownCheckResult(
                breached=True,
                current_drawdown_pct=drawdown_pct,
                warning_level="BREACH",
                message=(
                    f"Drawdown {drawdown_pct:.2%} has breached the maximum "
                    f"allowed {self.max_drawdown_pct:.2%}. Trading must halt."
                ),
            )

        ratio = drawdown_pct / self.max_drawdown_pct
        if ratio >= self.warning_threshold_pct:
            level, msg = "WARNING", (
                f"Drawdown {drawdown_pct:.2%} is at {ratio:.0%} of the "
                f"{self.max_drawdown_pct:.2%} limit — approaching breach."
            )
        elif ratio >= self.caution_threshold_pct:
            level, msg = "CAUTION", (
                f"Drawdown {drawdown_pct:.2%} is at {ratio:.0%} of the "
                f"{self.max_drawdown_pct:.2%} limit."
            )
        else:
            level, msg = "NONE", ""

        return DrawdownCheckResult(
            breached=False, current_drawdown_pct=drawdown_pct,
            warning_level=level, message=msg,
        )


def main(argv: list[str] | None = None) -> int:
    """CLI smoke-test: python drawdown_guard.py"""
    guard = DrawdownGuard(max_drawdown_pct=0.20)
    for equity in (100_000, 92_000, 84_000, 79_000):
        result = guard.check(equity=equity, peak_equity=100_000)
        print(f"equity={equity} -> {result.warning_level} dd={result.current_drawdown_pct:.2%} {result.message}")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
