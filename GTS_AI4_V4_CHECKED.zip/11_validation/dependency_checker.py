"""
GTS — Global Trading System
Module   : 11_validation/dependency_checker.py
Owner    : AI-4

INPUT       : Path to the GTS source tree (or a module manifest describing
              INPUT/OUTPUT/CALLER/CALLEE per file, per Master Blueprint
              rule "Every module has defined INPUT / OUTPUT / CALLER /
              CALLEE / DEPENDENCIES").
OUTPUT      : DependencyCheckResult — pass/fail + list of DependencyIssue.
CALLER      : 11_validation/qa_gate.py, CI pipeline.
CALLEE      : Python stdlib (ast, pathlib) only.
DEPENDENCIES: None outside the Python standard library.

Purpose:
  1. Build an import graph of the GTS codebase from source (AST-based,
     no execution).
  2. Detect circular imports between modules.
  3. Detect forbidden cross-layer imports — e.g. 09_backtest must not
     import from 17_live_trading (a lower/earlier pipeline stage must
     never depend on a later one), per the pipeline order defined in the
     Master Blueprint:
     market_data -> ... -> backtest -> optimization -> validation ->
     risk -> portfolio -> execution -> broker -> paper_trading ->
     live_trading -> accounting -> reporting.
  4. Detect references to third-party packages that are not present in
     requirements.txt (if provided).
"""

from __future__ import annotations

import ast
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path

logger = logging.getLogger("gts.validation.dependency_checker")
if not logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"))
    logger.addHandler(_h)
    logger.setLevel(logging.INFO)


class Severity(str, Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    BLOCKER = "BLOCKER"


@dataclass(frozen=True)
class DependencyIssue:
    rule_id: str
    severity: Severity
    message: str
    file: str = ""

    def __str__(self) -> str:  # pragma: no cover
        loc = f" @ {self.file}" if self.file else ""
        return f"[{self.severity.value}] {self.rule_id}{loc} — {self.message}"


@dataclass
class DependencyCheckResult:
    passed: bool
    issues: list[DependencyIssue] = field(default_factory=list)
    checked_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @property
    def blockers(self) -> list[DependencyIssue]:
        return [i for i in self.issues if i.severity == Severity.BLOCKER]

    @property
    def warnings(self) -> list[DependencyIssue]:
        return [i for i in self.issues if i.severity == Severity.WARNING]

    def summary(self) -> str:
        status = "PASS" if self.passed else "FAIL"
        return (
            f"DependencyChecker {status} — {len(self.blockers)} blocker(s), "
            f"{len(self.warnings)} warning(s)"
        )


# Pipeline order per Master Blueprint section 4 / 5. A module in an earlier
# stage may not import from a later stage's package.
PIPELINE_ORDER: list[str] = [
    "01_market_data", "02_instruments", "03_data_engine", "04_indicators",
    "05_market_analysis", "06_options_engine", "07_strategy", "08_signal_engine",
    "09_backtest", "10_optimization", "11_validation", "12_risk",
    "13_portfolio", "14_execution", "15_broker", "16_paper_trading",
    "17_live_trading", "18_accounting", "19_reporting",
]

# Packages every GTS module may always use regardless of pipeline stage.
SHARED_PACKAGES = {"20_dashboard", "21_ai", "22_security", "23_database",
                    "24_api", "25_scheduler", "26_notifications",
                    "27_system", "28_tests", "29_docs"}

STDLIB_ALLOWLIST_HINT = {
    # A small, non-exhaustive hint set used only to avoid false positives
    # for extremely common stdlib modules when no requirements.txt is given.
    "os", "sys", "json", "math", "time", "datetime", "logging", "typing",
    "dataclasses", "enum", "pathlib", "collections", "itertools",
    "functools", "re", "ast", "tempfile", "unittest", "abc", "copy",
    "decimal", "statistics", "threading", "asyncio", "queue", "uuid",
    "hashlib", "hmac", "socket", "struct", "io", "csv", "sqlite3",
}


@dataclass
class _ModuleNode:
    path: Path
    package: str  # e.g. "09_backtest"
    imports: set[str] = field(default_factory=set)  # top-level import roots
    internal_imports: set[str] = field(default_factory=set)  # GTS package names imported


class DependencyChecker:
    """
    Static import-graph checker for the GTS monorepo.

    Usage
    -----
        checker = DependencyChecker(root="GTS/")
        result = checker.check()
    """

    def __init__(self, root: str | Path, requirements_file: str | Path | None = None) -> None:
        self.root = Path(root)
        self.requirements_file = Path(requirements_file) if requirements_file else None

    # ------------------------------------------------------------------ #

    def check(self) -> DependencyCheckResult:
        issues: list[DependencyIssue] = []

        nodes = self._scan()
        issues += self._check_pipeline_order(nodes)
        issues += self._check_circular_imports(nodes)
        if self.requirements_file is not None:
            issues += self._check_third_party_deps(nodes)

        passed = not any(i.severity == Severity.BLOCKER for i in issues)
        result = DependencyCheckResult(passed=passed, issues=issues)
        logger.info(result.summary())
        return result

    # ------------------------------------------------------------------ #

    def _scan(self) -> list[_ModuleNode]:
        nodes: list[_ModuleNode] = []
        if not self.root.exists():
            logger.warning("Root path does not exist: %s", self.root)
            return nodes

        for py_file in sorted(self.root.rglob("*.py")):
            try:
                rel = py_file.relative_to(self.root)
            except ValueError:
                continue
            package = rel.parts[0] if rel.parts else ""
            try:
                source = py_file.read_text(encoding="utf-8")
                tree = ast.parse(source, filename=str(py_file))
            except (SyntaxError, OSError, UnicodeDecodeError) as exc:
                logger.warning("Skipping unparsable file %s: %s", py_file, exc)
                continue

            node = _ModuleNode(path=py_file, package=package)
            for stmt in ast.walk(tree):
                if isinstance(stmt, ast.Import):
                    for alias in stmt.names:
                        root_name = alias.name.split(".")[0]
                        node.imports.add(root_name)
                        if self._looks_like_gts_package(root_name):
                            node.internal_imports.add(root_name)
                elif isinstance(stmt, ast.ImportFrom):
                    if stmt.module:
                        root_name = stmt.module.split(".")[0]
                        node.imports.add(root_name)
                        if self._looks_like_gts_package(root_name):
                            node.internal_imports.add(root_name)
            nodes.append(node)
        return nodes

    @staticmethod
    def _looks_like_gts_package(name: str) -> bool:
        # GTS packages are named like "09_backtest", "12_risk", etc.
        parts = name.split("_", 1)
        return len(parts) == 2 and parts[0].isdigit()

    def _check_pipeline_order(self, nodes: list[_ModuleNode]) -> list[DependencyIssue]:
        issues: list[DependencyIssue] = []
        for node in nodes:
            if node.package not in PIPELINE_ORDER:
                continue
            own_index = PIPELINE_ORDER.index(node.package)
            for imported_pkg in node.internal_imports:
                if imported_pkg in SHARED_PACKAGES or imported_pkg == node.package:
                    continue
                if imported_pkg not in PIPELINE_ORDER:
                    continue
                imported_index = PIPELINE_ORDER.index(imported_pkg)
                if imported_index > own_index:
                    issues.append(
                        DependencyIssue(
                            "GTS-DEP-001", Severity.BLOCKER,
                            f"'{node.package}' imports from later pipeline "
                            f"stage '{imported_pkg}' — earlier stages must "
                            f"not depend on later ones.",
                            file=str(node.path),
                        )
                    )
        return issues

    def _check_circular_imports(self, nodes: list[_ModuleNode]) -> list[DependencyIssue]:
        """Detect cycles at package granularity using DFS."""
        graph: dict[str, set[str]] = {}
        for node in nodes:
            graph.setdefault(node.package, set())
            for dep in node.internal_imports:
                if dep != node.package:
                    graph[node.package].add(dep)

        issues: list[DependencyIssue] = []
        visited: set[str] = set()
        stack: list[str] = []

        def dfs(pkg: str) -> None:
            if pkg in stack:
                cycle = " -> ".join(stack[stack.index(pkg):] + [pkg])
                issues.append(
                    DependencyIssue(
                        "GTS-DEP-002", Severity.BLOCKER,
                        f"Circular package dependency detected: {cycle}",
                    )
                )
                return
            if pkg in visited:
                return
            visited.add(pkg)
            stack.append(pkg)
            for dep in graph.get(pkg, ()):
                dfs(dep)
            stack.pop()

        for pkg in graph:
            dfs(pkg)
        return issues

    def _check_third_party_deps(self, nodes: list[_ModuleNode]) -> list[DependencyIssue]:
        issues: list[DependencyIssue] = []
        assert self.requirements_file is not None
        if not self.requirements_file.exists():
            issues.append(
                DependencyIssue(
                    "GTS-DEP-003", Severity.WARNING,
                    f"requirements.txt not found at {self.requirements_file}; "
                    f"skipping third-party dependency check.",
                )
            )
            return issues

        declared: set[str] = set()
        for line in self.requirements_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            pkg_name = line.split("==")[0].split(">=")[0].split("<=")[0].strip()
            declared.add(pkg_name.lower().replace("-", "_"))

        for node in nodes:
            for imported in node.imports:
                if imported in node.internal_imports:
                    continue
                if imported in STDLIB_ALLOWLIST_HINT:
                    continue
                if imported.lower().replace("-", "_") not in declared:
                    issues.append(
                        DependencyIssue(
                            "GTS-DEP-004", Severity.WARNING,
                            f"Import '{imported}' is not declared in "
                            f"requirements.txt (may be stdlib — verify).",
                            file=str(node.path),
                        )
                    )
        return issues


def main(argv: list[str] | None = None) -> int:
    """
    CLI usage:
        python dependency_checker.py <gts_root> [requirements.txt]
    """
    import sys

    args = argv if argv is not None else sys.argv[1:]
    if not args:
        print("Usage: python dependency_checker.py <gts_root> [requirements.txt]")
        return 2

    root = args[0]
    requirements = args[1] if len(args) > 1 else None
    checker = DependencyChecker(root=root, requirements_file=requirements)
    result = checker.check()

    for issue in result.issues:
        print(issue)
    print(result.summary())
    return 0 if result.passed else 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
