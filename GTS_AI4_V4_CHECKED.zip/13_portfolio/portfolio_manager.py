"""
GTS — Global Trading System
Module   : 13_portfolio/portfolio_manager.py
Owner    : AI-4

INPUT       : Fills from 14_execution, mark prices from 01_market_data.
OUTPUT      : PortfolioState — the single snapshot object consumed by
              12_risk/risk_engine.py on every order evaluation.
CALLER      : 14_execution/execution_engine.py (after each fill),
              12_risk/risk_engine.py (reads current state before each
              order), 19_reporting/performance_report.py.
CALLEE       : 13_portfolio/position_manager.py, 13_portfolio/pnl_engine.py
              (via position_manager).
DEPENDENCIES: Standard library only.

Purpose: orchestrator for the whole 13_portfolio package. This is the
one object other packages should hold a reference to — it composes
position tracking and P&L into the single PortfolioState snapshot shape
that risk_engine.py expects, and provides the order-rate-limiting counter
risk_engine.py needs.
"""

from __future__ import annotations

import logging
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

from pnl_engine import Fill
from position_manager import PositionManager

logger = logging.getLogger("gts.portfolio.portfolio_manager")
if not logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"))
    logger.addHandler(_h)
    logger.setLevel(logging.INFO)


@dataclass
class PortfolioSnapshot:
    """Rich, reporting-oriented view. risk_engine.py uses the leaner
    PortfolioState shape (built via to_risk_state()) instead."""
    equity: float
    peak_equity: float
    realized_pnl: float
    unrealized_pnl: float
    daily_realized_pnl: float
    gross_exposure: float
    symbol_positions: dict[str, float]
    taken_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class PortfolioManager:
    """
    Top-level orchestrator: owns the position book, the P&L engine, and
    an order-rate tracker, and produces the state object risk_engine.py
    consumes before every order decision.

    Usage
    -----
        pm = PortfolioManager(starting_equity=100_000)
        pm.record_fill(Fill("NIFTY", "BUY", 10, 20000), strategy_id="expiry_v1")
        pm.record_order_submitted()
        pm.mark({"NIFTY": 20150})
        risk_state = pm.to_risk_state(kill_switch_active=False)
    """

    def __init__(self, starting_equity: float, order_rate_window_seconds: float = 60.0) -> None:
        self.position_manager = PositionManager(starting_equity=starting_equity)
        self.order_rate_window_seconds = order_rate_window_seconds
        self._order_timestamps: deque[datetime] = deque()

    # ------------------------------------------------------------------ #

    def record_fill(self, fill: Fill, strategy_id: str) -> None:
        self.position_manager.apply_fill(fill, strategy_id=strategy_id)
        logger.info(
            "Fill recorded: %s %s %s @ %s (strategy=%s)",
            fill.side, fill.quantity, fill.symbol, fill.price, strategy_id,
        )

    def mark(self, mark_prices: dict[str, float]) -> None:
        self.position_manager.mark(mark_prices)

    def record_order_submitted(self, at: datetime | None = None) -> None:
        """Call once per order submitted, so risk_engine.py can rate-limit."""
        now = at or datetime.now(timezone.utc)
        self._order_timestamps.append(now)
        self._prune_order_timestamps(now)

    def orders_in_current_window(self, at: datetime | None = None) -> int:
        now = at or datetime.now(timezone.utc)
        self._prune_order_timestamps(now)
        return len(self._order_timestamps)

    def snapshot(self) -> PortfolioSnapshot:
        pnl = self.position_manager.pnl_engine.snapshot()
        return PortfolioSnapshot(
            equity=pnl.equity,
            peak_equity=pnl.peak_equity,
            realized_pnl=pnl.realized_pnl,
            unrealized_pnl=pnl.unrealized_pnl,
            daily_realized_pnl=pnl.daily_realized_pnl,
            gross_exposure=self.position_manager.gross_exposure(),
            symbol_positions=self.position_manager.net_exposure_by_symbol(),
        )

    def to_risk_state(self, kill_switch_active: bool = False):
        """
        Build the exact PortfolioState shape that
        12_risk/risk_engine.py.PortfolioState expects. Imported lazily to
        avoid a hard import-time dependency from 13_portfolio on 12_risk
        (pipeline order: risk is downstream of portfolio's own package
        listing, but risk_engine consumes portfolio state, not the other
        way around — this keeps the dependency direction correct).
        """
        from risk_engine import PortfolioState  # local import: see docstring

        snap = self.snapshot()
        return PortfolioState(
            equity=snap.equity,
            peak_equity=snap.peak_equity,
            daily_realized_pnl=snap.daily_realized_pnl,
            positions=snap.symbol_positions,
            gross_exposure=snap.gross_exposure,
            orders_this_minute=self.orders_in_current_window(),
            kill_switch_active=kill_switch_active,
        )

    # ------------------------------------------------------------------ #

    def _prune_order_timestamps(self, now: datetime) -> None:
        cutoff = now - timedelta(seconds=self.order_rate_window_seconds)
        while self._order_timestamps and self._order_timestamps[0] < cutoff:
            self._order_timestamps.popleft()


def main(argv: list[str] | None = None) -> int:
    """CLI smoke-test: python portfolio_manager.py"""
    pm = PortfolioManager(starting_equity=100_000)
    pm.record_fill(Fill("NIFTY", "BUY", 10, 20000), strategy_id="expiry_v1")
    pm.record_order_submitted()
    pm.mark({"NIFTY": 20150})

    snap = pm.snapshot()
    print(f"equity={snap.equity:.2f} gross_exposure={snap.gross_exposure:.2f}")
    print("orders in window:", pm.orders_in_current_window())
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
