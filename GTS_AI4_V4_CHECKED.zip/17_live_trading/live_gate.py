"""
live_gate.py
============
MODULE   : 17_live_trading
OWNER    : AI-4
PURPOSE  : Final go/no-go checkpoint before ANY order reaches the live
           broker. Enforces the production gate defined in the AI-4
           blueprint:
           Backtest -> Optimization -> Walk Forward -> Stress Test ->
           Risk Test -> QA -> Paper Trade -> Live Approval

INPUT    : Candidate LiveOrder + strategy validation/approval records
OUTPUT   : GateResult(approved: bool, reason: str)
CALLER   : 17_live_trading.live_engine
CALLEE   : 12_risk.risk_engine, 12_risk.exposure_manager,
           11_validation.qa_gate
DEPENDS  : risk_engine, exposure_manager, qa_gate, strategy_registry
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Optional


@dataclass
class GateResult:
    approved: bool
    reason: str = ""


class LiveGate:
    """
    Every strategy must carry a certification record showing it passed:
      - backtest
      - optimization
      - walk_forward
      - stress_test
      - risk_test
      - qa_gate
      - paper_trade (minimum run duration / trade count met)
    Only then is it eligible for live capital.
    """

    REQUIRED_STAGES = [
        "backtest", "optimization", "walk_forward",
        "stress_test", "risk_test", "qa_gate", "paper_trade",
    ]

    def __init__(self, risk_engine, exposure_manager, qa_gate,
                 strategy_certifications: Optional[Dict[str, Dict]] = None,
                 min_paper_trades: int = 30):
        self.risk_engine = risk_engine
        self.exposure_manager = exposure_manager
        self.qa_gate = qa_gate
        self.certifications = strategy_certifications or {}
        self.min_paper_trades = min_paper_trades

    def register_certification(self, strategy_id: str, stage: str, passed: bool, **details):
        cert = self.certifications.setdefault(strategy_id, {})
        cert[stage] = {"passed": passed, **details}

    def _certification_complete(self, strategy_id: str) -> GateResult:
        cert = self.certifications.get(strategy_id)
        if not cert:
            return GateResult(False, "NO_CERTIFICATION_RECORD")
        for stage in self.REQUIRED_STAGES:
            entry = cert.get(stage)
            if not entry or not entry.get("passed"):
                return GateResult(False, f"STAGE_NOT_PASSED:{stage}")
        paper_trades = cert.get("paper_trade", {}).get("trade_count", 0)
        if paper_trades < self.min_paper_trades:
            return GateResult(False, f"INSUFFICIENT_PAPER_TRADES:{paper_trades}/{self.min_paper_trades}")
        return GateResult(True)

    def check(self, order) -> GateResult:
        strategy_id = getattr(order, "strategy_id", None)
        if not strategy_id:
            return GateResult(False, "NO_STRATEGY_ID_ON_ORDER")

        cert_result = self._certification_complete(strategy_id)
        if not cert_result.approved:
            return cert_result

        qa_result = self.qa_gate.check_strategy(strategy_id)
        if not qa_result.get("passed", False):
            return GateResult(False, f"QA_GATE_FAILED:{qa_result.get('reason','')}")

        risk_result = self.risk_engine.pre_trade_check(order)
        if not risk_result.get("passed", False):
            return GateResult(False, f"RISK_CHECK_FAILED:{risk_result.get('reason','')}")

        exposure_result = self.exposure_manager.check(order)
        if not exposure_result.get("passed", False):
            return GateResult(False, f"EXPOSURE_LIMIT_BREACHED:{exposure_result.get('reason','')}")

        return GateResult(True, "ALL_CHECKS_PASSED")
