"""
GTS — Global Trading System
Module   : 14_execution/execution_engine.py
Owner    : AI-4

INPUT       : A validated Order (passed order_validator.py) and a
              BrokerAdapter implementation from 15_broker.
OUTPUT      : ExecutionResult (fill or rejection), and emits fills onward
              to 13_portfolio/portfolio_manager.py and
              18_accounting/ledger.py.
CALLER      : 14_execution/order_manager.py.
CALLEE       : 15_broker/broker_adapter_base.py (the abstract interface —
              execution_engine.py never talks to a specific broker
              directly, only through this interface, so 15_broker can be
              swapped/mocked freely).
DEPENDENCIES: Standard library only. Depends on 15_broker's abstract
              interface only (not on any concrete broker).

Purpose: the single choke point through which every order that reaches a
real broker connection must pass. Applies a submission timeout, retry
policy for transient broker errors, and structured logging of every
attempt — this is the audit trail for "what did GTS actually try to do
in the market."
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Protocol

logger = logging.getLogger("gts.execution.execution_engine")
if not logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"))
    logger.addHandler(_h)
    logger.setLevel(logging.INFO)


class ExecutionStatus(str, Enum):
    FILLED = "FILLED"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    REJECTED = "REJECTED"
    ERROR = "ERROR"


@dataclass(frozen=True)
class BrokerFillResponse:
    """What a BrokerAdapter.submit_order() must return."""
    status: ExecutionStatus
    filled_quantity: float
    average_fill_price: float
    broker_order_id: str = ""
    message: str = ""


class BrokerAdapter(Protocol):
    """
    Abstract interface every concrete broker in 15_broker must implement.
    execution_engine.py only ever calls through this Protocol — see
    15_broker/broker_adapter_base.py for the canonical base class.
    """

    def submit_order(self, order: "OrderLike") -> BrokerFillResponse: ...


class OrderLike(Protocol):
    order_id: str
    symbol: str
    side: str
    quantity: float


@dataclass
class ExecutionResult:
    order_id: str
    status: ExecutionStatus
    filled_quantity: float
    average_fill_price: float
    attempts: int
    broker_order_id: str = ""
    message: str = ""
    executed_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @property
    def is_success(self) -> bool:
        return self.status in (ExecutionStatus.FILLED, ExecutionStatus.PARTIALLY_FILLED)

    def __str__(self) -> str:  # pragma: no cover
        return (
            f"{self.status.value} order={self.order_id} "
            f"qty={self.filled_quantity}@{self.average_fill_price} "
            f"attempts={self.attempts} {self.message}"
        )


class TransientBrokerError(Exception):
    """Raised by a BrokerAdapter for retryable failures (timeouts,
    connectivity blips). Any other exception is treated as fatal/non-retryable."""


class ExecutionEngine:
    """
    Submits validated orders to a broker adapter with bounded retries and
    a submission timeout. Never talks to a broker except through the
    BrokerAdapter interface.

    Usage
    -----
        engine = ExecutionEngine(broker=my_broker_adapter, max_retries=3)
        result = engine.execute(order)
    """

    def __init__(
        self,
        broker: BrokerAdapter,
        max_retries: int = 3,
        retry_backoff_seconds: float = 0.5,
        timeout_seconds: float = 10.0,
    ) -> None:
        self.broker = broker
        self.max_retries = max_retries
        self.retry_backoff_seconds = retry_backoff_seconds
        self.timeout_seconds = timeout_seconds

    # ------------------------------------------------------------------ #

    def execute(self, order: OrderLike) -> ExecutionResult:
        attempts = 0
        last_message = ""

        while attempts < self.max_retries:
            attempts += 1
            start = time.monotonic()
            try:
                response = self.broker.submit_order(order)
            except TransientBrokerError as exc:
                last_message = f"Transient broker error (attempt {attempts}): {exc}"
                logger.warning(last_message)
                self._sleep_backoff(attempts)
                continue
            except Exception as exc:  # noqa: BLE001 - fatal, non-retryable by design
                logger.error("Fatal broker error for order %s: %s", order.order_id, exc)
                return ExecutionResult(
                    order_id=order.order_id,
                    status=ExecutionStatus.ERROR,
                    filled_quantity=0.0,
                    average_fill_price=0.0,
                    attempts=attempts,
                    message=f"Fatal broker error: {exc}",
                )

            elapsed = time.monotonic() - start
            if elapsed > self.timeout_seconds:
                last_message = (
                    f"Broker response took {elapsed:.2f}s, exceeding "
                    f"timeout {self.timeout_seconds:.2f}s (attempt {attempts})."
                )
                logger.warning(last_message)
                self._sleep_backoff(attempts)
                continue

            result = ExecutionResult(
                order_id=order.order_id,
                status=response.status,
                filled_quantity=response.filled_quantity,
                average_fill_price=response.average_fill_price,
                attempts=attempts,
                broker_order_id=response.broker_order_id,
                message=response.message,
            )
            logger.info(str(result))
            return result

        # Exhausted retries without a usable response.
        result = ExecutionResult(
            order_id=order.order_id,
            status=ExecutionStatus.ERROR,
            filled_quantity=0.0,
            average_fill_price=0.0,
            attempts=attempts,
            message=f"Exhausted {self.max_retries} attempts. Last error: {last_message}",
        )
        logger.error(str(result))
        return result

    # ------------------------------------------------------------------ #

    def _sleep_backoff(self, attempt: int) -> None:
        time.sleep(self.retry_backoff_seconds * attempt)


# --------------------------------------------------------------------------- #
# A tiny in-memory broker used only for the CLI smoke-test below. Real
# adapters live in 15_broker and implement the same BrokerAdapter protocol.
# --------------------------------------------------------------------------- #

class _FakeBroker:
    def submit_order(self, order: OrderLike) -> BrokerFillResponse:
        return BrokerFillResponse(
            status=ExecutionStatus.FILLED,
            filled_quantity=order.quantity,
            average_fill_price=20000.0,
            broker_order_id="FAKE-1",
            message="filled by fake broker",
        )


def main(argv: list[str] | None = None) -> int:
    """CLI smoke-test: python execution_engine.py"""
    from dataclasses import dataclass as _dc

    @_dc
    class _DemoOrder:
        order_id: str
        symbol: str
        side: str
        quantity: float

    engine = ExecutionEngine(broker=_FakeBroker())
    order = _DemoOrder(order_id="ORD-0001", symbol="NIFTY", side="BUY", quantity=50)
    result = engine.execute(order)
    print(result)
    return 0 if result.is_success else 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
