# GTS CLEAN VERIFIED MASTER — FILE-BY-FILE AUDIT v1.0

Basis: GTS_ALL_CURRENT_BLUEPRINTS_MASTER_v1.0(2).md + user-locked V2 verification.

Total audited source files: 88. Python syntax failures: 0.

## Status rules
- 🟢 VERIFIED/OK = retain
- 🟠 REVIEW/ADAPT = retain as reference; not canonical merge-ready
- 🔵 RENAME/MOVE = later canonical re-home without changing logic
- 🔴 REJECT = do not use without Owner approval

## GTS_V2.zip

- Files checked: 62
- Status: 🟢 VERIFIED LOCKED
- Python syntax failures: 0

| # | Path | Status | Blueprint | Action |
|---:|---|---|---|---|
| 1 | `gts_project/09_backtest/__init__.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 2 | `gts_project/09_backtest/backtest_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 3 | `gts_project/07_alert_engine/__init__.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 4 | `gts_project/07_alert_engine/notification_manager.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 5 | `gts_project/10_risk_execution_support/__init__.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 6 | `gts_project/10_risk_execution_support/hyper_velocity_trailing_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 7 | `gts_project/05_market_analysis/__init__.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 8 | `gts_project/05_market_analysis/correlation_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 9 | `gts_project/05_market_analysis/economic_calendar.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 10 | `gts_project/05_market_analysis/hurst_regime_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 11 | `gts_project/05_market_analysis/liquidity_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 12 | `gts_project/05_market_analysis/market_hours.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 13 | `gts_project/05_market_analysis/market_regime.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 14 | `gts_project/05_market_analysis/momentum_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 15 | `gts_project/05_market_analysis/mtf_confluence.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 16 | `gts_project/05_market_analysis/trend_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 17 | `gts_project/05_market_analysis/volatility_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 18 | `gts_project/08_strategies/__init__.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 19 | `gts_project/08_strategies/multi_asset_strategies.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 20 | `gts_project/08_strategies/panel_gate_controller.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 21 | `gts_project/06_options_engine/__init__.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 22 | `gts_project/06_options_engine/breadth_micro_scalper.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 23 | `gts_project/06_options_engine/expiry_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 24 | `gts_project/06_options_engine/expiry_signal_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 25 | `gts_project/06_options_engine/gamma_acceleration_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 26 | `gts_project/06_options_engine/gamma_blast_house_money.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 27 | `gts_project/06_options_engine/gamma_blast_ladder_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 28 | `gts_project/06_options_engine/gamma_blast_selector.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 29 | `gts_project/06_options_engine/gex_regime_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 30 | `gts_project/06_options_engine/greeks_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 31 | `gts_project/06_options_engine/implied_volatility.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 32 | `gts_project/06_options_engine/micro_price_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 33 | `gts_project/06_options_engine/net_delta_exposure_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 34 | `gts_project/06_options_engine/open_interest.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 35 | `gts_project/06_options_engine/options_chain.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 36 | `gts_project/06_options_engine/options_selector.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 37 | `gts_project/06_options_engine/premium_analysis.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 38 | `gts_project/06_options_engine/pricing_models.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 39 | `gts_project/06_options_engine/pullback_counter_scalp_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 40 | `gts_project/06_options_engine/straddle_scanner.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 41 | `gts_project/06_options_engine/strike_selection.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 42 | `gts_project/06_options_engine/svi_volatility_surface.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 43 | `gts_project/06_options_engine/synthetic_forward_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 44 | `gts_project/06_options_engine/vanna_charm_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 45 | `gts_project/06_options_engine/volatility_skew_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 46 | `gts_project/06_options_engine/volume_analysis.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 47 | `gts_project/06_options_engine/zero_gamma_flip.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 48 | `gts_project/04_indicators/__init__.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 49 | `gts_project/04_indicators/adx.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 50 | `gts_project/04_indicators/atr.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 51 | `gts_project/04_indicators/ema.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 52 | `gts_project/04_indicators/fibonacci.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 53 | `gts_project/04_indicators/indicator_engine.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 54 | `gts_project/04_indicators/macd.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 55 | `gts_project/04_indicators/math_utils.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 56 | `gts_project/04_indicators/pivot.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 57 | `gts_project/04_indicators/price_action.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 58 | `gts_project/04_indicators/rsi.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 59 | `gts_project/04_indicators/supertrend.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 60 | `gts_project/21_ai/__init__.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 61 | `gts_project/21_ai/market_ai_adapter.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |
| 62 | `gts_project/21_ai/strategy_suggestion_input.py` | 🟢 VERIFIED LOCKED | MATCH — verified implementation; canonical re-home only if/when required | KEEP AS-IS |

## GTS_01_market_data_COMPLETED-8.zip

- Files checked: 13
- Status: 🟢 OK / TESTED
- Python syntax failures: 0

| # | Path | Status | Blueprint | Action |
|---:|---|---|---|---|
| 63 | `GTS_01_market_data_AUDIT.md` | 🟢 OK / TESTED | MATCH — canonical 01_market_data | KEEP |
| 64 | `01_market_data/data_normalizer.py` | 🟢 OK / TESTED | MATCH — canonical 01_market_data | KEEP |
| 65 | `01_market_data/historical_data_fetcher.py` | 🟢 OK / TESTED | MATCH — canonical 01_market_data | KEEP |
| 66 | `01_market_data/market_data_cache.py` | 🟢 OK / TESTED | MATCH — canonical 01_market_data | KEEP |
| 67 | `01_market_data/market_data_feed.py` | 🟢 OK / TESTED | MATCH — canonical 01_market_data | KEEP |
| 68 | `01_market_data/market_data_manager.py` | 🟢 OK / TESTED | MATCH — canonical 01_market_data | KEEP |
| 69 | `01_market_data/market_data_types.py` | 🟢 OK / TESTED | MATCH — canonical 01_market_data | KEEP |
| 70 | `01_market_data/websocket_manager.py` | 🟢 OK / TESTED | MATCH — canonical 01_market_data | KEEP |
| 71 | `01_market_data/tests/test_data_normalizer.py` | 🟢 OK / TESTED | MATCH — canonical 01_market_data | KEEP |
| 72 | `01_market_data/tests/test_historical_and_cache.py` | 🟢 OK / TESTED | MATCH — canonical 01_market_data | KEEP |
| 73 | `01_market_data/tests/test_market_data_feed.py` | 🟢 OK / TESTED | MATCH — canonical 01_market_data | KEEP |
| 74 | `01_market_data/tests/test_market_data_managers.py` | 🟢 OK / TESTED | MATCH — canonical 01_market_data | KEEP |
| 75 | `.pytest_cache/README.md` | 🟢 OK / TESTED | MATCH — canonical 01_market_data | KEEP |

## GTS_02_instruments_COMPLETED-10.zip

- Files checked: 12
- Status: 🟢 OK / TESTED
- Python syntax failures: 0

| # | Path | Status | Blueprint | Action |
|---:|---|---|---|---|
| 76 | `GTS_02_instruments_AUDIT.md` | 🟢 OK / TESTED | MATCH — canonical 02_instruments | KEEP |
| 77 | `.pytest_cache/README.md` | 🟢 OK / TESTED | MATCH — canonical 02_instruments | KEEP |
| 78 | `02_instruments/contract_builder.py` | 🟢 OK / TESTED | MATCH — canonical 02_instruments | KEEP |
| 79 | `02_instruments/contract_manager.py` | 🟢 OK / TESTED | MATCH — canonical 02_instruments | KEEP |
| 80 | `02_instruments/expiry_calendar.py` | 🟢 OK / TESTED | MATCH — canonical 02_instruments | KEEP |
| 81 | `02_instruments/expiry_manager.py` | 🟢 OK / TESTED | MATCH — canonical 02_instruments | KEEP |
| 82 | `02_instruments/instrument_master.py` | 🟢 OK / TESTED | MATCH — canonical 02_instruments | KEEP |
| 83 | `02_instruments/instrument_types.py` | 🟢 OK / TESTED | MATCH — canonical 02_instruments | KEEP |
| 84 | `02_instruments/tests/test_contract_builder.py` | 🟢 OK / TESTED | MATCH — canonical 02_instruments | KEEP |
| 85 | `02_instruments/tests/test_expiry_calendar.py` | 🟢 OK / TESTED | MATCH — canonical 02_instruments | KEEP |
| 86 | `02_instruments/tests/test_instrument_managers.py` | 🟢 OK / TESTED | MATCH — canonical 02_instruments | KEEP |
| 87 | `02_instruments/tests/test_instrument_master.py` | 🟢 OK / TESTED | MATCH — canonical 02_instruments | KEEP |

## GTS_NewsEngine_V5_OK-1.zip

- Files checked: 1
- Status: 🟠 REVIEW / ADAPT
- Python syntax failures: 0

| # | Path | Status | Blueprint | Action |
|---:|---|---|---|---|
| 88 | `news_intelligence/NewsEngine_V5.py` | 🟠 REVIEW / ADAPT | PARTIAL — functionality present, but required canonical registry is not complete | KEEP AS REFERENCE; ADAPT BEFORE CANONICAL MERGE |

