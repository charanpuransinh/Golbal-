"""
test_trade_book.py
MODULE: 18_accounting (tests)
OWNER : AI-4
Covers: open/close round-trip trades, PnL calc, open vs closed queries.
"""

import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from trade_book import TradeBook, TradeStatus


def test_open_trade_is_tracked_as_open():
    book = TradeBook()
    trade = book.open_trade("NIFTY", "S1", "LONG", entry_price=100, entry_qty=10)
    assert trade.status == TradeStatus.OPEN
    assert len(book.open_trades()) == 1


def test_close_trade_computes_long_pnl():
    book = TradeBook()
    book.open_trade("NIFTY", "S1", "LONG", entry_price=100, entry_qty=10)
    closed = book.close_trade("NIFTY", "S1", exit_price=110, exit_qty=10)
    assert closed.status == TradeStatus.CLOSED
    assert closed.realized_pnl == 100.0  # (110-100)*10


def test_close_trade_computes_short_pnl():
    book = TradeBook()
    book.open_trade("SILVER", "S2", "SHORT", entry_price=50, entry_qty=5)
    closed = book.close_trade("SILVER", "S2", exit_price=40, exit_qty=5)
    assert closed.realized_pnl == 50.0  # -1*(40-50)*5


def test_closing_unknown_trade_returns_none():
    book = TradeBook()
    result = book.close_trade("UNKNOWN", "S1", exit_price=1, exit_qty=1)
    assert result is None


def test_total_realized_pnl_aggregates():
    book = TradeBook()
    book.open_trade("GOLD", "S1", "LONG", entry_price=100, entry_qty=1)
    book.close_trade("GOLD", "S1", exit_price=120, exit_qty=1)
    book.open_trade("CRUDE", "S1", "LONG", entry_price=50, entry_qty=2)
    book.close_trade("CRUDE", "S1", exit_price=45, exit_qty=2)
    assert book.total_realized_pnl("S1") == 20 + (-10)


if __name__ == "__main__":
    test_open_trade_is_tracked_as_open()
    test_close_trade_computes_long_pnl()
    test_close_trade_computes_short_pnl()
    test_closing_unknown_trade_returns_none()
    test_total_realized_pnl_aggregates()
    print("trade_book: ALL TESTS PASSED")
