"""
trade_report.py
================
MODULE   : 19_reporting
OWNER    : AI-4
PURPOSE  : Human-readable / exportable trade-level reports — trade logs,
           per-strategy breakdowns, daily/weekly/monthly summaries.

INPUT    : TradeRecord list (18_accounting.trade_book), date range
OUTPUT   : Structured trade report (dict), CSV-ready rows
CALLER   : 20_dashboard, owner (manual export), 19_reporting (aggregation)
CALLEE   : 18_accounting.trade_book
DEPENDS  : trade_book
"""

from __future__ import annotations
import csv
import io
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class TradeReportRow:
    trade_id: str
    symbol: str
    strategy_id: Optional[str]
    side: str
    entry_price: float
    exit_price: Optional[float]
    quantity: float
    entry_time: float
    exit_time: Optional[float]
    realized_pnl: float
    fees: float
    status: str


@dataclass
class TradeReport:
    rows: List[TradeReportRow] = field(default_factory=list)
    summary_by_strategy: Dict[str, Dict] = field(default_factory=dict)
    summary_by_symbol: Dict[str, Dict] = field(default_factory=dict)


class TradeReportEngine:

    def __init__(self, trade_book):
        self.trade_book = trade_book

    def generate(self, strategy_id: str = None, symbol: str = None,
                 start_ts: float = None, end_ts: float = None) -> TradeReport:
        trades = self.trade_book.closed_trades(strategy_id=strategy_id, symbol=symbol)

        if start_ts is not None:
            trades = [t for t in trades if t.entry_time >= start_ts]
        if end_ts is not None:
            trades = [t for t in trades if t.entry_time <= end_ts]

        report = TradeReport()
        strat_agg = defaultdict(lambda: {"trades": 0, "pnl": 0.0, "fees": 0.0})
        symbol_agg = defaultdict(lambda: {"trades": 0, "pnl": 0.0, "fees": 0.0})

        for t in trades:
            row = TradeReportRow(
                trade_id=t.trade_id, symbol=t.symbol, strategy_id=t.strategy_id,
                side=t.side, entry_price=t.entry_price, exit_price=t.exit_price,
                quantity=t.entry_qty, entry_time=t.entry_time, exit_time=t.exit_time,
                realized_pnl=t.realized_pnl, fees=t.fees, status=t.status.value,
            )
            report.rows.append(row)

            key_s = t.strategy_id or "UNKNOWN"
            strat_agg[key_s]["trades"] += 1
            strat_agg[key_s]["pnl"] += t.realized_pnl
            strat_agg[key_s]["fees"] += t.fees

            symbol_agg[t.symbol]["trades"] += 1
            symbol_agg[t.symbol]["pnl"] += t.realized_pnl
            symbol_agg[t.symbol]["fees"] += t.fees

        report.summary_by_strategy = dict(strat_agg)
        report.summary_by_symbol = dict(symbol_agg)
        return report

    def to_csv(self, report: TradeReport) -> str:
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow([
            "trade_id", "symbol", "strategy_id", "side", "entry_price", "exit_price",
            "quantity", "entry_time", "exit_time", "realized_pnl", "fees", "status",
        ])
        for r in report.rows:
            writer.writerow([
                r.trade_id, r.symbol, r.strategy_id, r.side, r.entry_price, r.exit_price,
                r.quantity, r.entry_time, r.exit_time, r.realized_pnl, r.fees, r.status,
            ])
        return buf.getvalue()
