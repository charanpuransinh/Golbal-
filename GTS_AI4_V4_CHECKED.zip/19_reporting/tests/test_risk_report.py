"""
test_risk_report.py
MODULE: 19_reporting (tests)
OWNER : AI-4
Covers: exposure aggregation, leverage calc, VaR, limit breach reporting.
"""

import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from risk_report import RiskReportEngine


class FakePortfolioManager:
    def __init__(self, positions):
        self._positions = positions
    def get_all_positions(self):
        return self._positions


class FakeExposureManager:
    def __init__(self, breaches=None):
        self.breaches = breaches or []
    def check_all(self, positions, equity):
        return {"breaches": self.breaches}


class FakeKillSwitch:
    def __init__(self, tripped=False):
        self._tripped = tripped
    def is_tripped(self):
        return self._tripped


def test_exposure_and_leverage_calc():
    positions = [
        {"symbol": "NIFTY", "quantity": 10, "last_price": 100, "avg_price": 90},
        {"symbol": "GOLD", "quantity": -5, "last_price": 50, "avg_price": 55},
    ]
    engine = RiskReportEngine(FakeExposureManager(), risk_engine=object(),
                               portfolio_manager=FakePortfolioManager(positions))
    report = engine.generate(account_equity=1000)
    assert report.gross_exposure == 1000 + 250
    assert round(report.leverage, 3) == round(1250 / 1000, 3)


def test_limit_breaches_reported():
    positions = [{"symbol": "CRUDE", "quantity": 100, "last_price": 60, "avg_price": 58}]
    engine = RiskReportEngine(FakeExposureManager(breaches=["MAX_POSITION_EXCEEDED"]),
                               risk_engine=object(), portfolio_manager=FakePortfolioManager(positions))
    report = engine.generate(account_equity=5000)
    assert "MAX_POSITION_EXCEEDED" in report.limit_breaches


def test_kill_switch_status_reflected():
    engine = RiskReportEngine(FakeExposureManager(), risk_engine=object(),
                               portfolio_manager=FakePortfolioManager([]),
                               kill_switch=FakeKillSwitch(tripped=True))
    report = engine.generate(account_equity=1000)
    assert report.kill_switch_active is True


def test_var_from_historical_returns():
    engine = RiskReportEngine(FakeExposureManager(), risk_engine=object(),
                               portfolio_manager=FakePortfolioManager([]))
    returns = [-0.05, -0.02, 0.01, 0.03, -0.08, 0.02, -0.01, 0.04, -0.03, 0.0]
    report = engine.generate(account_equity=1000, historical_returns=returns)
    assert report.value_at_risk_95 is not None


if __name__ == "__main__":
    test_exposure_and_leverage_calc()
    test_limit_breaches_reported()
    test_kill_switch_status_reflected()
    test_var_from_historical_returns()
    print("risk_report: ALL TESTS PASSED")
