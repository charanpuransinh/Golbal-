"""
GTS — Global Trading System
Module   : 10_optimization
File     : optimizer.py
Owner    : AI-4 (Backtest + Risk + Execution + Production)

PURPOSE
-------
Runs a caller-supplied objective function (in practice: "build a
BacktestEngine with these parameters, run it, return
PerformanceEngine.summary()") over a sequence of parameter combinations
(from parameter_search.py's GridSearch/RandomSearch), and ranks the
results by a chosen metric.

This file knows nothing about strategies or backtesting internals — it is
a generic "evaluate many parameter sets, rank by a metric" runner, kept
strictly decoupled from 09_backtest per the plugin-first /
core-engines-independent architectural rule so it can equally optimize a
strategy's own parameters or a risk-engine's parameters.

CONTRACT
--------
INPUT      : An objective_fn: Callable[[Dict[str, Any]], Dict[str, object]]
             and an iterable of parameter-combination dicts (typically
             from parameter_search.py).
OUTPUT     : List[OptimizationResult], sorted best-first by the configured
             metric.
CALLER     : A human/operator script, or walk_forward.py (re-optimizes
             per rolling window).
CALLEE     : None directly — objective_fn is supplied by the caller and
             may internally call backtest_engine.py, but optimizer.py
             itself has zero import dependency on it.
DEPENDENCIES: Python standard library only (logging, dataclasses).

ARCHITECTURAL RULES ENFORCED
-----------------------------
- No guessing: a combination whose objective_fn raises, or whose returned
  summary is missing the configured metric key, or whose metric value is
  None, is recorded with an explicit failure reason (never silently
  dropped, never assigned a fabricated score) and sorted after every
  successful result — best() therefore never accidentally returns a
  failed run as though it were the winner.
- Determinism: given the same objective_fn and the same ordered iterable
  of combinations, run() always evaluates them in the same order and
  produces the same ranking (stable sort) — required for optimizer output
  to be diffable across code changes during development.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional

logger = logging.getLogger("gts.optimization.optimizer")

ObjectiveFunction = Callable[[Dict[str, Any]], Dict[str, object]]


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class OptimizerError(Exception):
    """Base exception for all optimizer failures."""


# ---------------------------------------------------------------------------
# Result record
# ---------------------------------------------------------------------------

@dataclass
class OptimizationResult:
    """The outcome of evaluating one parameter combination.

    metric_value is None when the run failed or the metric was
    undefined/missing — `failure_reason` explains why in that case, and
    is None for every successful result.
    """

    params: Dict[str, Any]
    metric_value: Optional[float]
    summary: Optional[Dict[str, object]]
    failure_reason: Optional[str] = None

    @property
    def succeeded(self) -> bool:
        return self.failure_reason is None and self.metric_value is not None


# ---------------------------------------------------------------------------
# Optimizer
# ---------------------------------------------------------------------------

class Optimizer:
    """Evaluates `objective_fn` over many parameter combinations and ranks
    the results by `metric_name`.

    Example:
        def objective(params: dict) -> dict:
            bt = BacktestEngine(starting_cash=100000.0, ...)
            wire_my_strategy(bt, **params)
            result = bt.run(bars)
            return result.summary

        optimizer = Optimizer(objective, metric_name="sharpe_ratio", maximize=True)
        results = optimizer.run(GridSearch(space))
        best = optimizer.best(results)
    """

    def __init__(self, objective_fn: ObjectiveFunction, metric_name: str, maximize: bool = True):
        """
        Args:
            objective_fn: called once per parameter combination; must
                return a dict (typically a PerformanceEngine.summary())
                containing `metric_name`.
            metric_name: key to read out of the dict returned by
                objective_fn for ranking (e.g. "sharpe_ratio",
                "total_return", "profit_factor").
            maximize: if True, higher metric values rank better (default —
                correct for sharpe_ratio, total_return, profit_factor,
                win_rate); set False for metrics where lower is better
                (e.g. "max_drawdown").
        """
        self.objective_fn = objective_fn
        self.metric_name = metric_name
        self.maximize = maximize

    def run(self, param_combinations: Iterable[Dict[str, Any]]) -> List[OptimizationResult]:
        """Evaluate every combination in `param_combinations`, in order,
        and return all results sorted best-first (successful results
        ranked by metric_name per `maximize`; failed/degenerate results
        follow, in the order they were evaluated).

        A combination's objective_fn call raising an exception is caught,
        logged with the offending params, and recorded as a failed
        OptimizationResult — it never stops the rest of the search.
        """
        results: List[OptimizationResult] = []
        for i, params in enumerate(param_combinations):
            result = self._evaluate_one(i, params)
            results.append(result)

        successful = [r for r in results if r.succeeded]
        failed = [r for r in results if not r.succeeded]
        successful.sort(key=lambda r: r.metric_value, reverse=self.maximize)
        return successful + failed

    def _evaluate_one(self, index: int, params: Dict[str, Any]) -> OptimizationResult:
        try:
            summary = self.objective_fn(params)
        except Exception as exc:  # noqa: BLE001 - deliberately broad: isolate one bad combo
            logger.error(
                "objective_fn raised for combination #%d (params=%s): %s",
                index, params, exc, exc_info=True,
            )
            return OptimizationResult(
                params=params, metric_value=None, summary=None,
                failure_reason=f"objective_fn raised {type(exc).__name__}: {exc}",
            )

        if not isinstance(summary, dict):
            reason = f"objective_fn must return a dict, got {type(summary).__name__}"
            logger.error("Combination #%d (params=%s): %s", index, params, reason)
            return OptimizationResult(params=params, metric_value=None, summary=None, failure_reason=reason)

        if self.metric_name not in summary:
            reason = f"metric '{self.metric_name}' not present in objective_fn result"
            logger.warning("Combination #%d (params=%s): %s", index, params, reason)
            return OptimizationResult(params=params, metric_value=None, summary=summary, failure_reason=reason)

        metric_value = summary[self.metric_name]
        if metric_value is None:
            reason = f"metric '{self.metric_name}' was None (undefined for this run)"
            logger.info("Combination #%d (params=%s): %s", index, params, reason)
            return OptimizationResult(params=params, metric_value=None, summary=summary, failure_reason=reason)

        try:
            metric_value = float(metric_value)
        except (TypeError, ValueError):
            reason = f"metric '{self.metric_name}' value {metric_value!r} is not numeric"
            logger.error("Combination #%d (params=%s): %s", index, params, reason)
            return OptimizationResult(params=params, metric_value=None, summary=summary, failure_reason=reason)

        return OptimizationResult(params=params, metric_value=metric_value, summary=summary)

    @staticmethod
    def best(results: List[OptimizationResult]) -> Optional[OptimizationResult]:
        """Return the top-ranked result from a list produced by `run()`,
        or None if every result failed/was degenerate. Since `run()`
        already sorts successful results first, this is simply the first
        successful entry (results are not re-sorted here, so passing a
        list you sorted differently yourself will not be respected — call
        run() again or sort explicitly if needed)."""
        for result in results:
            if result.succeeded:
                return result
        return None
