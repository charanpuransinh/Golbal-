"""
test_performance_report.py
MODULE: 19_reporting (tests)
OWNER : AI-4
Covers: win rate, profit factor, drawdown, Sharpe from a synthetic equity curve.
"""

import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from performance_report import PerformanceReportEngine


class FakeTrade:
    def __init__(self, pnl):
        self.realized_pnl = pnl


def test_win_rate_and_profit_factor():
    engine = PerformanceReportEngine()
    trades = [FakeTrade(100), FakeTrade(-50), FakeTrade(200), FakeTrade(-25)]
    report = engine.from_trades(trades)
    assert report.total_trades == 4
    assert report.winning_trades == 2
    assert report.win_rate == 0.5
    assert report.gross_profit == 300
    assert report.gross_loss == 75
    assert report.profit_factor == 4.0


def test_empty_trades_returns_zeroed_report():
    engine = PerformanceReportEngine()
    report = engine.from_trades([])
    assert report.total_trades == 0
    assert report.win_rate == 0.0


def test_drawdown_from_equity_curve():
    engine = PerformanceReportEngine()
    report = engine.from_trades([FakeTrade(10)])
    curve = [100, 120, 90, 130, 80, 150]
    report = engine.with_equity_curve(report, curve)
    assert report.max_drawdown == 50   # peak 130 -> trough 80
    assert round(report.max_drawdown_pct, 4) == round(50 / 130, 4)


def test_generate_combines_trades_and_curve():
    engine = PerformanceReportEngine()
    trades = [FakeTrade(10), FakeTrade(-5)]
    curve = [1000, 1010, 1005, 1015]
    report = engine.generate(trades, curve)
    assert report.total_trades == 2
    assert report.max_drawdown >= 0


if __name__ == "__main__":
    test_win_rate_and_profit_factor()
    test_empty_trades_returns_zeroed_report()
    test_drawdown_from_equity_curve()
    test_generate_combines_trades_and_curve()
    print("performance_report: ALL TESTS PASSED")
