"""
GTS — Global Trading System
Module   : 12_risk/kill_switch.py
Owner    : AI-4

INPUT       : Trip triggers from risk_engine.py (daily loss breach,
              drawdown breach, manual operator command, anomaly
              detection from 21_ai, connectivity loss from 15_broker).
OUTPUT      : KillSwitch state (active/inactive) that risk_engine.py
              consults on every single order evaluation.
CALLER      : 12_risk/risk_engine.py, 17_live_trading/live_gate.py,
              22_security (for manual/authenticated trip & reset),
              24_api (operator-facing trip/reset endpoint).
CALLEE      : None outside stdlib.
DEPENDENCIES: Standard library only.

Purpose: an absolute, global emergency stop. Once tripped, it blocks
ALL new order flow across every strategy until explicitly, and
deliberately, reset by an authorized operator. It is intentionally the
simplest, most auditable module in the risk package — a kill switch that
itself has bugs defeats its purpose.

Design notes:
- Tripping is idempotent (tripping an already-tripped switch just logs).
- Every trip and reset is recorded in an in-memory audit trail with a
  reason and timestamp; callers persisting elsewhere (23_database) should
  read `history` and store it durably.
- Reset requires an explicit reason string — accidental/no-arg resets are
  not possible by construction.
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone

logger = logging.getLogger("gts.risk.kill_switch")
if not logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"))
    logger.addHandler(_h)
    logger.setLevel(logging.INFO)


@dataclass(frozen=True)
class KillSwitchEvent:
    action: str  # "TRIP" or "RESET"
    reason: str
    actor: str
    at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def __str__(self) -> str:  # pragma: no cover
        return f"{self.at} | {self.action} | actor={self.actor} | reason={self.reason}"


class KillSwitch:
    """
    Global, thread-safe emergency stop for all GTS order flow.

    Usage
    -----
        switch = KillSwitch()
        switch.trip("daily_loss_limit_breached", actor="risk_engine")
        assert switch.is_active()
        switch.reset("manual review complete, resuming trading", actor="ops_team")
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._active = False
        self._history: list[KillSwitchEvent] = []

    # ------------------------------------------------------------------ #

    def is_active(self) -> bool:
        with self._lock:
            return self._active

    def trip(self, reason: str, actor: str = "system") -> None:
        """Activate the kill switch. Safe to call repeatedly."""
        with self._lock:
            event = KillSwitchEvent(action="TRIP", reason=reason, actor=actor)
            self._history.append(event)
            if self._active:
                logger.warning("Kill switch already active; additional trip logged: %s", event)
                return
            self._active = True
            logger.critical("KILL SWITCH TRIPPED: %s", event)

    def reset(self, reason: str, actor: str) -> None:
        """
        Deactivate the kill switch. A non-empty reason and actor are
        mandatory — this is a deliberate, auditable action, never a
        default/no-op call.
        """
        if not reason or not reason.strip():
            raise ValueError("A non-empty reason is required to reset the kill switch.")
        if not actor or not actor.strip():
            raise ValueError("A non-empty actor is required to reset the kill switch.")

        with self._lock:
            event = KillSwitchEvent(action="RESET", reason=reason, actor=actor)
            self._history.append(event)
            if not self._active:
                logger.info("Kill switch reset requested but was not active: %s", event)
                return
            self._active = False
            logger.warning("KILL SWITCH RESET: %s", event)

    @property
    def history(self) -> list[KillSwitchEvent]:
        with self._lock:
            return list(self._history)

    def last_event(self) -> KillSwitchEvent | None:
        with self._lock:
            return self._history[-1] if self._history else None


def main(argv: list[str] | None = None) -> int:
    """CLI smoke-test: python kill_switch.py"""
    switch = KillSwitch()
    print("active:", switch.is_active())
    switch.trip("manual test trip", actor="cli_demo")
    print("active:", switch.is_active())
    switch.reset("test complete", actor="cli_demo")
    print("active:", switch.is_active())
    for event in switch.history:
        print(event)
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
